//
//  ConsoleFeature+InternalActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension ConsoleFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .logReceived(let log):
      state.logs.append(log)
      return .none
    case .startBroadcast:
      return .run { _ in
        await log.startBroadcast()
      }
    case .stopBroadcast:
      return .run { _ in
        await log.stopBroadcast()
      }
    case .toggleBroadcast(let isRunning):
      state.isBroadcasting = isRunning
      return .none
    }
  }
}
