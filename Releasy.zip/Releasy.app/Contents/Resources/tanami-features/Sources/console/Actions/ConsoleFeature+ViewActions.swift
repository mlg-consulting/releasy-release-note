//
//  ConsoleFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import SwiftUI

extension ConsoleFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .logRowTapped(let id):
      guard let log = state.logs.first(where: { $0.id == id }) else { return .none }
      system.addToPasteboard(log.name)
      if let data = log.params.data(using: .utf8),
         let object = try? JSONSerialization.jsonObject(with: data),
         let dataString = try? JSONSerialization.data(
          withJSONObject: object, options: [.prettyPrinted, .withoutEscapingSlashes, .sortedKeys]
         ) {
        state.logDetails = String(data: dataString, encoding: .utf8) ?? ""
      }
      return .none
    case .state:
      return .run { send in
        for await isRunning in await log.isRunning() {
          await send(.internal(.toggleBroadcast(isRunning)))
        }
      }
    case .task:
      return .run { send in
        await log.startBroadcast()
        for await log in await log.logs().dropFirst() {
          if let log {
            await send(.internal(.logReceived(log)))
          }
        }
      }
    case .toggleButtonTapped:
      return switch state.isBroadcasting {
      case true: .send(.internal(.stopBroadcast))
      case false: .send(.internal(.startBroadcast))
      }
    case .trashButtonTapped:
      state.logs.removeAll()
      state.logDetails = "{}"
      return .none
    case .windowWillClose:
      return .run { _ in
//        await log.stopBroadcast()
      }
    }
  }
}
