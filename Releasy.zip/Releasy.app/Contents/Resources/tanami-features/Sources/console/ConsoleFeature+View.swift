//
//  ConsoleFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import CodeMirror_SwiftUI
import ComposableArchitecture
import Dependencies
import LogService
import SystemService
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@ViewAction(for: ConsoleFeature.self)
public struct ConsoleFeatureView: View {
  enum SortType {
    case asc, desc

    mutating func toggle() {
      switch self {
        case .asc: self = .desc
        case .desc: self = .asc
      }
    }
  }

  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme
  @Dependency(\.systemClient) var system

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @Bindable public var store: StoreOf<ConsoleFeature>
  @State private var sortType: SortType = .asc
  @State private var selectedLogId: UUID?
  @State private var showDeviceFilter: Bool = false
  @State private var selectedDeviceId: UUID?
  @State private var currentDeviceId: String?

  let dateFormatter = Date.FormatStyle(date: .omitted, time: .standard)

  public init(store: StoreOf<ConsoleFeature>) {
    self.store = store
  }

  public var body: some View {
    VStack {
      toolbar
      HStack(alignment: .top) {
        sidebar
        detail
      }
    }
    .scrollIndicators(.hidden)
    .frame(minWidth: 800, minHeight: 800)
    .onReceive(NotificationCenter.default.publisher(for: NSWindow.willCloseNotification)) { notification in
      guard (notification.object as? NSWindow)?.identifier?.rawValue == "ConsoleWindow" else { return }
      send(.windowWillClose)
      customWindowPresentation?.dismiss()
    }
    .onChange(of: selectedLogId) { _, newValue in
      if let newValue {
        send(.logRowTapped(newValue))
      }
    }
    .task { send(.state) }
    .task { send(.task) }
  }
}

extension ConsoleFeatureView {
  private var toolbar: some View {
    HStack {
      Button(action: { send(.toggleButtonTapped) }) {
        designSystem.icon(store.isBroadcasting ? .pauseFill : .playFill)
          .font(.title3)
          .padding(designSystem.spacing(.xxs))
      }
      .buttonStyle(.plain)
      .help(store.isBroadcasting ? L10n.toolbarStopBroadcast : L10n.toolbarStartBroadcast)
      Divider().frame(height: designSystem.spacing(.m))
      Button(action: { send(.trashButtonTapped) }) {
        designSystem.icon(.trashFill)
          .font(.title3)
          .padding(designSystem.spacing(.xxs))
      }
      .buttonStyle(.plain)
      .disabled(store.logs.isEmpty)
      .help(L10n.toolbarClearLogs)
      Divider().frame(height: designSystem.spacing(.m))
      Button(action: { showDeviceFilter.toggle() }) {
        designSystem.icon(.line3HorizontalDecreaseCircleFill)
          .font(.title3)
          .padding(designSystem.spacing(.xxs))
          .foregroundStyle(currentDeviceId == .none || store.logs.isEmpty ? .white : .accentColor)
      }
      .buttonStyle(.plain)
      .disabled(store.logs.isEmpty)
      .help(L10n.toolbarFilterDevice)
      .popover(isPresented: $showDeviceFilter, arrowEdge: .trailing) {
        VStack(alignment: .leading) {
          Picker(selection: $currentDeviceId) {
            ForEach(store.deviceIds.sorted(), id: \.self) { deviceId in
              Label {
                Text(deviceId)
              } icon: {
                designSystem.icon(.appsIphone)
              }
              .tag(deviceId)
              .padding(designSystem.spacing(.xs))
            }
          } label: {
            Text("")
          }
          .labelsHidden()
          .pickerStyle(.radioGroup)
          Divider()
          HStack {
            Spacer()
            Button(action: {
              currentDeviceId = .none
              showDeviceFilter.toggle()
            }, label: {
              Text(L10n.deviceResetFilter)
            })
            .buttonStyle(.plain)
            .disabled(currentDeviceId == .none)
          }
        }
        .padding(designSystem.spacing(.m))
      }
      Divider().frame(height: designSystem.spacing(.m))
      Button(action: { sortType.toggle() }) {
        designSystem.icon(.arrowUpArrowDown)
          .font(.title3)
          .padding(designSystem.spacing(.xxs))
          .foregroundStyle(
            sortType == .asc ? Color.accentColor : .primary,
            sortType == .asc ? Color.primary: .accentColor
          )
      }
      .buttonStyle(.plain)
      .disabled(store.logs.isEmpty)
      .help(L10n.toolbarSort)
      Spacer()
      Button(action: { system.addToPasteboard(store.logDetails) }) {
        designSystem.icon(.docOnDocFill)
          .font(.title3)
          .padding(designSystem.spacing(.xxs))
          .foregroundStyle(.primary)
      }
      .buttonStyle(.plain)
      .disabled(store.logDetails.isEmpty)
      .help(L10n.toolbarCopy)
    }
    .padding(.top, 44.0)
    .padding(.horizontal, designSystem.spacing(.s))
  }

  private var sidebar: some View {
    List(
      store
        .logs
        .filter({ $0.deviceId == currentDeviceId || currentDeviceId == .none })
        .sorted(by: {
          switch sortType {
          case .asc: $0.createAt > $1.createAt
          case .desc: $0.createAt < $1.createAt
          }
        }),
      selection: $selectedLogId
    ) {
      logRow(for: $0)
    }
  }

  @ViewBuilder
  private var detail: some View {
    CodeView(
      theme: .dracula,
      code: .constant(store.logDetails),
      mode: CodeMode.json.mode(),
      fontSize: 17,
      showInvisibleCharacters: false,
      lineWrapping: true,
      readOnly: "true"
    )
    .preferredColorScheme(.dark)
  }

  private func logRow(for log: ConsoleLog) -> some View {
    HStack {
      VStack(alignment: .leading) {
        HStack(spacing: designSystem.spacing(.xs)) {
          device(id: log.deviceId)
          Divider()
          logTime(date: log.createAt)
        }
        .foregroundStyle(.secondary)
        Text(log.name)
          .font(.title3)
          .fontWeight(.semibold)
          .frame(maxWidth: .infinity, alignment: .leading)
          .multilineTextAlignment(.leading)
      }
    }
  }

  private func device(id: String) -> some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      designSystem.icon(.appsIphone)
      Text(id)
    }
    .fontDesign(.monospaced)
  }

  private func logTime(date: Date) -> some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      designSystem.icon(.clock)
      Text(date, format: dateFormatter)
    }
  }
}

#if DEBUG
#Preview {
  ConsoleFeatureView(
    store: Store(
      initialState: .initial(
        logs: [
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_notifications_tokenReceived",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"token\":\"809eff610b444c58fc4709da423062bc8e2cf946d2cd48514bb43b93169c9f8ba079aa6048fb6b97c83365f666d421502aea47bab8e4916d89beb4ea90a48c22429b5cbb95ce7479380d64360027bcc3\"}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_performance_start",
            timestamp: Date.now.timeIntervalSince1970,
            params: "",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_state_didEnterNetworkConnected",
            timestamp: Date.now.timeIntervalSince1970,
            params: "",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_attribution_success",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"market\":\"apple\",\"trackerName\":\"No User Consent\",\"networkName\":\"No User Consent\",\"tracker\":\"unattr\"}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_performance_available",
            timestamp: Date.now.timeIntervalSince1970,
            params: "",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_launch_installedApps",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"installedApps\":[]}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d", name: "app_feature_abTriggered",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"variantId\":\"WITH_AUTH\",\"featureId\":\"app_onboarding\"}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_launch_state",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"fontScale\":\"UICTContentSizeCategoryL\",\"diskUsage\":\"55,87 GB \\/ 494,38 GB (systemFree: 55,87 GB)\",\"accessibility\":{\"isVoiceOverEnabled\":false,\"isLargerTextEnabled\":true,\"isReduceMotionEnabled\":false,\"isButtonShapesEnabled\":false,\"isHearingDevicePaired\":false,\"isGuidedAccessEnabled\":false,\"isDifferentiateWithoutColorEnabled\":false,\"isOnOffSwitchLabelsEnabled\":false,\"isSpeakScreenEnabled\":false,\"isAssistiveTouchEnabled\":false,\"isInvertColorsEnabled\":false,\"isSwitchControlEnabled\":false,\"isDarkerSystemColorsEnabled\":false,\"isClosedCaptioningEnabled\":false,\"isShakeToUndoEnabled\":true,\"isGrayscaleEnabled\":false,\"isReduceTransparencyEnabled\":false,\"isBoldTextEnabled\":false,\"isSpeakSelectionEnabled\":false,\"isMonoAudioEnabled\":false,\"isVideoAutoplayEnabled\":true,\"isZoomed\":false,\"isPrefersCrossFadeTransitionsEnabled\":false},\"systemVersion\":\"18.3.1\",\"notificationsAuthorization\":\"notDetermined\",\"photosAuthorization\":\"authorized_unlimited\",\"type\":\"classic\",\"version\":\"856\",\"firstInstallDeviceId\":\"4A6FB8F7-62AA-477C-A3BD-E6C2390AB66B\",\"didCrashOnPreviousExecution\":false,\"currentDeviceId\":\"4A6FB8F7-62AA-477C-A3BD-E6C2390AB66B\",\"interfaceStyle\":\"light\",\"locale\":\"fr-FR\",\"modelName\":\"arm64\",\"systemName\":\"iOS\"}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_feature_abTriggered",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"featureId\":\"brand_logo_header\",\"variantId\":\"DEFAULT\"}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "app_feature_abTriggered",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"featureId\":\"first_tab\",\"variantId\":\"FEED-3\"}",
            buildNumber: "854"
          ),
          .init(
            deviceId: "62b3bbf3-60e9-440c-bd91-04d03c2eb94d",
            name: "ui_generic_screenEnter",
            timestamp: Date.now.timeIntervalSince1970,
            params: "{\"screen\":\"Feed\",\"parameters\":{}}",
            buildNumber: "854"
          )
        ]
      ),
      reducer: ConsoleFeature.init
    )
  )
}
#endif
