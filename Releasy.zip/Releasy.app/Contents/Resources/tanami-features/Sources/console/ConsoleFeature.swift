//
//  ConsoleFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import Foundation
import LogService
import SystemService

@Reducer
public struct ConsoleFeature: Sendable {
  @Dependency(\.console.simCtl) var logger
  @Dependency(\.log) var log
  @Dependency(\.systemClient) var system

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    var isLoading: Bool
    var logs: [ConsoleLog]
    var shouldCloseWindow: Bool
    var logDetails: String
    var isBroadcasting: Bool

    var deviceIds: [String] {
     Array(Set(logs.map(\.deviceId)))
    }

    /// Initializes the state with navigation path.
    init(isLoading: Bool, isBroadcasting: Bool, logs: [ConsoleLog], logDetails: String, shouldCloseWindow: Bool) {
      self.isLoading = isLoading
      self.isBroadcasting = isBroadcasting
      self.logs = logs
      self.shouldCloseWindow = shouldCloseWindow
      self.logDetails = logDetails
    }

    /// Provides an initial state.
    public static func initial(logs: [ConsoleLog] = []) -> State {
      .init(isLoading: true, isBroadcasting: false, logs: logs, logDetails: "{}", shouldCloseWindow: false)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case logReceived(ConsoleLog)
      case startBroadcast
      case stopBroadcast
      case toggleBroadcast(Bool)
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case logRowTapped(UUID)
      case state
      case task
      case toggleButtonTapped
      case trashButtonTapped
      case windowWillClose
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
