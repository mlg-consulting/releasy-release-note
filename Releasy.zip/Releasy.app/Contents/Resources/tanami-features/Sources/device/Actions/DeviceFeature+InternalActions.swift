//
//  DeviceFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension DeviceFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didLoadDevices(let devices):
      state.isLoading = false
      state.devices = devices
      return .none
    }
  }
}
