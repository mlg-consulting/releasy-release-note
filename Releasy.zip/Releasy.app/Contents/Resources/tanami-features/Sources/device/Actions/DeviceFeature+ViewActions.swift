//
//  DeviceFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import DeviceKit

extension DeviceFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .copyIdentifierButtonTapped(let id):
      return .run { _ in system.addToPasteboard(id) }
    case .copyNameButtonTapped(let name):
      return .run { _ in system.addToPasteboard(name) }
    case .loadDevices:
      state.isLoading = true
      return .run { send in
        await device.loadDevices()
        let devices = await device.devices()
        await send(.internal(.didLoadDevices(devices)))
      } catch: { error, send in
        logger.log(level: .error, method: "loadDevices", message: "error=[\(error)]")
      }
    case .task:
      return .none
    }
  }
}
