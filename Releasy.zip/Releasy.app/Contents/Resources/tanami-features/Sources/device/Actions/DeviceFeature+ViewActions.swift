//
//  DeviceFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import DeviceKit

extension DeviceFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .copyIdentifierButtonTapped(let id):
      system.addToPasteboard(id)
      return .none
    case .copyNameButtonTapped(let name):
      system.addToPasteboard(name)
      return .none
    case .loadDevices:
      state.isLoading = true
      return .run { send in
        await device.loadDevices()
        let devices = await device.devices()
        await send(.internal(.didLoadDevices(devices)))
      } catch: { error, send in
        logger.log(level: .error, method: "loadDevices", message: "error=[\(error)]")
      }
    case .task:
      return .none
    }
  }
}
