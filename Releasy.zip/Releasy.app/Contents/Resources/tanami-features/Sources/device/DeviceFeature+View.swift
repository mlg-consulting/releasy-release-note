//
//  DeviceFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import DeviceKit
import Sharing
import SwiftUI
import TanamiDesignSystem

@ViewAction(for: DeviceFeature.self)
public struct DeviceFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Environment(\.scenePhase) private var scenePhase
  @Bindable public var store: StoreOf<DeviceFeature>

  public init(store: StoreOf<DeviceFeature>) {
    self.store = store
  }

  public var body: some View {
    DevicePicker(title: L10n.menuDeviceSectionTitle, isLoading: store.isLoading) {
      VStack(spacing: designSystem.spacing(.xs)) {
        ForEach(store.devices) { device in
          DeviceRow(
            icon: { icon(for: device.connection) },
            name: device.name,
            runtime: String(describing: device.runtime),
            menu: { menu(for: device) }
          )
          .menuBackgroundOnHover(color: .primary.opacity(0.1))
          .contextMenu { menuOptions(for: device) }
          .help(device.connection.description)
        }
      }
    }
    .onChange(of: scenePhase) { oldValue, newValue in
      if newValue == .active {
        Task(priority: .userInitiated) { send(.loadDevices) }
      }
    }
  }
}

extension DeviceFeatureView {
  private func icon(for connection: Connection) -> some View {
    designSystem.icon(.appsIphone)
      .font(.body)
      .frame(width: 32.0, height: 32.0)
      .background(Color.gray.opacity(0.4))
      .cornerRadius(.infinity)
  }

  @ViewBuilder
  private func menu(for device: Device) -> some View {
    Menu {
      menuOptions(for: device)
    } label: {
      designSystem.icon(device.connection.symbol)
        .padding(.trailing, designSystem.spacing(.xs))
        .foregroundStyle(.secondary)
    }
    .buttonStyle(.plain)
  }

  @ViewBuilder
  private func menuOptions(for device: Device) -> some View {
    Button(L10n.menuDeviceCopyIdentifierLabel) { send(.copyIdentifierButtonTapped(device.id)) }
    Button(L10n.menuDeviceCopyNameLabel) { send(.copyNameButtonTapped(device.name)) }
  }
}

extension Platform {
  var symbol: DesignSystem.Symbols {
    switch self {
    case .iOS: .appsIphone
    case .watchOS: .applewatchWatchface
    case .tvOS: .appletv
    case .visionOS: .visionPro
    default: .exclamationmarkCircle
    }
  }
}

extension Connection {
  var symbol: DesignSystem.Symbols {
    switch self {
    case .network: .wifi
    case .physical: .cableConnectorHorizontal
    case .internal: .circle
    }
  }

  var description: String {
    switch self {
    case .network: L10n.deviceConnectionWifiLabel
    case .physical: L10n.deviceConnectionUsbLabel
    default: ""
    }
  }
}

#if DEBUG
#Preview {
  DeviceFeatureView(store: Store(initialState: .initial, reducer: DeviceFeature.init))
}
#endif
