//
//  SimulatorFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountTab
import AppsTab
import ComposableArchitecture
import DevicesTab
import DeviceKit
import Foundation
import GeneralTab
import MediaTab
import Sharing

@Reducer
public struct SimulatorFeature: Sendable {
  @Dependency(\.console.simCtl) var logger
  @Dependency(\.deviceClient) var device
  @Dependency(\.systemClient) var system

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.mockMedia) var mockMedia
    @Shared(.pinnedSimulators) var pinnedSimulators

    var simulators: [Simulator]
    var isLoading: Bool

    var selectedSimulatorIds: [Simulator.ID]

    var selectedSimulator: [Simulator] {
      simulators.filter({ pinnedSimulators.contains($0.id) }).sorted(by: >)
    }

    var launchSimulatorsEnabled: Bool {
      !selectedSimulatorIds.isEmpty
    }

    /// Initializes the state with navigation path.
    init(simulators: [Simulator], selectedSimulatorIds: [Simulator.ID], isLoading: Bool) {
      self.simulators = simulators
      self.selectedSimulatorIds = selectedSimulatorIds
      self.isLoading = isLoading
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(simulators: [], selectedSimulatorIds: [], isLoading: true)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case didLoadSimulators([Simulator])
      case didLoadMedia
      case selectedSimulatorStartDidFinish
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case copyIdentifierButtonTapped(Simulator.ID)
      case copyNameButtonTapped(String)
      case deselectAllSimulatorButtonTapped
      case loadMediaButtonTapped(Simulator.ID)
      case loadSimulators
      case revealSimulatorButtonTapped(Simulator.ID)
      case startSelectedSimulatorMenuTapped
      case startSimulatorButtonTapped(Simulator.ID)
      case simulatorButtonTapped(Simulator.ID)
      case task
      case unpinSimulatorButtonTapped(Simulator.ID)
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
