//
//  LaunchFromURLPanel.swift
//  tanami-features
//
//  Created by Loïc Griffié on 22/07/2025.
//

import ArtifactService
import Dependencies
import DeviceKit
import SwiftUI
import TanamiFoundation
import TanamiDesignSystem

struct LaunchFromURLPanel: View {
  @Dependency(\.artifact) var artifact
  @Dependency(\.designSystem) var designSystem
  @Environment(\.colorScheme) private var colorScheme
  @Environment(\.customPanelPresentation) private var customPanelPresentation

  @State private var text = ""

  let simulator: Simulator

  var body: some View {
    VStack(spacing: designSystem.spacing(.s)) {
      TextField("URL", text: $text, prompt: Text(L10n.artifactUrlLabel))
        .textFieldStyle(.plain)
        .font(.title)
        .foregroundColor(colorScheme == .dark ? .white : .primary)

      HStack(alignment: .firstTextBaseline) {
        Spacer()
        Button(L10n.artifactInstallCancelButtonLabel) {
          customPanelPresentation?.dismiss()
          text = ""
        }
        Button(L10n.artifactInstallLaunchButtonLabel) {
          if let url = URL(string: text) {
            text = ""
            Task(priority: .userInitiated) { try await artifact.install(url, simulator, .simulator) }
          }
          customPanelPresentation?.dismiss()
        }
        .keyboardShortcut(.defaultAction)
        .disabled(text.isEmpty)
      }
    }
    .frame(width: 600)
    .padding()
    .onExitCommand {
      if text.isEmpty {
        customPanelPresentation?.dismiss()
      } else {
        text = ""
      }
    }
  }
}
