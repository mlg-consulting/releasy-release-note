//
//  SimulatorFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import DeviceKit
import SettingsRouter
import Sharing
import SwiftUI
import TanamiDesignSystem

@ViewAction(for: SimulatorFeature.self)
public struct SimulatorFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Shared(.selectedTab) var selectedTab

  @Environment(\.scenePhase) private var scenePhase
  @Bindable public var store: StoreOf<SimulatorFeature>

  public init(store: StoreOf<SimulatorFeature>) {
    self.store = store
  }

  public var body: some View {
    DevicePicker(title: L10n.menuSimulatorSectionTitle, action: { settings }, isLoading: store.isLoading) {
      VStack(spacing: designSystem.spacing(.xs)) {
        ForEach(store.selectedSimulator) { simulator in
          DeviceRow(
            icon: { icon(for: simulator.state) },
            name: simulator.name,
            runtime: String(describing: simulator.runtime),
            menu: {
              if store.selectedSimulatorIds.contains(simulator.id) {
                designSystem.icon(.checkmarkCircleFill).foregroundStyle(theme.color(.success))
              } else {
                menu(for: simulator)
              }
            },
            onTapped: { send(.simulatorButtonTapped(simulator.id)) },
            onDoubleTapped: { send(.startSimulatorButtonTapped(simulator.id)) }
          )
          .menuBackgroundOnHover(color: .primary.opacity(0.1))
          .contextMenu { menuOptions(for: simulator) }
          .help(simulator.state.description)
        }
        VStack(alignment: .leading, spacing: .zero) {
          launch
          selected
        }
      }
    }
    .onChange(of: scenePhase) { oldValue, newValue in
      if newValue == .active {
        Task(priority: .userInitiated) { send(.loadSimulators) }
      }
    }
  }
}

extension SimulatorFeatureView {
  private var launch: some View {
    Button(action: { send(.startSelectedSimulatorMenuTapped) }) {
      Text(L10n.launchSelectedSimulatorButtonLabel)
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true, disabled: !store.launchSimulatorsEnabled))
  }

  private var settings: some View {
    Group {
      SettingsLink {
        Text(L10n.addSimulatorButtonLabel)
      }
      .buttonStyle(
        SettingsLinkActionButtonStyle {
          $selectedTab.withLock { $0 = .devices }
        }
      )
    }
    .buttonStyle(InlineButtonStyle())
  }

  private func icon(for status: DeviceState) -> some View {
    designSystem.icon(status.symbol)
      .font(.body)
      .frame(width: 32.0, height: 32.0)
      .background(status.color.opacity(0.4))
      .cornerRadius(.infinity)
  }

  private var selected: some View {
    Button(action: { send(.deselectAllSimulatorButtonTapped) }) {
      HStack {
        Text(L10n.menuSimulatorDeselectAllLabel)
        Spacer()
        if !store.selectedSimulatorIds.isEmpty {
          Text(L10n.menuSimulatorSelectedCount(store.selectedSimulatorIds.count))
            .foregroundStyle(.secondary)
        }
      }
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true, disabled: store.selectedSimulatorIds.isEmpty))
  }

  @ViewBuilder
  private func menu(for simulator: Simulator) -> some View {
    if !store.selectedSimulatorIds.contains(simulator.id) {
      Menu {
        menuOptions(for: simulator)
      } label: {
        designSystem.icon(.ellipsisCircle)
          .foregroundColor(.secondary)
      }
      .buttonStyle(.plain)
    }
  }

  @ViewBuilder
  private func menuOptions(for simulator: Simulator) -> some View {
    Button(simulator.state == .ready ? L10n.menuSimulatorStateRunningLabel : L10n.menuSimulatorStateIdleLabel) {
      send(.startSimulatorButtonTapped(simulator.id))
    }
    .disabled(simulator.state == .ready)
    Divider()
    Button(L10n.menuSimulatorCopyIdentifierLabel) { send(.copyIdentifierButtonTapped(simulator.id)) }
    Button(L10n.menuSimulatorCopyNameLabel) { send(.copyNameButtonTapped(simulator.name)) }
    Divider()
    Button(L10n.menuSimulatorRevealLabel) {
      send(.revealSimulatorButtonTapped(simulator.id))
    }
    .disabled(simulator.state == .idle)
    Divider()
    Button(L10n.menuSimulatorUnpinLabel) { send(.unpinSimulatorButtonTapped(simulator.id)) }
  }
}

extension Platform {
  var symbol: DesignSystem.Symbols {
    switch self {
    case .iOS: .appsIphone
    case .watchOS: .applewatchWatchface
    case .tvOS: .appletv
    case .visionOS: .visionPro
    default: .exclamationmarkCircle
    }
  }
}

extension DeviceState {
  var symbol: DesignSystem.Symbols {
    switch self {
    case .idle: .iphoneBadgeExclamationmark
    case .ready: .iphoneBadgePlay
    case .unknown: .iphoneSlash
    }
  }

  var color: Color {
    @Dependency(\.designSystem.theme) var theme
    return switch self {
    case .idle: theme.color(.warning)
    case .ready: theme.color(.success)
    case .unknown: theme.color(.error)
    }
  }

  var description: String {
    switch self {
    case .idle: L10n.simulatorStateIdle
    case .ready: L10n.simulatorStateReady
    case .unknown: L10n.simulatorStateUnknown
    }
  }
}

#if DEBUG
#Preview {
  SimulatorFeatureView(store: Store(initialState: .initial, reducer: SimulatorFeature.init))
}
#endif
