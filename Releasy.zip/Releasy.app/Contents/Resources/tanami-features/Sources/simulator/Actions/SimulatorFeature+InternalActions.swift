//
//  SimulatorFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension SimulatorFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didLoadSimulators(let simulators):
      state.isLoading = false
      state.simulators = simulators.filter { state.pinnedSimulators.contains($0.id) }
      return .none
    case .selectedSimulatorStartDidFinish:
      state.selectedSimulatorIds.removeAll()
      return .none
    case .startSimulator(let simulator):
      return .run { _ in
        try await simulator.boot()
      } catch: { error, send in
        logger.log(level: .error, method: "startSimulatorButtonTapped", message: "error=[\(error)]")
      }
    case .revealSimulator(let simulator):
      return .run { _ in
        try simulator.focus()
      } catch: { error, send in
        logger.log(level: .error, method: "revealSimulatorButtonTapped", message: "error=[\(error)]")
      }
    }
  }
}
