//
//  SimulatorFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture
import DeviceKit

extension SimulatorFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didLoadMedia:
      return .none
    case .didLoadSimulators(let simulators):
      state.isLoading = false
      state.simulators = simulators.filter { state.pinnedSimulators.contains($0.id) }
      return .none
    case .selectedSimulatorStartDidFinish:
      state.selectedSimulatorIds.removeAll()
      return .none
    }
  }
}
