//
//  SimulatorFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import DeviceKit
import Foundation

extension SimulatorFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .copyIdentifierButtonTapped(let id):
      system.addToPasteboard(id)
      return .none
    case .copyNameButtonTapped(let name):
      system.addToPasteboard(name)
      return .none
    case .deselectAllSimulatorButtonTapped:
      state.selectedSimulatorIds.removeAll()
      return .none
    case .loadMediaButtonTapped(let id):
      guard let simulator = state.simulators.first(where: { $0.id == id }) else { return .none }
      return .run { [media = state.mockMedia] send in
        if simulator.state == .idle {
          try await simulator.boot()
        } else {
          try simulator.focus()
        }
        try media.forEach { try simulator.addMedia($0.url) }
        // https://support.apple.com/fr-fr/guide/deployment/depece748c41/web
        let bundleIdentifier = "com.apple.mobileslideshow" // Photos Application
        try simulator.launch(application: .init(name: .none, url: .none, bundleIdentifier: bundleIdentifier))
        await send(.internal(.didLoadMedia))
      } catch: { error, send in
        logger.log(level: .error, method: "loadMedia", message: "error=[\(error)]")
      }
    case .revealSimulatorButtonTapped(let id):
      guard let simulator = state.simulators.first(where: { $0.id == id }) else { return .none }
      do {
        try simulator.focus()
      } catch {
        logger.log(level: .error, method: "revealSimulatorButtonTapped", message: "error=[\(error)]")
      }
      return .none
    case .startSimulatorButtonTapped(let id):
      guard let simulator = state.simulators.first(where: { $0.id == id }) else { return .none }
      return .run { send in
        if simulator.state == .idle {
          try await simulator.boot()
        } else {
          try simulator.focus()
        }
      } catch: { error, send in
        logger.log(level: .error, method: "startSimulatorButtonTapped", message: "error=[\(error)]")
      }
    case .startSelectedSimulatorMenuTapped:
      return .run { [simulators = state.selectedSimulators] send in
        for simulator in simulators {
          if simulator.state == .idle {
            try await simulator.boot()
          } else {
            try simulator.focus()
          }
        }
        await send(.internal(.selectedSimulatorStartDidFinish))
      } catch: { error, send in
        logger.log(level: .error, method: "startSelectedSimulatorMenuTapped", message: "error=[\(error)]")
      }
    case .simulatorButtonTapped(let id):
      if state.selectedSimulatorIds.contains(id) {
        state.selectedSimulatorIds.removeAll(where: { $0 == id})
      } else {
        state.selectedSimulatorIds.append(id)
      }
      return .none
    case .task:
      state.isLoading = true
      state.selectedSimulatorIds = Array(
        Set(state.selectedSimulatorIds).intersection(Set(state.pinnedSimulators))
      )
      return .run { send in
        await device.loadSimulators()
        let simulators = await device.simulators()
        await send(.internal(.didLoadSimulators(simulators)))
      } catch: { error, send in
        logger.log(level: .error, method: "loadSimulators", message: "error=[\(error)]")
      }
    case .unpinSimulatorButtonTapped(let id):
      state.$pinnedSimulators.withLock { $0.removeAll(where: { $0 == id }) }
      state.selectedSimulatorIds.removeAll(where: { $0 == id})
      return .none
    }
  }
}
