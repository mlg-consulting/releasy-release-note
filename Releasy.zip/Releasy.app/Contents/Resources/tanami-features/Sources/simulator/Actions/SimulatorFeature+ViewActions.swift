//
//  SimulatorFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import DeviceKit

extension SimulatorFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .copyIdentifierButtonTapped(let id):
      return .run { _ in await system.addToPasteboard(id) }
    case .copyNameButtonTapped(let name):
      return .run { _ in await system.addToPasteboard(name) }
    case .deselectAllSimulatorButtonTapped:
      state.selectedSimulatorIds.removeAll()
      return .none
    case .loadSimulators:
      state.isLoading = true
      return .run { send in
        await device.loadSimulators()
        let simulators = await device.simulators()
        await send(.internal(.didLoadSimulators(simulators)))
      } catch: { error, send in
        logger.log(level: .error, method: "loadSimulators", message: "error=[\(error)]")
      }
    case .revealSimulatorButtonTapped(let id):
      guard let simulator = state.simulators.first(where: { $0.id == id }) else { return .none }
      return .send(.internal(.revealSimulator(simulator)))
    case .startSimulatorButtonTapped(let id):
      guard let simulator = state.simulators.first(where: { $0.id == id }) else { return .none }
      return switch simulator.state {
      case .idle: .send(.internal(.startSimulator(simulator)))
      case .ready: .send(.internal(.revealSimulator(simulator)))
      case .unknown: .none
      }
    case .startSelectedSimulatorMenuTapped:
      return .run { [simulators = state.simulators] send in
        for simulator in simulators {
          switch simulator.state {
          case .idle: await send(.internal(.startSimulator(simulator)))
          case .ready: await send(.internal(.revealSimulator(simulator)))
          case .unknown: break
          }
        }
        await send(.internal(.selectedSimulatorStartDidFinish))
      }
    case .simulatorButtonTapped(let id):
      if state.selectedSimulatorIds.contains(id) {
        state.selectedSimulatorIds.removeAll(where: { $0 == id})
      } else {
        state.selectedSimulatorIds.append(id)
      }
      return .none
    case .task:
      return .none
    case .unpinSimulatorButtonTapped(let id):
      state.$pinnedSimulators.withLock { $0.removeAll(where: { $0 == id }) }
      state.selectedSimulatorIds.removeAll(where: { $0 == id})
      return .none
    }
  }
}
