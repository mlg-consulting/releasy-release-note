// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Add Simulators
  internal static let addSimulatorButtonLabel = L10n.tr("Localizable", "add_simulator_button_label", fallback: "Add Simulators")
  /// Launch Simulators…
  internal static let launchSelectedSimulatorButtonLabel = L10n.tr("Localizable", "launch_selected_simulator_button_label", fallback: "Launch Simulators…")
  /// Add Photos…
  internal static let menuSimulatorAddPhotoLabel = L10n.tr("Localizable", "menu_simulator_add_photo_label", fallback: "Add Photos…")
  /// Copy Identifier
  internal static let menuSimulatorCopyIdentifierLabel = L10n.tr("Localizable", "menu_simulator_copy_identifier_label", fallback: "Copy Identifier")
  /// Copy Name
  internal static let menuSimulatorCopyNameLabel = L10n.tr("Localizable", "menu_simulator_copy_name_label", fallback: "Copy Name")
  /// Deselect All
  internal static let menuSimulatorDeselectAllLabel = L10n.tr("Localizable", "menu_simulator_deselect_all_label", fallback: "Deselect All")
  /// Load Photos…
  internal static let menuSimulatorLoadPhotoLabel = L10n.tr("Localizable", "menu_simulator_load_photo_label", fallback: "Load Photos…")
  /// Reveal Device Window
  internal static let menuSimulatorRevealLabel = L10n.tr("Localizable", "menu_simulator_reveal_label", fallback: "Reveal Device Window")
  /// Simulators
  internal static let menuSimulatorSectionTitle = L10n.tr("Localizable", "menu_simulator_section_title", fallback: "Simulators")
  /// %d Selected
  internal static func menuSimulatorSelectedCount(_ p1: Int) -> String {
    return L10n.tr("Localizable", "menu_simulator_selected_count", p1, fallback: "%d Selected")
  }
  /// Start
  internal static let menuSimulatorStateIdleLabel = L10n.tr("Localizable", "menu_simulator_state_idle_label", fallback: "Start")
  /// Running
  internal static let menuSimulatorStateRunningLabel = L10n.tr("Localizable", "menu_simulator_state_running_label", fallback: "Running")
  /// Unpin
  internal static let menuSimulatorUnpinLabel = L10n.tr("Localizable", "menu_simulator_unpin_label", fallback: "Unpin")
  /// Stopped
  internal static let simulatorStateIdle = L10n.tr("Localizable", "simulator_state_idle", fallback: "Stopped")
  /// Running
  internal static let simulatorStateReady = L10n.tr("Localizable", "simulator_state_ready", fallback: "Running")
  /// Not Available
  internal static let simulatorStateUnknown = L10n.tr("Localizable", "simulator_state_unknown", fallback: "Not Available")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
