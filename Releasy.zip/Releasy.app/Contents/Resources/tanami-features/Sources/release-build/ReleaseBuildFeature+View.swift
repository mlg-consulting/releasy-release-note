//
//  ReleaseBuildFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Build
import ComposableArchitecture
import ReleaseService
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

extension ReleaseBuildFeatureView {
  private enum UI {
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
    static let spacing: CGFloat = 32.0
  }
}

@ViewAction(for: ReleaseBuildFeature.self)
public struct ReleaseBuildFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @Bindable public var store: StoreOf<ReleaseBuildFeature>

  public init(store: StoreOf<ReleaseBuildFeature>) {
    self.store = store
  }

  public var body: some View {
    ZStack(alignment: .top) {
      VStack(spacing: designSystem.spacing(.xs)) {
        apps
        header
        form
        toolbar
      }
      .padding(UI.padding)
      .frame(width: 600)
      .frame(minHeight: 300, maxHeight: 400)
      .scrollContentBackground(.hidden)
      .fixedSize()
      .task { send(.loadWorkflows) }

      errorMessage
    }
    .onChange(of: store.shouldCloseWindow) { oldValue, newValue in
      if newValue {
        Task {
          try await Task.sleep(for: .seconds(5))
          customWindowPresentation?.dismiss()
        }
      }
    }
  }
}

extension ReleaseBuildFeatureView {
  @ViewBuilder
  private var errorMessage: some View {
    if let message = store.errorMessage {
      ErrorMessage(message)
    }
  }

  private var header: some View {
    Text(L10n.newReleaseBuildTitle)
      .font(.largeTitle)
      .foregroundColor(.primary)
  }

  private var apps: some View {
    HStack(spacing: designSystem.spacing(.xs)) {
      ForEach(store.appStoreConnectApps.filter({ store.appIds.contains($0.id) }).sorted()) { app in
        AsyncImage(url: app.iconUrl) { image in
          image.resizable()
        } placeholder: {
          Color.gray
        }
        .frame(width: 32.0, height: 32.0)
        .mask(RoundedRectangle(cornerRadius: designSystem.radius(.s)))
      }
    }
  }

  private var form: some View {
    Form {
      Section {
        gitReferences
      }
    }
    .formStyle(.grouped)
  }

  @ViewBuilder
  private var gitReferences: some View {
    HStack(alignment: .center) {
      Text(L10n.gitReferenceBranchSelectTitle).font(.headline)
      Spacer()
      Picker(L10n.branchesTitle, selection: $store.currentGitReferenceId.sending(\.view.currentGitReferenceIdChanged)) {
        ForEach(store.gitReferences) { gitReference in
          Text(gitReference.name ?? "--").tag(gitReference.id)
        }
      }
      .labelsHidden()
    }
  }

  private var toolbar: some View {
    HStack {
      if !store.isLoading {
        cancel
      }
      Spacer()
      if store.shouldCloseWindow {
        done
      } else {
        create
      }
    }
    .padding(designSystem.spacing(.m))
  }

  @ViewBuilder
  private var cancel: some View {
    Button(L10n.cancelNewReleaseButtonLabel) {
      customWindowPresentation?.dismiss()
    }
    .tint(.secondary)
    .controlSize(.large)
  }

  private var create: some View {
    Button(L10n.createNewReleaseButtonLabel) {
      send(.createReleaseBuildButtonTapped)
    }
    .controlSize(.large)
    .keyboardShortcut(.return)
    .disabled(!store.isReleaseValid)
  }

  private var done: some View {
    Button(action: { customWindowPresentation?.dismiss() }) {
      HStack(spacing: designSystem.spacing(.xxs)) {
        designSystem.icon(.checkmark)
        Text(L10n.createNewReleaseSuccessLabel)
      }
    }
    .buttonStyle(.borderedProminent)
    .tint(theme.color(.success))
    .controlSize(.large)
  }
}

#if DEBUG
#Preview() {
  ReleaseBuildFeatureView(store: Store(initialState: .initial(appIds: []), reducer: ReleaseBuildFeature.init))
}
#endif
