//
//  ReleaseBuildFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppsTab
import Build
import ComposableArchitecture
import Console
import Dependencies
import Foundation
import ReleaseService
import Sharing
import TanamiFoundation
import Workflow

@Reducer
public struct ReleaseBuildFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.console.app) var logger
  @Dependency(\.mainQueue) var mainQueue
  @Dependency(\.release) var releaseClient

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectApps) var appStoreConnectApps
    @Shared(.recentBuilds) var recentBuilds

    let appIds: [AppStoreConnect.Application.ID]
    var repository: AppStoreConnect.ScmRepository? = .none
    var workflows: [Workflow] = []
    var gitReferences: [AppStoreConnect.ScmGitReference] = []
    var currentGitReferenceId: AppStoreConnect.ScmGitReference.ID? = .none

    var isLoading: Bool
    var errorMessage: String?
    var shouldCloseWindow: Bool

    var isReleaseValid: Bool { !isLoading && currentGitReferenceId != .none }

    init(
      appIds: [AppStoreConnect.Application.ID],
      isLoading: Bool,
      errorMessage: String?,
      shouldCloseWindow: Bool
    ) {
      self.appIds = appIds
      self.isLoading = isLoading
      self.errorMessage = errorMessage
      self.shouldCloseWindow = shouldCloseWindow
    }

    /// Provides an initial state.
    public static func initial(appIds: [AppStoreConnect.Application.ID], isLoading: Bool = false) -> State {
      .init(
        appIds: appIds,
        isLoading: isLoading,
        errorMessage: .none,
        shouldCloseWindow: false
      )
    }

    var applications: [AppStoreConnect.Application] {
      appStoreConnectApps.filter { appIds.contains($0.id) }.sorted()
    }

    var currentGitReference: AppStoreConnect.ScmGitReference? {
      gitReferences.first(where: { $0.id == currentGitReferenceId })
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case buildsDidStart([BuildRun])
      case error(String)
      case releaseBuildDidSuccess
      case gitReferencesDidLoad([AppStoreConnect.ScmGitReference])
      case repositoryDidLoad(AppStoreConnect.ScmRepository)
      case workflowDidLoad([Workflow])
      case workflowDidFail(String)
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case createReleaseBuildButtonTapped
      case currentGitReferenceIdChanged(AppStoreConnect.ScmGitReference.ID?)
      case hideErrorMessage
      case loadGitReferences
      case loadRepository
      case loadWorkflows
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
