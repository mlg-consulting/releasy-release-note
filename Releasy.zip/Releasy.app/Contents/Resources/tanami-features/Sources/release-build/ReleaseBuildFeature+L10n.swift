// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Branches
  internal static let branchesTitle = L10n.tr("Localizable", "branches_title", fallback: "Branches")
  /// Cancel
  internal static let cancelNewReleaseButtonLabel = L10n.tr("Localizable", "cancel_new_release_button_label", fallback: "Cancel")
  /// Create Build Release…
  internal static let createNewReleaseButtonLabel = L10n.tr("Localizable", "create_new_release_button_label", fallback: "Create Build Release…")
  /// Done
  internal static let createNewReleaseSuccessLabel = L10n.tr("Localizable", "create_new_release_success_label", fallback: "Done")
  /// Select branch for release
  internal static let gitReferenceBranchSelectTitle = L10n.tr("Localizable", "git_reference_branch_select_title", fallback: "Select branch for release")
  /// Create Build For Release
  internal static let newReleaseBuildTitle = L10n.tr("Localizable", "new_release_build_title", fallback: "Create Build For Release")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
