//
//  ReleaseBuildFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Build
import ComposableArchitecture
#if canImport(FoundationModels)
import FoundationModels
#endif
import ReleaseService
import TanamiFoundation

extension ReleaseBuildFeature {
  public struct BuildRun: Equatable, Sendable {
    let applicationId: AppStoreConnect.Application.ID
    let workflowId: AppStoreConnect.CIWorkflow.ID
    let gitReferenceId: AppStoreConnect.ScmGitReference.ID
    let buildRun: AppStoreConnect.CIBuildRun?
  }
  public struct Workflow: Equatable, Sendable {
    let applicationId: AppStoreConnect.Application.ID
    let ciWorkflows: [AppStoreConnect.CIWorkflow]
  }
}

extension ReleaseBuildFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .createReleaseBuildButtonTapped:
      guard let gitReferenceId = state.currentGitReferenceId else { return .none }
      state.isLoading = true
      return .run { [workflows = state.workflows] send in
        let buildRuns = try await startBuild(for: workflows, with: gitReferenceId)
        await send(.internal(.buildsDidStart(buildRuns)))
      }
    case .currentGitReferenceIdChanged(let gitReferenceId):
      guard let gitReferenceId, gitReferenceId != state.currentGitReferenceId else { return .none }
      state.currentGitReferenceId = gitReferenceId
      return .none
    case .hideErrorMessage:
      state.errorMessage = .none
      state.isLoading = false
      return .none
    case .loadGitReferences:
      guard let repositoryId = state.repository?.id else { return .none }
      return .run { send in
        let gitReferences = try await appStore.repository.gitReferences(repositoryId)
        await send(.internal(.gitReferencesDidLoad(gitReferences)))
      }
    case .loadRepository:
      return .run { [workflows = state.workflows] send in
        guard let repository = try await loadRepository(for: workflows.flatMap(\.ciWorkflows)) else { return }
        await send(.internal(.repositoryDidLoad(repository)))
      }
    case .loadWorkflows:
      state.isLoading = true
      return .run { [application = state.applications] send in
        let workflows = try await loadWorkflows(for: application)
        await send(.internal(.workflowDidLoad(workflows)))
      } catch: { error, send in
        await send(.internal(.workflowDidFail(error.localizedDescription)))
      }
      .debounce(id: Cancellable.prePreleases, for: .milliseconds(250), scheduler: mainQueue)
    }
  }

  private func startBuild(
    for workflows: [Workflow],
    with gitReferenceId: AppStoreConnect.ScmGitReference.ID
  ) async throws -> [BuildRun] {
    try await withThrowingTaskGroup { group in
      for workflow in workflows {
        for ciWorkflow in workflow.ciWorkflows {
          group.addTask {
            let buildRun = try await appStore.ci.startGitReference(ciWorkflow.id, gitReferenceId)
            return BuildRun(
              applicationId: workflow.applicationId,
              workflowId: ciWorkflow.id,
              gitReferenceId: gitReferenceId,
              buildRun: buildRun
            )
          }
        }
      }

      var buildRuns: [BuildRun] = .init()
      for try await buildRun in group.compactMap({ $0 }) {
        buildRuns.append(buildRun)
      }
      return buildRuns
    }
  }

  private func loadRepository(
    for worflows: [AppStoreConnect.CIWorkflow]
  ) async throws -> AppStoreConnect.ScmRepository? {
    try await withThrowingTaskGroup { group in
      for worflow in worflows {
        group.addTask {
          try await appStore.ci.repository(worflow.id)
        }
      }

      var repositories: Set<AppStoreConnect.ScmRepository> = .init()
      for try await repository in group.compactMap({ $0 }) {
        repositories.insert(repository)
      }
      return repositories.first
    }
  }

  private func loadWorkflows(for applications: [AppStoreConnect.Application]) async throws -> [Workflow] {
    try await withThrowingTaskGroup { group in
      for application in applications {
        guard let ciProductId = application.ciProductId else { continue }
        group.addTask {
          let ciWorkflows = try await appStore.ci.workflows(ciProductId).filter {
            $0.isEnabled &&
            $0.actions.compactMap(\.audience)
              .filter({ AppStoreConnect.Build.AudienceType.allCases.contains($0) })
              .isEmpty == false
          }
          return Workflow(applicationId: application.id, ciWorkflows: ciWorkflows)
        }
      }

      var workflows: [Workflow] = .init()
      for try await ciWorkflow in group.compactMap({ $0 }) {
        workflows.append(ciWorkflow)
      }
      return workflows
    }
  }
}

extension ReleaseBuildFeature {
  enum Cancellable {
    case prePreleases
  }
}
