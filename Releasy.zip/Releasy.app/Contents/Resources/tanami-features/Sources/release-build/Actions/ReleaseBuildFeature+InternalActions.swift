//
//  ReleaseBuildFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture
import TanamiFoundation
import Workflow

extension ReleaseBuildFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .buildsDidStart(let builds):
      state.isLoading = false
      state.$recentBuilds.withLock { recentBuilds in
        for build in builds {
          guard let buildRunId = build.buildRun?.id else { continue }
          _ = recentBuilds.updateOrAppend(
            RecentBuild(
              applicationId: build.applicationId,
              buildRunId: buildRunId,
              gitReferenceId: build.gitReferenceId,
              sourceBranchOrTag: state.currentGitReference?.name,
              workflowId: build.workflowId
            )
          )
        }
      }
      return .send(.internal(.releaseBuildDidSuccess))
    case .error(let message):
      state.errorMessage = message
      return .run { send in
        try? await Task.sleep(for: .seconds(3))
        await send(.view(.hideErrorMessage), animation: .bouncy(duration: 0.15))
      }
    case .gitReferencesDidLoad(let gitReferences):
      state.isLoading = false
      state.gitReferences = gitReferences
        .filter({ $0.isDeleted == false && $0.kind == .branch && $0.canonicalName?.contains("release/") == true })
        .sorted(by: >)
      state.currentGitReferenceId = state.gitReferences.first?.id
      return .none
    case .repositoryDidLoad(let repository):
      state.repository = repository
      return .send(.view(.loadGitReferences))
    case .releaseBuildDidSuccess:
      state.shouldCloseWindow = true
      return .none
    case .workflowDidLoad(let workflows):
      state.workflows = workflows
      return .send(.view(.loadRepository))
    case .workflowDidFail(let message):
      state.isLoading = false
      state.errorMessage = message
      return .none
    }
  }
}
