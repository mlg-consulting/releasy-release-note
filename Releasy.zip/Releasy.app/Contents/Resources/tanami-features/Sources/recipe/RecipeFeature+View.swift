//
//  RecipeFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import SwiftUI
import ProviderService
import TanamiDesignSystem
import TanamiFoundation

extension RecipeFeatureView {
  private enum UI {
    static let iconSize: CGSize = .init(width: 64.0, height: 64.0)
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
  }
}

@ViewAction(for: RecipeFeature.self)
public struct RecipeFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @Bindable public var store: StoreOf<RecipeFeature>

  public init(store: StoreOf<RecipeFeature>) {
    self.store = store
  }

  public var body: some View {
    ZStack(alignment: .top) {
      VStack(spacing: designSystem.spacing(.xs)) {
        app
        form
        toolbar
      }
      .padding(UI.padding)
      .frame(width: 600)
      .frame(minHeight: 500, maxHeight: 700)
      .scrollContentBackground(.hidden)
      .scrollDisabled(true)
      .fixedSize()

      errorMessage
    }
    .onChange(of: store.shouldCloseWindow) { oldValue, newValue in
      if newValue {
        customWindowPresentation?.dismiss()
      }
    }
  }
}

extension RecipeFeatureView {
  @ViewBuilder
  private var errorMessage: some View {
    if let message = store.errorMessage {
      ErrorMessage(message)
    }
  }

  @ViewBuilder
  private var app: some View {
    if let app = store.currentApplication {
      VStack(spacing: designSystem.spacing(.xs)) {
        AsyncImage(url: app.iconUrl) { image in
          image.resizable()
        } placeholder: {
          Color.gray
        }
        .frame(width: UI.iconSize.width, height: UI.iconSize.height)
        .mask(RoundedRectangle(cornerRadius: designSystem.radius(.m)))
        Text(app.name)
          .font(.largeTitle)
          .foregroundColor(.primary)
        Text(L10n.configureTitle)
          .font(.body)
          .foregroundColor(.secondary)
      }
    }
  }

  private var provider: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.providerPickerTitle)
        .font(.headline)
      Spacer()
      Picker(L10n.providerPickerTitle, selection: $store.provider.sending(\.view.providerWillChange)) {
        ForEach([RecipeFeature.Provider.xcodeCloud], id: \.self) { provider in
          Text(provider.description)
            .tag(provider)
        }
      }
      .labelsHidden()
    }
  }

  private var platform: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.platformPickerTitle)
        .font(.headline)
      Spacer()
      Picker(L10n.platformPickerTitle, selection: $store.platform) {
        ForEach(AppStoreConnect.Platform.available, id: \.self) { platform in
          Text(platform.description)
            .tag(platform)
        }
      }
      .labelsHidden()
    }
  }

  private var destination: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.destinationPickerTitle)
        .font(.headline)
      Spacer()
      Picker(L10n.destinationPickerTitle, selection: $store.destination) {
        ForEach(Formula.Destination.allCases, id: \.self) { destination in
          Text(destination.description)
            .tag(destination)
        }
      }
      .labelsHidden()
    }
  }

  @ViewBuilder
  private var configuration: some View {
    switch store.provider {
    case .bitrise: bitrise
    case .http: http
    case .xcodeCloud: EmptyView()
    }
  }

  @ViewBuilder
  private var bitrise: some View {
    CustomTextField($store.appSlug, placeholder: L10n.bitriseAppPlaceholder, prompt: L10n.bitriseAppPrompt)
    CustomTextField($store.buildSlug, placeholder: L10n.bitriseBuildPlaceholder, prompt: L10n.bitriseBuildPrompt)
    CustomTextField($store.artifactSlug, placeholder: L10n.bitriseArtifactPlaceholder, prompt: L10n.bitriseArtifactPrompt)
  }

  @ViewBuilder
  private var http: some View {
    CustomTextField($store.uri, placeholder: L10n.httpUrlPlaceholder, prompt: L10n.httpUrlPrompt)
  }

  private var form: some View {
    Form {
      Section {
        provider
      }
      Section {
        platform
        destination
      }
      Section {
        configuration
      }
    }
    .formStyle(.grouped)
    .task { send(.task) }
  }

  private var toolbar: some View {
    VStack(spacing: designSystem.spacing(.s)) {
      Divider()
      HStack {
        Button(L10n.cancelRecipeButtonLabel, action: { send(.cancelButtonTapped) })
        Spacer()
        Button(L10n.saveRecipeButtonLabel, action: { send(.saveButtonTapped) })
          .buttonStyle(.borderedProminent)
          .disabled(!store.configurationIsValid)
      }
    }
    .padding(designSystem.spacing(.m))
  }
}

extension Formula.Destination {
  var description: String {
    switch self {
    case .any: L10n.destinationAnyLabel
    case .device: L10n.destinationDeviceLabel
    case .simulator: L10n.destinationSimulatorLabel
    }
  }
}

extension AppStoreConnect.Platform {
  public static var available: [Self] {
    [.iOS]
  }

  var description: String {
    switch self {
    case .iOS: L10n.platformIosLabel
    case .macOS: L10n.platformMacosLabel
    case .tvOS: L10n.platformTvosLabel
    case .visionOS: L10n.platformVisionosLabel
    case .watchOS: L10n.platformWatchOsLabel
    }
  }
}

#if DEBUG
#Preview {
  RecipeFeatureView(
    store: Store(
      initialState: .initial(appId: AppStoreConnect.Application.mock.id),
      reducer: RecipeFeature.init
    )
  )
}
#endif
