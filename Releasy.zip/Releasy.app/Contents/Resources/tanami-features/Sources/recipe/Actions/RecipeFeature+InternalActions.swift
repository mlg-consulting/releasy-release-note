//
//  RecipeFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension RecipeFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .error(let message):
      state.errorMessage = message
      return .run { send in
        try? await Task.sleep(for: .seconds(3))
        await send(.view(.hideErrorMessage), animation: .bouncy(duration: 0.15))
      }
    case .recipeDidLoad(let recipe):
      switch recipe.provider {
      case .bitrise(let app, let build, let artifact):
        state.provider = .bitrise
        state.appSlug = app
        state.buildSlug = build
        state.artifactSlug = artifact
      case .http(let url):
        state.provider = .http
        state.uri = url.absoluteString
      case .xcodeCloud:
        state.provider = .xcodeCloud
      }
      state.platform = recipe.platform
      state.destination = recipe.destination
      return .none
    case .recipeDidSave:
      state.shouldCloseWindow = true
      return .none
    }
  }
}
