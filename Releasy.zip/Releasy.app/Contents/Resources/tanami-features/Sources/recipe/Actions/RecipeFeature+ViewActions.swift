//
//  RecipeFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Foundation
import TanamiFoundation
import TanamiServices

extension RecipeFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .cancelButtonTapped:
      state.shouldCloseWindow = true
      return .none
    case .hideErrorMessage:
      state.errorMessage = .none
      state.isLoading = false
      return .none
    case .providerWillChange(let provider):
      guard provider != state.provider else { return .none }
      state.provider = provider
      state.appSlug = ""
      state.buildSlug = ""
      state.artifactSlug = ""
      state.uri = ""
      return .none
    case .saveButtonTapped:
      guard let provider = provider(state: state) else {
        return .send(.internal(.error(L10n.genericErrorMessageLabel)))
      }
      let recipe = Formula(
        appId: state.appId,
        name: "",
        provider: provider,
        platform: state.platform,
        destination: state.destination
      )
      return .run { send in
        await recipeClient.save(recipe)
        await send(.internal(.recipeDidSave))
      }
    case .task:
      return .run { [appId = state.appId] send in
        guard let recipe = await recipeClient.recipe(appId) else { return }
        await send(.internal(.recipeDidLoad(recipe)))
      }
    }
  }

  private func provider(state: State) -> Formula.Provider? {
    switch state.provider {
    case .bitrise:
      return Formula.Provider.bitrise(app: state.appSlug, build: state.buildSlug, artifact: state.artifactSlug)
    case .http:
      guard let url = URL(string: state.uri) else { return .none }
      return Formula.Provider.http(url)
    case .xcodeCloud:
      return Formula.Provider.xcodeCloud
    }
  }
}
