//
//  RecipeFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import Foundation
import Sharing
import TanamiFoundation
import TanamiServices

@Reducer
public struct RecipeFeature: Sendable {
  @Dependency(\.recipe) var recipeClient

  // MARK: - Model
  public enum Provider: CaseIterable, Hashable, Sendable {
    case bitrise, http, xcodeCloud

    var description: String {
      switch self {
      case .bitrise: L10n.providerBitriseLabel
      case .http: L10n.providerHttpLabel
      case .xcodeCloud: L10n.providerXcodeCloudLabel
      }
    }
  }

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectApps) var appStoreConnectApps
    @Shared(.recipes) var recipes

    var appId: AppStoreConnect.Application.ID
    var provider: Provider
    var platform: AppStoreConnect.Platform
    var destination: Formula.Destination
    var configuration: Formula.Provider
    var isLoading: Bool
    var errorMessage: String?
    var shouldCloseWindow: Bool

    var appSlug: String = ""
    var buildSlug: String = ""
    var artifactSlug: String = ""
    var uri: String = ""

    var currentApplication: AppStoreConnect.Application? {
      appStoreConnectApps.first(where: { $0.id == appId })
    }

    var configurationIsValid: Bool {
      switch provider {
      case .bitrise: !appSlug.isEmpty && !buildSlug.isEmpty && !artifactSlug.isEmpty
      case .http: !uri.isEmpty
      case .xcodeCloud: true
      }
    }

    init(
      appId: AppStoreConnect.Application.ID,
      provider: Provider,
      platform: AppStoreConnect.Platform,
      destination: Formula.Destination,
      configuration: Formula.Provider,
      isLoading: Bool,
      errorMessage: String?,
      shouldCloseWindow: Bool
    ) {
      self.appId = appId
      self.provider = provider
      self.platform = platform
      self.destination = destination
      self.configuration = configuration
      self.isLoading = isLoading
      self.errorMessage = errorMessage
      self.shouldCloseWindow = shouldCloseWindow
    }

    /// Provides an initial state.
    public static func initial(appId: AppStoreConnect.Application.ID, isLoading: Bool = false) -> State {
      .init(
        appId: appId,
        provider: .xcodeCloud,
        platform: .iOS,
        destination: .any,
        configuration: .xcodeCloud,
        isLoading: isLoading,
        errorMessage: .none,
        shouldCloseWindow: false
      )
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case error(String)
      case recipeDidLoad(Formula)
      case recipeDidSave
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case cancelButtonTapped
      case hideErrorMessage
      case providerWillChange(Provider)
      case saveButtonTapped
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
