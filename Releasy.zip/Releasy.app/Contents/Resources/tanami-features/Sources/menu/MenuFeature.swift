//
//  MenuFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountPicker
import AnalyticsService
import Application
import AppStoreConnectService
import AccountTab
import AppsTab
import ComposableArchitecture
import Device
import DevicesTab
import DeviceKit
import FeatureService
import Foundation
import GeneralTab
import RecentBuild
import Sharing
import Simulator
import TanamiFoundation
import XcodeService

@Reducer
public struct MenuFeature: Sendable {
  @Dependency(\.analytics) var analytics
  @Dependency(\.appStore) var appStore
  @Dependency(\.continuousClock) var clock
  @Dependency(\.feature) var feature
  @Dependency(\.xcode) var xcode

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Presents var destination: Destination.State?
    @Shared(.appStoreConnectAccounts) var appStoreConnectAccounts
    @Shared(.currentAccountId) var currentAccountId

    var application: ApplicationFeature.State
    var build: RecentBuildFeature.State
    var device: DeviceFeature.State
    var simulator: SimulatorFeature.State
    var xcodeRelease: XcodeRelease?

    var accountSelector: Bool { appStoreConnectAccounts.count > 1 }

    var currentAccount: AppStoreConnect.Account? {
      appStoreConnectAccounts.first(where: { $0.id == currentAccountId })
    }

    /// Initializes the state with navigation path.
    init(
      application: ApplicationFeature.State,
      build: RecentBuildFeature.State,
      device: DeviceFeature.State,
      simulator: SimulatorFeature.State,
      xcodeRelease: XcodeRelease?
    ) {
      self.application = application
      self.build = build
      self.device = device
      self.simulator = simulator
      self.xcodeRelease = xcodeRelease
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(application: .initial, build: .initial, device: .initial, simulator: .initial, xcodeRelease: .none)
    }
  }

  // MARK: - Destinations
  @Reducer
  public enum Destination {
    case accountPicker(AccountPicker)
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to analytics.
    case analytic(Analytic)
    /// Actions releated to the application features.
    case application(ApplicationFeature.Action)
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions releated to the recent builds features.
    case build(RecentBuildFeature.Action)
    /// Actions for destination interactions.
    case destination(PresentationAction<Destination.Action>)
    /// Actions releated to the device features.
    case device(DeviceFeature.Action)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to the simulator features.
    case simulator(SimulatorFeature.Action)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Analytic: Equatable, Sendable {
      case featureRequestMenuTapped
      case updateMenuTapped
      case settingsMenuTapped
      case quitMenuTapped
    }
    @CasePathable
    public enum Internal: Equatable, Sendable {
      case loadCurrentAccountId(AppStoreConnect.Account.ID?)
      case xcodeReleaseDidLoad(XcodeRelease?)
    }
    @CasePathable
    public enum View: Sendable, Equatable {
      case accountPickerButtonTapped
      case task
      case xcodeRefresh
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Scope(state: \.application, action: \.application, child: ApplicationFeature.init)
    Scope(state: \.build, action: \.build, child: RecentBuildFeature.init)
    Scope(state: \.device, action: \.device, child: DeviceFeature.init)
    Scope(state: \.simulator, action: \.simulator, child: SimulatorFeature.init)
    Reduce { state, action in
      switch action {
      case .analytic(let action):
        return handleAnalyticAction(action, state: &state)
      case .application:
        return .none
      case .binding:
        return .none
      case .build:
        return .none
      case .destination(.presented(.accountPicker(.delegate(let action)))):
        return handleAccountPickerAction(action, state: &state)
      case .destination:
        return .none
      case .device:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .simulator:
        return .none
      case .view(let action):
        return handleViewAction(action, state: &state)
      }
    }
    .ifLet(\.$destination, action: \.destination)
  }

  // MARK: - Inializer
  public init() {}
}

extension MenuFeature.Destination.Action: Equatable, Sendable {}
extension MenuFeature.Destination.State: Equatable, Sendable {}
