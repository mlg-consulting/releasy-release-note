//
//  MenuFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Application
import AccountTab
import AppsTab
import ComposableArchitecture
import DevicesTab
import DeviceKit
import Foundation
import GeneralTab
import Sharing
import Simulator

@Reducer
public struct MenuFeature: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    var application: ApplicationFeature.State
    var simulator: SimulatorFeature.State

    /// Initializes the state with navigation path.
    init(application: ApplicationFeature.State, simulator: SimulatorFeature.State) {
      self.application = application
      self.simulator = simulator
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(application: .initial, simulator: .initial)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions releated to the settings account tab features.
    case application(ApplicationFeature.Action)
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions releated to the settings account tab features.
    case simulator(SimulatorFeature.Action)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum View: Sendable, Equatable {
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Scope(state: \.application, action: \.application, child: ApplicationFeature.init)
    Scope(state: \.simulator, action: \.simulator, child: SimulatorFeature.init)
    Reduce { state, action in
      switch action {
      case .application:
        return .none
      case .binding:
        return .none
      case .simulator:
        return .none
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
