//
//  MenuFeature+SharedKey.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 31/12/2024.
//

import Sharing

//extension SharedReaderKey where Self == AppStorageKey<SettingsTab>.Default {
//  public static var selectedTab: Self {
//    Self[.appStorage("selectedTab"), default: .general]
//  }
//}
