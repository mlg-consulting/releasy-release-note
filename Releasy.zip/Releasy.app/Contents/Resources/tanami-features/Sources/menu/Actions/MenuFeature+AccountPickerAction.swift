//
//  MenuFeature+InternalActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import AccountPicker

extension MenuFeature {
  func handleAccountPickerAction(_ action: AccountPicker.Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didSelectAccount(let id):
      guard id != state.currentAccountId else { return .none }
      guard let account = state.appStoreConnectAccounts.first(where: { $0.id == id} ) else { return .none }
      state.destination = .none
      return .run { send in
        try await appStore.accounts.setCurrent(account)
      } catch: { error, send in
        // TODO: Add error handling
      }
    case .didTapAddAccount:
      state.destination = .none
      return .none
    }
  }
}
