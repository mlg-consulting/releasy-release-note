//
//  MenuFeature+InternalActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import FeatureService

extension MenuFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .loadCurrentAccountId(let id):
      state.$currentAccountId.withLock { $0 = id }
      return .none
    case .xcodeReleaseDidLoad(let xcode):
      state.xcodeRelease = xcode
      return .none
    }
  }
}
