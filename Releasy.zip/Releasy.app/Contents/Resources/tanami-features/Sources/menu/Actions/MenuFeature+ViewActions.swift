//
//  MenuFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import FeatureService

extension MenuFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .task:
      return .run { send in
        try? await feature.load(.currentEnv)
        for await _ in clock.timer(interval: .seconds(3600)) {
          try? await feature.load(.currentEnv) // Hopefully it will work next run
        }
      }
    }
  }
}

extension Env {
  static var currentEnv: Env {
#if DEBUG
    .dev
#else
    .prod
#endif
  }
}
