//
//  MenuFeature+Analytics.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AnalyticsService
import ComposableArchitecture

extension MenuFeature {
  func handleAnalyticAction(_ action: Action.Analytic, state: inout State) -> EffectOf<Self> {
    switch action {
    case .featureRequestMenuTapped:
      analytics.send(Feature.Menu.FeatureRequest.tapped)
    case .updateMenuTapped:
      analytics.send(Feature.Menu.Update.tapped)
    case .settingsMenuTapped:
      analytics.send(Feature.Menu.Settings.tapped)
    case .quitMenuTapped:
      analytics.send(Feature.Menu.Quit.tapped)
    }
    return .none
  }
}
