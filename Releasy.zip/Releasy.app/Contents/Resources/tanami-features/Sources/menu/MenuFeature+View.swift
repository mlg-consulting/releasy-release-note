//
//  MenuFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Application
import ComposableArchitecture
import Dependencies
import Device
import DeviceKit
import SettingsRouter
import Simulator
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import TanamiServices

@ViewAction(for: MenuFeature.self)
public struct MenuFeatureView: View {
  @Dependency(\.designSystem) var designSystem

  @Shared(.selectedTab) var selectedTab

  @Environment(UpdateController.self) private var updateController
  @Bindable public var store: StoreOf<MenuFeature>

  public init(store: StoreOf<MenuFeature>) {
    self.store = store
  }

  public var body: some View {
    VStack(alignment: .leading, spacing: designSystem.spacing(.xs)) {
      header
      Divider()
      ApplicationFeatureView(store: store.scope(state: \.application, action: \.application))
      Divider()
      DeviceFeatureView(store: store.scope(state: \.device, action: \.device))
      SimulatorFeatureView(store: store.scope(state: \.simulator, action: \.simulator))
      Divider()
      VStack(alignment: .leading, spacing: .zero) {
        settings
        updates
        quit
      }
    }
    .padding(designSystem.spacing(.xs))
    .frame(width: 336)
  }
}

extension MenuFeatureView {
  private var header: some View {
    HStack(alignment: .center) {
      Text(Bundle.main.displayName)
        .font(.body.bold())
      Spacer()
      Text(Bundle.main.shortVersionString)
    }
    .foregroundColor(.primary)
  }

  private var settings: some View {
    SettingsLink {
      Text(L10n.menuSettingsTitle)
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true))
  }

  private var updates: some View {
    Button {
      updateController.checkForUpdates()
    } label: {
      Text(L10n.menuUpdatesTitle)
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true))
  }

  private var quit: some View {
    Button {
      NSApplication.shared.terminate(nil)
    } label: {
      Text(L10n.menuQuitTitle(Bundle.main.displayName))
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true))
  }
}

#if DEBUG
#Preview {
  MenuFeatureView(store: Store(initialState: .initial, reducer: MenuFeature.init))
}
#endif
