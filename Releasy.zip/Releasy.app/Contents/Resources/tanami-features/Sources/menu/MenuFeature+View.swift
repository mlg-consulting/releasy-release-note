//
//  MenuFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountPicker
import Application
import ComposableArchitecture
import Console
import Dependencies
import Device
import DeviceKit
import FeatureService
import SettingsRouter
import Simulator
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import UpdateService
import XcodeService

@ViewAction(for: MenuFeature.self)
public struct MenuFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme
  @Dependency(\.feature) var feature
  @Dependency(\.xcode) var xcode

  @Shared(.selectedTab) var selectedTab

  let showConsoleWindow = ShowConsoleWindowAction()

  @Environment(\.scenePhase) var scenePhase
  @Environment(UpdateController.self) private var updateController
  @State private var isAccountPickerHovered: Bool = false
  @State private var bonjourStarted: Bool = false
  @Bindable public var store: StoreOf<MenuFeature>

  public init(store: StoreOf<MenuFeature>) {
    self.store = store
  }

  public var body: some View {
    VStack(alignment: .leading, spacing: designSystem.spacing(.xs)) {
      header
      Divider()
      if !store.appStoreConnectAccounts.isEmpty {
        xcodeRelease
        Divider()
        ApplicationFeatureView(store: store.scope(state: \.application, action: \.application))
        Divider()
        DeviceFeatureView(store: store.scope(state: \.device, action: \.device))
        SimulatorFeatureView(store: store.scope(state: \.simulator, action: \.simulator))
        Divider()
      }
      VStack(alignment: .leading, spacing: designSystem.spacing(.xs)) {
        console
        documentation
        Divider()
        settings
        updates
        Divider()
        report
        Divider()
        quit
      }
    }
    .padding(designSystem.spacing(.xs))
    .frame(width: 336)
    .task { send(.task) }
    .task { send(.xcodeRefresh) }
  }
}

extension MenuFeatureView {
  private var header: some View {
    HStack(alignment: .center) {
      accounts
      Spacer()
      VStack(alignment: .trailing, spacing: designSystem.spacing(.xxs)) {
        HStack(spacing: designSystem.spacing(.xxs)) {
          Text(Bundle.main.displayName)
            .font(.body.bold())
        }
        Text(Bundle.main.shortVersionString)
          .font(.caption)
          .foregroundStyle(.secondary)
      }
    }
    .foregroundColor(.primary)
  }

  @ViewBuilder
  private var xcodeRelease: some View {
    if let xcode = store.xcodeRelease, let releaseDate = xcode.releaseDate {
      HStack {
        VStack(alignment: .leading) {
          Text("Xcode " + xcode.version.displayable)
            .font(.title3)
            .fontWeight(.semibold)
          Text(releaseDate, style: .date)
            .font(.subheadline)
            .foregroundStyle(.secondary)
        }
        Spacer()
        if let url = xcode.releaseNotesURL {
          Link(destination: url) {
            Pill(label: L10n.xcodeReleaseNoteLabel)
          }
          .foregroundStyle(.white)
        }
      }
      .padding(designSystem.spacing(.xxs))
    }
  }

  @ViewBuilder
  private var accounts: some View {
    if let account = store.currentAccount {
      Button(action: { send(.accountPickerButtonTapped) }) {
        Avatar(name: account.name, color: theme.color(.init(stringLiteral: account.colorKey)))
        if isAccountPickerHovered || store.destination != .none {
          Text(account.name)
            .font(.body)
            .fontWeight(.bold)
            .lineLimit(1)
        }
        designSystem.icon(.chevronUpChevronDown)
          .fontWeight(.semibold)
      }
      .buttonStyle(.plain)
      .onHover { isAccountPickerHovered in
        withAnimation(.snappy) {
          self.isAccountPickerHovered = isAccountPickerHovered
        }
      }
      .popover(
        item: $store.scope(
          state: \.destination?.accountPicker,
          action: \.destination.accountPicker
        ),
        arrowEdge: .leading
      ) { store in
        AccountPickerView(store: store)
      }
    }
  }

  private var console: some View {
    Button(L10n.deviceOpenConsoleLabel) {
      showConsoleWindow.callAsFunction(
        store: Store(
          initialState: .initial(),
          reducer: ConsoleFeature.init
        )
      )
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true))
  }

  private var documentation: some View {
    Link(destination: URL(string: "https://applelab-documentation.web.app/documentation/applelab/")! ) {
      Text(L10n.menuDocumentationTitle)
    }
    .buttonStyle(
      .menuItem(blinks: true)
    )
  }

  private var settings: some View {
    SettingsLink {
      Text(L10n.menuSettingsTitle)
    }
    .buttonStyle(
      .menuItem(activatesApplication: true, blinks: true) {
        store.send(.analytic(.settingsMenuTapped))
      }
    )
  }

  private var updates: some View {
    Button {
      store.send(.analytic(.updateMenuTapped))
      updateController.checkForUpdates()
    } label: {
      Text(L10n.menuUpdatesTitle)
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true))
  }

  private var report: some View {
    Link(destination: URL(string: "https://github.com/mlg-consulting/releasy-release-note/issues/new/choose")! ) {
      Text(L10n.menuReportTitle)
    }
    .buttonStyle(
      .menuItem(blinks: true) {
        store.send(.analytic(.featureRequestMenuTapped))
      }
    )
  }

  private var quit: some View {
    Button {
      store.send(.analytic(.quitMenuTapped))
      NSApplication.shared.terminate(nil)
    } label: {
      Text(L10n.menuQuitTitle(Bundle.main.displayName))
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true))
  }
}

extension Semver {
  var displayable: String {
    String("\(major).\(minor).\(patch)")
  }
}

#if DEBUG
#Preview {
  MenuFeatureView(store: Store(initialState: .initial, reducer: MenuFeature.init))
}
#endif
