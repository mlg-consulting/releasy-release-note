import AppKit
import ComposableArchitecture
import TanamiDesignSystem
import SwiftUI

@MainActor
final class WorkflowWindow<Content: View>: NSPanel, CustomWindowPresentation {
	private let rootView: () -> Content

	private lazy var hostingView: NSHostingView<some View> = {
		let view = NSHostingView(
			rootView: rootView()
				.environment(\.customWindowPresentation, self)
				.edgesIgnoringSafeArea(.all)
				// Compensate for extra height from hidden title bar.
				.padding(.top, -titleBarHeight)
		)

		view.translatesAutoresizingMaskIntoConstraints = false
		return view
	}()

	init(content: @escaping () -> Content) {
		self.rootView = content

		super.init(
			contentRect: CGRect(x: 0, y: 0, width: 100, height: 100),
			styleMask: [.titled, .fullSizeContentView],
			backing: .buffered,
			defer: false
		)

    isMovable = true
		isMovableByWindowBackground = true
		isFloatingPanel = false
		isOpaque = true
		titleVisibility = .hidden
		titlebarAppearsTransparent = true

		animationBehavior = .utilityWindow
		hidesOnDeactivate = false

		standardWindowButton(.closeButton)?.isHidden = true
		standardWindowButton(.miniaturizeButton)?.isHidden = true
		standardWindowButton(.zoomButton)?.isHidden = true

		contentView = hostingView
		setContentSize(hostingView.intrinsicContentSize)
	}

	private var titleBarHeight: CGFloat {
		if let windowFrameHeight = contentView?.frame.height {
			return windowFrameHeight - contentLayoutRect.height
		}
    return .zero
	}

	override var canBecomeKey: Bool { true }

	override var canBecomeMain: Bool { true }

  func dismiss() {
    close()
  }
}

public final class ShowWorkflowWindowAction {
  private var workflowWindow: NSWindow?

  public init() {}

  @MainActor
  public func callAsFunction(store: StoreOf<WorkflowFeature>) {
    if workflowWindow == nil {
      workflowWindow = WorkflowWindow {
        WorkflowFeatureView(store: store)
          .showDockIconWhenOpen()
      }
      workflowWindow?.identifier = .init("WorkflowFeature")
    }
    workflowWindow?.center()
    workflowWindow?.makeKeyAndOrderFront(nil)
    NSRunningApplication.current.activate()
  }
}

extension EnvironmentValues {
  @Entry public var showWorkflowWindow: ShowWorkflowWindowAction?
}

public protocol CustomWindowPresentation {
  @MainActor func dismiss()
}

extension EnvironmentValues {
  @Entry public var customWindowPresentation: CustomWindowPresentation? = .none
}
