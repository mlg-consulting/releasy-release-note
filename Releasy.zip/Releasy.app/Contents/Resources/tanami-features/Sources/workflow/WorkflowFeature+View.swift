import AppStoreConnectService
import ComposableArchitecture
import TanamiDesignSystem
import TanamiFoundation
import SwiftUI

extension AppStoreConnect.CIGitRefKind {
  public var localized: String {
    switch self {
    case .branch: L10n.gitReferenceBranchesItemTitle
    case .tag: L10n.gitReferenceTagsItemTitle
    }
  }
}

extension WorkflowFeatureView {
  private enum UI {
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
    static let spacing: CGFloat = 32.0
  }
}

@ViewAction(for: WorkflowFeature.self)
public struct WorkflowFeatureView: View {
  @Dependency(\.designSystem) var designSystem

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @Bindable public var store: StoreOf<WorkflowFeature>

  public init(store: StoreOf<WorkflowFeature>) {
    self.store = store
  }

  public var body: some View {
    ZStack(alignment: .top) {
      VStack(spacing: designSystem.spacing(.xs)) {
        app
        header
        disclaimer
        gitReferenceSelector
        form
        Spacer()
        toolbar
      }
      .padding(UI.padding)
      .frame(width: 600)
      .frame(minHeight: 500, maxHeight: 700)
      .scrollContentBackground(.hidden)
      .task { send(.loadWorkflows) }

      errorMessage
    }
    .fixedSize()
  }
}

extension WorkflowFeatureView {
  @ViewBuilder
  private var errorMessage: some View {
    if let message = store.errorMessage {
      ErrorMessage(message)
    }
  }

  private var header: some View {
    Text(L10n.newBuildTitle)
      .font(.largeTitle)
      .foregroundColor(.primary)
      .padding(.bottom, designSystem.spacing(.s))
  }

  private var disclaimer: some View {
    HStack(alignment: .top, spacing: designSystem.spacing(.xxs)) {
      designSystem.icon(.exclamationmarkCircleFill)
      Text(L10n.newBuildDisclaimer)
    }
    .font(.body)
    .foregroundColor(.secondary)
    .padding(designSystem.spacing(.xs))
    .background(
      RoundedRectangle(cornerRadius: designSystem.radius(.s))
        .fill(.blue.opacity(0.1))
    )
    .overlay(
      RoundedRectangle(cornerRadius: designSystem.radius(.s))
        .stroke(.blue, lineWidth: 0.5)
    )
    .padding(.vertical, designSystem.spacing(.s))
    .padding(.horizontal, designSystem.spacing(.m))
  }

  private var app: some View {
    VStack(alignment: .leading, spacing: designSystem.spacing(.xxs)) {
      AsyncImage(url: store.application.iconUrl) { image in
        image.resizable()
      } placeholder: {
        Color.gray
      }
      .frame(width: 32.0, height: 32.0)
      .mask(RoundedRectangle(cornerRadius: designSystem.radius(.s)))
    }
  }

  private var form: some View {
    Form {
      Section {
        workflows
        gitReferences
      }
    }
    .formStyle(.grouped)
  }

  @ViewBuilder
  private var workflows: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.workflowTitle).font(.headline)
      Spacer()
      Picker(L10n.workflowTitle, selection: $store.currentWorkflowId.sending(\.view.currentWorkflowIdChanged)) {
        ForEach(store.workflows) { workflow in
          Text(workflow.name ?? "--").tag(workflow.id)
        }
      }
      .labelsHidden()
    }
  }

  private var gitReferenceSelector: some View {
    Picker(
      L10n.gitReferenceSelectorTitle,
      selection: $store.currentGitReferenceType.sending(\.view.currentGitReferenceTypeChanged)
    ) {
      ForEach(AppStoreConnect.CIGitRefKind.allCases, id: \.self) { item in
        Text(item.localized).tag(item.id)
      }
    }
    .labelsHidden()
    .pickerStyle(.segmented)
  }

  @ViewBuilder
  private var gitReferences: some View {
    HStack(alignment: .center) {
      Text(L10n.gitReferenceSelectorTitle).font(.headline)
      Spacer()
      Picker(L10n.branchesTitle, selection: $store.currentGitReferenceId.sending(\.view.currentGitReferenceIdChanged)) {
        ForEach(gitReferenceElements) { gitReference in
          Text(gitReference.name ?? "--").tag(gitReference.id)
        }
      }
      .labelsHidden()
    }
  }

  private var toolbar: some View {
    HStack {
      cancel
      Spacer()
      start
    }
    .padding(designSystem.spacing(.m))
  }

  @ViewBuilder
  private var cancel: some View {
    Button(L10n.cancelStartBuildButtonLabel) {
      customWindowPresentation?.dismiss()
    }
    .tint(.secondary)
    .controlSize(.large)
  }

  private var start: some View {
    Button(
      action: { send(.startBuildButtonTapped) },
      label: {
        if store.isLoading {
          ProgressView().controlSize(.small)
        } else {
          Text(L10n.startBuildButtonLabel)
        }
      }
    )
    .controlSize(.large)
    .keyboardShortcut(.return)
    .disabled(!store.isStartValid)
  }

  private var gitReferenceElements: [AppStoreConnect.ScmGitReference] {
    switch store.currentGitReferenceType {
    case .branch: store.availableBranches
    case .tag: store.availableTags
    }
  }
}

#if DEBUG
#Preview {
  WorkflowFeatureView(
    store: Store(
      initialState: .initial(application: .mock),
      reducer: WorkflowFeature.init
    )
  )
}
#endif
