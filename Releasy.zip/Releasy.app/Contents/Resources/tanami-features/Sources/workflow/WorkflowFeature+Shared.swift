import Foundation
import IdentifiedCollections
import Sharing
import TanamiFoundation

public struct RecentBuild: Codable, Equatable, Identifiable, Sendable {
  public var id: AppStoreConnect.CIBuildRun.ID { buildRunId }
  public let applicationId: AppStoreConnect.Application.ID
  public let buildRunId: AppStoreConnect.CIBuildRun.ID
  public let gitReferenceId: AppStoreConnect.ScmGitReference.ID
  public let sourceBranchOrTag: String?
  public let workflowId: AppStoreConnect.CIWorkflow.ID
}

extension SharedReaderKey where Self == FileStorageKey<IdentifiedArrayOf<RecentBuild>>.Default {
  public static var recentBuilds: Self {
    Self[
      .fileStorage(
        .applicationSupportDirectory
          .appending(component: Bundle.main.displayName)
          .appending(component: "recent-builds")
      ),
      default: .init()
    ]
  }
}
