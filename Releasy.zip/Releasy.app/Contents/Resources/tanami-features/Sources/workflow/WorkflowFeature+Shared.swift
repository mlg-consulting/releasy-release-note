import Foundation
import IdentifiedCollections
import Sharing
import TanamiFoundation

public struct RecentBuild: Codable, Equatable, Identifiable, Sendable {
  public var id: AppStoreConnect.CIBuildRun.ID { buildRunId }
  public let applicationId: AppStoreConnect.Application.ID
  public let buildRunId: AppStoreConnect.CIBuildRun.ID
  public let gitReferenceId: AppStoreConnect.ScmGitReference.ID
  public let sourceBranchOrTag: String?
  public let workflowId: AppStoreConnect.CIWorkflow.ID

  public init(
    applicationId: AppStoreConnect.Application.ID,
    buildRunId: AppStoreConnect.CIBuildRun.ID,
    gitReferenceId: AppStoreConnect.ScmGitReference.ID,
    sourceBranchOrTag: String?,
    workflowId: AppStoreConnect.CIWorkflow.ID
  ) {
    self.applicationId = applicationId
    self.buildRunId = buildRunId
    self.gitReferenceId = gitReferenceId
    self.sourceBranchOrTag = sourceBranchOrTag
    self.workflowId = workflowId
  }
}

extension SharedReaderKey where Self == FileStorageKey<IdentifiedArrayOf<RecentBuild>>.Default {
  public static var recentBuilds: Self {
    Self[
      .fileStorage(
        .applicationSupportDirectory
          .appending(component: Bundle.main.displayName)
          .appending(component: "recent-builds")
      ),
      default: .init()
    ]
  }
}
