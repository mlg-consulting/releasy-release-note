import AppStoreConnectService
import ComposableArchitecture
import Dependencies
import Foundation
import Sharing
import TanamiFoundation

extension String {
  func contains(_ strings: [String]) -> Bool {
    strings.contains { contains($0) }
  }
}

@Reducer
public struct WorkflowFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.mainQueue) var mainQueue

  // MARK: - Inializer
  public init() {}

  // MARK: - Models
  enum BuildState: Equatable, Sendable {
    case pending, loading, building, built, failed
  }

  // MARK: - State
  @ObservableState
  public struct State: Identifiable, Sendable, Equatable {
    @Shared(.recentBuilds) var recentBuilds

    public let id = UUID()
    let application: AppStoreConnect.Application
    var repository: AppStoreConnect.ScmRepository? = .none
    var workflows: [AppStoreConnect.CIWorkflow] = []
    var currentWorkflowId: AppStoreConnect.CIWorkflow.ID? = .none
    var gitReferences: [AppStoreConnect.ScmGitReference] = []
    var currentGitReferenceId: AppStoreConnect.ScmGitReference.ID? = .none
    var currentGitReferenceType: AppStoreConnect.CIGitRefKind = .branch
    var errorMessage: String? = .none
    var buildState: BuildState = .pending

    init(application: AppStoreConnect.Application) {
      self.application = application
    }

    /// Provides an initial state.
    public static func initial(application: AppStoreConnect.Application) -> State {
      .init(application: application)
    }

    var availableBranches: [AppStoreConnect.ScmGitReference] {
      gitReferences.filter({ $0.kind == .branch }).filter {
        let prefixes = currentWorkflow?.manualBranchStartCondition?.source?.patterns.compactMap(\.pattern) ?? []
        guard !prefixes.isEmpty else { return true }
        return $0.name?.contains(prefixes) == true
      }
      .sorted(by: { $0.canonicalName ?? "" < $1.canonicalName ?? "" })
      .sorted(by: >)
    }

    var availableTags: [AppStoreConnect.ScmGitReference] {
      gitReferences.filter({ $0.kind == .tag }).sorted(by: { $0.canonicalName ?? "" > $1.canonicalName ?? "" })
    }

    var currentWorkflow: AppStoreConnect.CIWorkflow? {
      workflows.first(where: { $0.id == currentWorkflowId })
    }

    var currentGitReference: AppStoreConnect.ScmGitReference? {
      gitReferences.first(where: { $0.id == currentGitReferenceId })
    }

    var isStartValid: Bool { currentWorkflow != .none && currentGitReference != .none }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case buidDidStart(AppStoreConnect.CIBuildRun, AppStoreConnect.CIWorkflow.ID, AppStoreConnect.ScmGitReference.ID)
      case gitReferencesDidLoad([AppStoreConnect.ScmGitReference])
      case repositoryDidLoad(AppStoreConnect.ScmRepository?)
      case workflowDidLoad([AppStoreConnect.CIWorkflow])
      case workflowDidFail(String)
    }
    @CasePathable
    public enum View: Sendable, Equatable {
      case currentWorkflowIdChanged(AppStoreConnect.CIWorkflow.ID?)
      case currentGitReferenceIdChanged(AppStoreConnect.ScmGitReference.ID?)
      case currentGitReferenceTypeChanged(AppStoreConnect.CIGitRefKind)
      case loadGitReferences
      case loadRepository
      case loadWorkflows
      case startBuildButtonTapped
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding: .none
      case .internal(let action): handleInternalAction(action, state: &state)
      case .view(let action): handleViewAction(action, state: &state)
      }
    }
  }
}
