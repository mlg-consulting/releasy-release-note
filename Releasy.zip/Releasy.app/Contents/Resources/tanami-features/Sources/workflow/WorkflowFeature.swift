import AppStoreConnectService
import ComposableArchitecture
import Dependencies
import Foundation
import Sharing
import TanamiFoundation

extension String {
  func contains(_ strings: [String]) -> Bool {
    strings.contains { contains($0) }
  }
}

@Reducer
public struct WorkflowFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.mainQueue) var mainQueue

  // MARK: - Inializer
  public init() {}

  // MARK: - State
  @ObservableState
  public struct State: Identifiable, Sendable, Equatable {
    public let id = UUID()
    let application: AppStoreConnect.Application
    var repository: AppStoreConnect.ScmRepository?
    var workflows: [AppStoreConnect.CIWorkflow]
    var currentWorkflowId: AppStoreConnect.CIWorkflow.ID?
    var gitReferences: [AppStoreConnect.ScmGitReference]
    var currentGitReferenceId: AppStoreConnect.ScmGitReference.ID?
    var currentGitReferenceType: AppStoreConnect.CIGitRefKind
    var errorMessage: String?
    var isLoading: Bool

    init(
      application: AppStoreConnect.Application,
      repository: AppStoreConnect.ScmRepository?,
      workflows: [AppStoreConnect.CIWorkflow],
      currentWorkflowId: AppStoreConnect.CIWorkflow.ID?,
      gitReferences: [AppStoreConnect.ScmGitReference],
      currentGitReferenceId: AppStoreConnect.ScmGitReference.ID?,
      currentGitReferenceType: AppStoreConnect.CIGitRefKind,
      errorMessage: String?,
      loading: Bool
    ) {
      self.application = application
      self.repository = repository
      self.workflows = workflows
      self.currentWorkflowId = currentWorkflowId
      self.gitReferences = gitReferences
      self.currentGitReferenceId = currentGitReferenceId
      self.currentGitReferenceType = currentGitReferenceType
      self.errorMessage = errorMessage
      self.isLoading = loading
    }

    /// Provides an initial state.
    public static func initial(application: AppStoreConnect.Application) -> State {
      .init(
        application: application,
        repository: .none,
        workflows: [],
        currentWorkflowId: .none,
        gitReferences: [],
        currentGitReferenceId: .none,
        currentGitReferenceType: .branch,
        errorMessage: .none,
        loading: false
      )
    }

    var availableBranches: [AppStoreConnect.ScmGitReference] {
      gitReferences.filter { $0.kind == .branch }.filter {
        let prefixes = currentWorkflow?.manualBranchStartCondition?.source?.patterns.compactMap(\.pattern) ?? []
        guard !prefixes.isEmpty else { return true }
        return $0.name?.contains(prefixes) == true
      }
    }

    var availableTags: [AppStoreConnect.ScmGitReference] {
      gitReferences.filter { $0.kind == .tag }
    }

    var currentWorkflow: AppStoreConnect.CIWorkflow? {
      workflows.first(where: { $0.id == currentWorkflowId })
    }

    var currentGitReference: AppStoreConnect.ScmGitReference? {
      gitReferences.first(where: { $0.id == currentGitReferenceId })
    }

    var isStartValid: Bool { currentWorkflow != .none && currentGitReference != .none }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case buidDidStart
      case gitReferencesDidLoad([AppStoreConnect.ScmGitReference])
      case repositoryDidLoad(AppStoreConnect.ScmRepository?)
      case workflowDidLoad([AppStoreConnect.CIWorkflow])
      case workflowDidFail(String)
    }
    @CasePathable
    public enum View: Sendable, Equatable {
      case currentWorkflowIdChanged(AppStoreConnect.CIWorkflow.ID?)
      case currentGitReferenceIdChanged(AppStoreConnect.ScmGitReference.ID?)
      case currentGitReferenceTypeChanged(AppStoreConnect.CIGitRefKind)
      case loadGitReferences
      case loadRepository
      case loadWorkflows
      case startBuildButtonTapped
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        .none
      case .internal(let action):
        handleInternalAction(action, state: &state)
      case .view(let action):
        handleViewAction(action, state: &state)
      }
    }
  }
}
