import ComposableArchitecture

extension WorkflowFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .currentWorkflowIdChanged(let workflowId):
      guard let workflowId, workflowId != state.currentWorkflowId else { return .none }
      state.currentWorkflowId = workflowId
      return .send(.view(.loadRepository))
    case .currentGitReferenceIdChanged(let gitReferenceId):
      guard let gitReferenceId, gitReferenceId != state.currentGitReferenceId else { return .none }
      state.currentGitReferenceId = gitReferenceId
      return .none
    case .currentGitReferenceTypeChanged(let type):
      state.currentGitReferenceType = type
      state.currentGitReferenceId = .none
      return .none
    case .loadGitReferences:
      guard let repositoryId = state.repository?.id else { return .none }
      state.buildState = .loading
      return .run { send in
        let gitReferences = try await appStore.repository.gitReferences(repositoryId)
        await send(.internal(.gitReferencesDidLoad(gitReferences)))
      }
    case .loadRepository:
      guard let workflowId = state.currentWorkflowId else { return .none }
      return .run { send in
        guard let repository = try await appStore.ci.repository(workflowId) else { return }
        await send(.internal(.repositoryDidLoad(repository)))
      }
    case .loadWorkflows:
      guard let ciProductId = state.application.ciProductId else { return .none }
      state.buildState = .loading
      return .run { send in
        let workflows = try await appStore.ci.workflows(ciProductId)
        await send(.internal(.workflowDidLoad(workflows)))
      } catch: { error, send in
        await send(.internal(.workflowDidFail(error.localizedDescription)))
      }
      .debounce(id: Cancellable.prePreleases, for: .milliseconds(250), scheduler: mainQueue)
    case .startBuildButtonTapped:
      guard let workflowId = state.currentWorkflowId, let gitReferenceId = state.currentGitReferenceId else {
        return .none
      }
      state.buildState = .building
      return .run { send in
        let buildRun = try await appStore.ci.startGitReference(workflowId, gitReferenceId)
        await send(.internal(.buildDidStart(buildRun, workflowId, gitReferenceId)))
      }
    }
  }
}

extension WorkflowFeature {
  enum Cancellable {
    case prePreleases
  }
}
