import AppStoreConnectService
import ComposableArchitecture
import Sharing

extension WorkflowFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .buildDidStart(let buildRun, let workflowId, let gitReferenceId):
      state.buildState = .built
      state.$recentBuilds.withLock {
        _ = $0.updateOrAppend(
          .init(
            applicationId: state.application.id,
            buildRunId: buildRun.id,
            gitReferenceId: gitReferenceId,
            sourceBranchOrTag: state.currentGitReference?.name,
            workflowId: workflowId
          )
        )
      }
      return .none
    case .gitReferencesDidLoad(let gitReferences):
      state.buildState = .pending
      state.gitReferences = gitReferences.filter({ $0.isDeleted == false })
      return .none
    case .repositoryDidLoad(let repository):
      state.buildState = .pending
      state.repository = repository
      return .send(.view(.loadGitReferences))
    case .workflowDidLoad(let workflows):
      state.workflows = workflows.filter(\.isEnabled)
      state.currentWorkflowId = state.workflows.last?.id
      guard state.currentWorkflowId != .none else { return .none }
      return .send(.view(.loadRepository))
    case .workflowDidFail(let message):
      state.buildState = .failed
      state.errorMessage = message
      return .none
    }
  }
}
