import AppStoreConnectService
import ComposableArchitecture

extension WorkflowFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .buidDidStart:
      state.isLoading = false
      return .none
    case .gitReferencesDidLoad(let gitReferences):
      state.isLoading = false
      state.gitReferences = gitReferences.filter({ $0.isDeleted == false })
      return .none
    case .repositoryDidLoad(let repository):
      state.isLoading = false
      state.repository = repository
      return .send(.view(.loadGitReferences))
    case .workflowDidLoad(let workflows):
      state.workflows = workflows.filter(\.isEnabled)
      state.currentWorkflowId = state.workflows.last?.id
      guard let workflowId = state.currentWorkflowId else { return .none }
      return .send(.view(.loadRepository))
    case .workflowDidFail(let message):
      state.isLoading = false
      state.errorMessage = message
      return .none
    }
  }
}
