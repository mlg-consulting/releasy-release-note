//
//  ReleaseFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Build
import ComposableArchitecture
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import TanamiServices

extension ReleaseFeatureView {
  private enum UI {
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
    static let spacing: CGFloat = 32.0
  }
}

@ViewAction(for: ReleaseFeature.self)
public struct ReleaseFeatureView: View {
  enum Field {
    case version
  }

  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @FocusState var focusedField: Field?
  @Bindable public var store: StoreOf<ReleaseFeature>

  public init(store: StoreOf<ReleaseFeature>) {
    self.store = store
  }

  public var body: some View {
    ZStack(alignment: .top) {
      VStack(spacing: designSystem.spacing(.xs)) {
        apps
        header
        form
        toolbar
      }
      .padding(UI.padding)
      .frame(width: 600)
      .frame(minHeight: 500, maxHeight: 700)
      .scrollContentBackground(.hidden)
      .fixedSize()

      errorMessage
    }
    .onChange(of: store.shouldCloseWindow) { oldValue, newValue in
      if newValue {
        Task {
          try await Task.sleep(for: .seconds(5))
          customWindowPresentation?.dismiss()
        }
      }
    }
  }
}

extension ReleaseFeatureView {
  @ViewBuilder
  private var errorMessage: some View {
    if let message = store.errorMessage {
      ErrorMessage(message)
    }
  }

  private var header: some View {
    Text(L10n.newReleaseTitle)
      .font(.largeTitle)
      .foregroundColor(.primary)
  }

  private var apps: some View {
    HStack(spacing: designSystem.spacing(.xs)) {
      ForEach(store.appStoreConnectApps.filter({ store.appIds.contains($0.id) }).sorted()) { app in
        AsyncImage(url: app.iconUrl) { image in
          image.resizable()
        } placeholder: {
          Color.gray
        }
        .frame(width: 32.0, height: 32.0)
        .mask(RoundedRectangle(cornerRadius: designSystem.radius(.s)))
      }
    }
  }

  private var simver: some View {
    TextField(L10n.inputVersionLabel, text: $store.version, prompt: Text(L10n.inputVersionPrompt))
      .disabled(store.isLoading)
      .onSubmit { send(.task) }
      .focused($focusedField, equals: .version)
      .onAppear { send(.computeApplicationVersion) }
  }

  private var build: some View {
    ForEach(store.scope(state: \.builds, action: \.builds)) {
      BuildFeatureView(store: $0, isDisabled: $store.isLoading)
    }
  }

  private var whatsNew: some View {
    TextEditor(text: $store.whatsNew)
      .font(.body)
      .scrollContentBackground(.hidden)
      .multilineTextAlignment(.leading)
      .overlay(alignment: .topLeading) {
        if store.whatsNew.isEmpty {
          Text(L10n.inputWhatsNewPlaceholder)
            .font(.body)
            .foregroundStyle(.tertiary)
            .padding(.horizontal, designSystem.spacing(.xxs))
            .allowsHitTesting(false)
        }
      }
      .frame(height: 100)
      .disabled(store.isLoading)
  }

  private var form: some View {
    Form {
      Section {
        simver
      }
      Section {
        build
      } header: { Text(L10n.inputBuildLabel) }
      Section {
        whatsNew
      } header: { Text(L10n.inputWhatsNewLabel) }
    }
    .formStyle(.grouped)
    .task { send(.task) }
    .onAppear { focusedField = .version }
  }

  private var toolbar: some View {
    HStack {
      if store.isLoading {
        progress
      } else {
        cancel
      }
      Spacer()
      if store.shouldCloseWindow {
        done
      } else {
        create
      }
    }
    .padding(designSystem.spacing(.m))
  }

  @ViewBuilder
  private var cancel: some View {
    Button(L10n.cancelNewReleaseButtonLabel) {
      customWindowPresentation?.dismiss()
    }
    .tint(.secondary)
    .controlSize(.large)
  }

  private var create: some View {
    Button(L10n.createNewReleaseButtonLabel) {
      send(.createReleaseButtonTapped)
    }
    .controlSize(.large)
    .keyboardShortcut(.return)
    .disabled(store.isReleaseValid)
  }

  private var done: some View {
    Button(action: { customWindowPresentation?.dismiss() }) {
      HStack(spacing: designSystem.spacing(.xxs)) {
        designSystem.icon(.checkmark)
        Text(L10n.createNewReleaseSuccessLabel)
      }
    }
    .buttonStyle(.borderedProminent)
    .tint(theme.color(.success))
    .controlSize(.large)
  }

  private var progress: some View {
    VStack(alignment: .leading, spacing: designSystem.spacing(.xxs)) {
      HStack {
        Text(store.currentApplication?.name ?? "--")
        if let description = store.progress?.step.description {
          Text("(\(description))")
            .foregroundStyle(.secondary)
        }
      }
      ProgressView(value: store.progress?.step.value)
        .progressViewStyle(.linear)
        .tint(store.progress?.step.color)
    }
    .padding(.trailing, designSystem.spacing(.l))
  }
}

extension Release.Progress.Step {
  var description: String {
    switch self {
    case .start: L10n.createVersionStateStarted
    case .createVersion: L10n.createVersionStateCreateVersion
    case .updateMetadata: L10n.createVersionStateUpdateLocalizations
    case .assignBuild: L10n.createVersionStateAssignBuild
    case .complete: L10n.createVersionStateCompleted
    case .error: L10n.createVersionStateErrored
    }
  }

  var value: CGFloat {
    switch self {
    case .start: 0.0
    case .createVersion: 0.3
    case .updateMetadata: 0.5
    case .assignBuild: 0.7
    case .complete, .error: 1
    }
  }

  var color: Color {
    @Dependency(\.designSystem.theme) var theme
    return switch self {
    case .error: theme.color(.error)
    default: theme.color(.success)
    }
  }
}

#if DEBUG
#Preview("Default") {
  ReleaseFeatureView(store: Store(initialState: .initial(appIds: []), reducer: ReleaseFeature.init))
}

extension ReleaseFeatureView {
  static var progressMock: ReleaseFeature.State {
    let app = AppStoreConnect.Application.mock
    return .init(
      appIds: [app.id],
      builds: .init(
        uniqueElements: [
          BuildFeature.State.initial(
            application: .mock,
            version: app.simver
          )
        ]
      ),
      version: "",
      selectedBuildIds: [app.id: AppStoreConnect.Build.mock.id],
      whatsNew: "",
      isLoading: true,
      progress: .init(app.id, step: .start),
      errorMessage: "You cannot create a new version of the App in the current state.",
      shouldCloseWindow: false
    )
  }
}

#Preview("In Progress") {
  @Shared(.appStoreConnectApps) var appStoreConnectApps = [.mock]
  ReleaseFeatureView(store: Store(initialState: ReleaseFeatureView.progressMock, reducer: ReleaseFeature.init))
}
#endif
