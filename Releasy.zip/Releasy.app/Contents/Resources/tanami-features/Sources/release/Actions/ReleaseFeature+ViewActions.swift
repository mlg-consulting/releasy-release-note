//
//  ReleaseFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Build
import ComposableArchitecture
#if canImport(FoundationModels)
import FoundationModels
#endif
import ReleaseService
import TanamiFoundation

extension ReleaseFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .computeApplicationVersion:
      guard
        let application = state.appStoreConnectApps.first(where: { state.appIds.contains($0.id) }),
        let appVersionString = application.versionString,
        let version = Semver(appVersionString)
      else {
        return .none
      }
      state.version = Semver(major: version.major, minor: version.minor, patch: version.patch + 1).description
      return .none
    case .createReleaseButtonTapped:
      state.isLoading = true
      let release = Release(
        version: state.version,
        whatsNew: state.whatsNew.isEmpty ? L10n.inputWhatsNewPlaceholder : state.whatsNew,
        manualRelease: true,
        builds: state.selectedBuildIds,
        appVersions: state.appVersions
      )
      return .merge(
        .run { send in
          try await releaseClient.create(release)
          await send(.internal(.releaseDidSuccess))
        } catch: { error, send in
          await send(.internal(.error(error.localizedDescription)), animation: .bouncy(duration: 0.15))
        },
        .run { send in
          for await progress in await releaseClient.progress() {
            await send(.internal(.updateProgress(progress)))
          }
        }
      )
    case .generateWhatsNewButtonTapped:
      guard let buildId = state.selectedBuildIds.values.first else { return .none }
      state.isWhatsNewLoading = true
      return .run { send in
        if #available(macOS 26.0, *) {
          guard let whatsNew = try await appStore.betaBuild.localizations(buildId).compactMap(\.whatsNew).first else {
            return
          }
          let instructions = "Do not include the technical release note elements. Use natural language to describe the changes for our users. Do not includes bug fixes elements."
          let prompt = "Can you write a release note for a what's new using the following technical release note: \(whatsNew)"
          let response = try await LanguageModelSession(instructions: instructions).respond(to: prompt)
          await send(.internal(.whatsNewAIGeneratedDidSuccess(response.content)))
        }
      } catch: { error, send in
        logger.log(
          level: .error,
          method: "generateWhatsNew",
          message: "error=[\(error)]"
        )
        await send(.internal(.whatsNewAIGeneratedDidFail))
      }
    case .hideErrorMessage:
      state.errorMessage = .none
      state.isLoading = false
      state.progress = .none
      return .none
    case .task:
      state.builds = .init(
        uniqueElements: state.appIds
          .compactMap { appId in state.appStoreConnectApps.first(where: { $0.id == appId }) }
          .sorted()
          .map { BuildFeature.State.initial(application: $0, version: state.version) }
      )
      return .none
    }
  }
}
