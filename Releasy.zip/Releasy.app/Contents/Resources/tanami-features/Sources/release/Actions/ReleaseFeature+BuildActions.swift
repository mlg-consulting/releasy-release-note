//
//  ReleaseFeature+BuildActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Build
import ComposableArchitecture
import TanamiFoundation

extension ReleaseFeature {
  func handleBuildAction(_ action: BuildFeature.Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didSelectBuild(let buildId, let appId):
      state.selectedBuildIds[appId] = buildId
      return .none
    }
  }
}
