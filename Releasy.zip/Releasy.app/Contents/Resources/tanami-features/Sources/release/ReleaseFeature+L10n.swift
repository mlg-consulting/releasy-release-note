// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Cancel
  internal static let cancelNewReleaseButtonLabel = L10n.tr("Localizable", "cancel_new_release_button_label", fallback: "Cancel")
  /// Create Release…
  internal static let createNewReleaseButtonLabel = L10n.tr("Localizable", "create_new_release_button_label", fallback: "Create Release…")
  /// New Release Created
  internal static let createNewReleaseSuccessLabel = L10n.tr("Localizable", "create_new_release_success_label", fallback: "New Release Created")
  /// Assign Build…
  internal static let createVersionStateAssignBuild = L10n.tr("Localizable", "create_version_state_assign_build", fallback: "Assign Build…")
  /// Version Created With Success.
  internal static let createVersionStateCompleted = L10n.tr("Localizable", "create_version_state_completed", fallback: "Version Created With Success.")
  /// Create Version…
  internal static let createVersionStateCreateVersion = L10n.tr("Localizable", "create_version_state_create_version", fallback: "Create Version…")
  /// An error has occured.
  internal static let createVersionStateErrored = L10n.tr("Localizable", "create_version_state_errored", fallback: "An error has occured.")
  /// New version in progress…
  internal static let createVersionStateStarted = L10n.tr("Localizable", "create_version_state_started", fallback: "New version in progress…")
  /// Updated Localizations…
  internal static let createVersionStateUpdateLocalizations = L10n.tr("Localizable", "create_version_state_update_localizations", fallback: "Updated Localizations…")
  /// Builds
  internal static let inputBuildLabel = L10n.tr("Localizable", "input_build_label", fallback: "Builds")
  /// Version
  internal static let inputVersionLabel = L10n.tr("Localizable", "input_version_label", fallback: "Version")
  /// Type application version
  internal static let inputVersionPrompt = L10n.tr("Localizable", "input_version_prompt", fallback: "Type application version")
  /// What's new?
  internal static let inputWhatsNewLabel = L10n.tr("Localizable", "input_whats_new_label", fallback: "What's new?")
  /// Bug fixes and performance improvements
  internal static let inputWhatsNewPlaceholder = L10n.tr("Localizable", "input_whats_new_placeholder", fallback: "Bug fixes and performance improvements")
  /// Create New Release
  internal static let newReleaseTitle = L10n.tr("Localizable", "new_release_title", fallback: "Create New Release")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
