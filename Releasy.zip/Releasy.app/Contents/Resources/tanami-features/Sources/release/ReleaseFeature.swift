//
//  ReleaseFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppsTab
import Build
import ComposableArchitecture
import Console
import Dependencies
import Foundation
import ReleaseService
import Sharing
import TanamiFoundation

@Reducer
public struct ReleaseFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.console.app) var logger
  @Dependency(\.release) var releaseClient

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectApps) var appStoreConnectApps

    let appIds: [AppStoreConnect.Application.ID]

    var builds: IdentifiedArrayOf<BuildFeature.State>
    var version: String
    var selectedBuildIds: [AppStoreConnect.Application.ID: AppStoreConnect.Build.ID]
    var whatsNew: String
    var isLoading: Bool
    var isWhatsNewLoading: Bool
    var progress: Release.Progress?
    var errorMessage: String?
    var shouldCloseWindow: Bool

    var appVersions: [AppStoreConnect.Application.ID: AppStoreConnect.AppVersion.ID] {
      appStoreConnectApps
        .filter { selectedBuildIds.keys.contains($0.id) }
        .reduce(into: [:]) { $0[$1.id] = $1.appVersionId }
        .compactMapValues { $0 }
    }

    var isReleaseValid: Bool { !version.isEmpty && selectedBuildIds.count == appIds.count && !isLoading }

    init(
      appIds: [AppStoreConnect.Application.ID],
      builds: IdentifiedArrayOf<BuildFeature.State>,
      version: String,
      selectedBuildIds: [AppStoreConnect.Application.ID: AppStoreConnect.Build.ID],
      whatsNew: String,
      isLoading: Bool,
      isWhatsNewLoading: Bool,
      progress: Release.Progress?,
      errorMessage: String?,
      shouldCloseWindow: Bool
    ) {
      self.appIds = appIds
      self.builds = builds
      self.version = version
      self.selectedBuildIds = selectedBuildIds
      self.whatsNew = whatsNew
      self.isLoading = isLoading
      self.isWhatsNewLoading = isWhatsNewLoading
      self.progress = progress
      self.errorMessage = errorMessage
      self.shouldCloseWindow = shouldCloseWindow
    }

    /// Provides an initial state.
    public static func initial(appIds: [AppStoreConnect.Application.ID], isLoading: Bool = false) -> State {
      .init(
        appIds: appIds,
        builds: .init(),
        version: "",
        selectedBuildIds: [:],
        whatsNew: "",
        isLoading: isLoading,
        isWhatsNewLoading: false,
        progress: .none,
        errorMessage: .none,
        shouldCloseWindow: false
      )
    }

    var currentApplication: AppStoreConnect.Application? {
      appStoreConnectApps.first(where: { $0.id == progress?.appId })
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to build feature interactions
    case builds(IdentifiedActionOf<BuildFeature>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case error(String)
      case releaseDidSuccess
      case updateProgress(Release.Progress?)
      case whatsNewAIGeneratedDidSuccess(String)
      case whatsNewAIGeneratedDidFail
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case computeApplicationVersion
      case createReleaseButtonTapped
      case generateWhatsNewButtonTapped
      case hideErrorMessage
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case let .builds(.element(_, action)):
        guard case let .delegate(delegateAction) = action else { return .none }
        return handleBuildAction(delegateAction, state: &state)
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
    .forEach(\.builds, action: \.builds) {
      BuildFeature()
    }
  }

  // MARK: - Inializer
  public init() {}
}
