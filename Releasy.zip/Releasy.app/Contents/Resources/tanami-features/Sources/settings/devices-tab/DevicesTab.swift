//
//  DevicesTab.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import DeviceKit
import Foundation
import Sharing
import TanamiServices

@Reducer
public struct DevicesTab: Sendable {
  @Dependency(\.deviceClient) var device
  @Dependency(\.systemClient) var system

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.pinnedSimulators) var pinnedSimulators

    var simulators: [Simulator]

    /// Initializes the state with navigation path.
    init(simulators: [Simulator]) {
      self.simulators = simulators
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(simulators: [])
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case didLoadSimulators([Simulator])
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case loadSimulators
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding(let action):
        return handleBindingAction(action, state: &state)
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
