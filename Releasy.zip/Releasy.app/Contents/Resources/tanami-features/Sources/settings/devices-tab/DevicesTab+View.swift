//
//  DevicesTab+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import DeviceKit
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@ViewAction(for: DevicesTab.self)
public struct DevicesTabView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.deviceClient) var devices

  @Bindable public var store: StoreOf<DevicesTab>

  public init(store: StoreOf<DevicesTab>) {
    self.store = store
  }

  public var body: some View {
    Form {
      Section {
        ForEach(store.simulators.sorted(by: >)) { simulator in
          Toggle(isOn: pinned(simulator: simulator)) {
            DeviceRow(
              name: simulator.name,
              runtime: String(describing: simulator.runtime)
            )
          }
        }
      } header: {
        Text(L10n.headerTitle)
        Text(L10n.headerDescription)
      }
    }
    .formStyle(.grouped)
    .task { send(.loadSimulators) }
  }

  private func pinned(simulator: Simulator) -> Binding<Bool> {
    Binding {
      store.pinnedSimulators.contains(simulator.id)
    } set: { newValue in
      if newValue {
        store.pinnedSimulators.append(simulator.id)
      } else {
        store.pinnedSimulators.removeAll { $0 == simulator.id }
      }
    }
  }
}

#if DEBUG
#Preview {
  DevicesTabView(store: Store(initialState: .initial, reducer: DevicesTab.init))
}
#endif
