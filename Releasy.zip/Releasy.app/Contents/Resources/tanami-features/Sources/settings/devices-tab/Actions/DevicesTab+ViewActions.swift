//
//  DevicesTab+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture

extension DevicesTab {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .loadSimulators:
      return .run { send in
        let simulators = await device.simulators()
        await send(.internal(.didLoadSimulators(simulators)))
      }
    case .task:
      return .none
    }
  }
}
