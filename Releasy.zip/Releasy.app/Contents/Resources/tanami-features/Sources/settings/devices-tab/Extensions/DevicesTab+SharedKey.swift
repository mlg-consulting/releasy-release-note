//
//  DevicesTab+SharedKey.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 31/12/2024.
//

import DeviceKit
import Foundation
import Sharing
import TanamiFoundation

extension SharedReaderKey where Self == FileStorageKey<[Simulator.ID]>.Default {
  public static var pinnedSimulators: Self {
    Self[
      .fileStorage(
        .applicationSupportDirectory
          .appending(component: Bundle.main.displayName)
          .appending(component: "pinned-simulators")
      ),
      default: .init()
    ]
  }
}
