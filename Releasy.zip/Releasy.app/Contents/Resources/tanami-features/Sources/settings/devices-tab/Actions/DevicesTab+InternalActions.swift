//
//  DevicesTab+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//


import ComposableArchitecture

extension DevicesTab {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didLoadSimulators(let simulators):
      state.simulators = simulators
      return .none
    }
  }
}
