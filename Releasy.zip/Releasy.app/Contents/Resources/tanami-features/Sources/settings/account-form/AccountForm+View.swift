//
//  AccountForm+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@ViewAction(for: AccountForm.self)
public struct AccountFormView: View {
  enum Field {
    case name, issuerID, keyID
  }

  @Dependency(\.designSystem) var designSystem

  @FocusState var focusedField: Field?
  @Bindable public var store: StoreOf<AccountForm>

  public init(store: StoreOf<AccountForm>) {
    self.store = store
  }

  public var body: some View {
    Form {
      Section {
        header
        InlineColorPicker(selected: $store.account.colorKey)
        CustomTextField($store.account.name, placeholder: L10n.accountNamePlaceholder, prompt: L10n.accountNamePrompt)
          .focused($focusedField, equals: .name)
        CustomTextField($store.account.issuerID, placeholder: L10n.issuerIdentifierPlaceholder, prompt: L10n.issuerIdentifierPrompt)
          .focused($focusedField, equals: .issuerID)
        CustomTextField($store.account.keyID, placeholder: L10n.keyIdentifierPlaceholder, prompt: L10n.keyIdentifierPrompt)
          .focused($focusedField, equals: .keyID)
        FilePlaceholder(
          key: store.account.privateKey,
          onUpdate: { send(.privateKeyUpdate(filename: $0, key: $1)) },
          onDelete: { store.account.privateKey = "" }
        )
        validate
      }
    }
    .formStyle(.grouped)
    .scrollDisabled(true)
    .frame(width: 500)
    .fixedSize()
    .onAppear { focusedField = .name }
  }
}

extension AccountFormView {
  private var header: some View {
    Text(L10n.headerTitle)
      .font(.title3)
      .foregroundStyle(.primary)
  }
  
  private var validate: some View {
    HStack {
      Button(L10n.cancelAccountButtonLabel, action: { send(.cancelButtonTapped) })
      Spacer()
      if store.loading {
        ProgressView()
          .controlSize(.small)
      } else {
        Button(action: { send(.saveButtonTapped) }) {
          switch store.mode {
          case .create: Text(L10n.createAccountButtonLabel)
          case .edit: Text(L10n.updateAccountButtonLabel)
          }
        }
        .disabled(!store.account.isValid)
      }
    }
  }
}

#if DEBUG
#Preview {
  AccountFormView(store: Store(initialState: .initial(account: .empty, mode: .create), reducer: AccountForm.init))
    .frame(height: 500)
}
#endif
