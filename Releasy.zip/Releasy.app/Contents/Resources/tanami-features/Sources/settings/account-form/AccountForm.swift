//
//  AccountForm.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppStoreConnectService
import ComposableArchitecture
import Dependencies
import Foundation
import TanamiFoundation

@Reducer
public struct AccountForm: Sendable {
  @Dependency(\.appStore) var appStore

  // MARK: - Error
  public enum AccountError: Error, Equatable, CustomStringConvertible {
    case invalidKeyID
    case invalidIssuerID
    case invalidPrivateKey
    case invalid(String)

    public var description: String {
      switch self {
      case .invalidKeyID: L10n.invalidKeyErrorMessage
      case .invalidIssuerID: L10n.invalidIssuerErrorMessage
      case .invalidPrivateKey: L10n.invalidPrivateKeyErrorMessage
      case .invalid(let message): message
      }
    }
  }

  // MARK: - Model
  public enum Mode: Sendable { case create, edit }

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    let mode: Mode
    var account: AppStoreConnect.Account
    var error: AccountError? = .invalidPrivateKey
    var loading: Bool

    /// Initializes the state with navigation path.
    init(account: AppStoreConnect.Account, mode: Mode, loading: Bool) {
      self.account = account
      self.mode = mode
      self.loading = loading
    }

    /// Provides an initial state.
    public static func initial(account: AppStoreConnect.Account, mode: Mode) -> State {
      .init(account: account, mode: mode, loading: false)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions for delegate responses.
    case delegate(Delegate)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    /// Delegate actions, typically for handling selection or navigation events.
    @CasePathable
    public enum Delegate: Equatable, Sendable {
      case didAddAccount
      case didCloseAccountForm
    }

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case accountCheckFailure(AccountError)
      case accountCheckSuccess(AppStoreConnect.Account)
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case cancelButtonTapped
      case privateKeyUpdate(filename: String, key: String)
      case saveButtonTapped
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .delegate(let action):
        return handleDelegateAction(action, state: &state)
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
