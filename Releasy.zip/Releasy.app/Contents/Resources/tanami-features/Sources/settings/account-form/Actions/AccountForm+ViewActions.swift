//
//  AccountForm+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Foundation
import TanamiFoundation

extension AccountForm {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .cancelButtonTapped:
      return .send(.delegate(.didCloseAccountForm))
    case .privateKeyUpdate(let filename, let key):
      var temp = key.split(separator: "\n")
      temp.removeFirst()
      temp.removeLast()
      if state.account.name.isEmpty {
        state.account.name = filename
      }
      state.account.privateKey = temp.joined()
      return .none
    case .saveButtonTapped:
      state.loading = true
      return .run { [account = state.account] send in
        try await Task.sleep(for: .milliseconds(500))
        try await appStore.accounts.check(account)
        await send(.internal(.accountCheckSuccess(account)))
      } catch: { error, send in
        await send(.internal(.accountCheckFailure(.invalid(error.localizedDescription))))
      }
    case .task:
      return .none
    }
  }
}
