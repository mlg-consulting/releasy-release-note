// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Account name
  internal static let accountNamePlaceholder = L10n.tr("Localizable", "account_name_placeholder", fallback: "Account name")
  /// Provide an account name
  internal static let accountNamePrompt = L10n.tr("Localizable", "account_name_prompt", fallback: "Provide an account name")
  /// Cancel
  internal static let cancelAccountButtonLabel = L10n.tr("Localizable", "cancel_account_button_label", fallback: "Cancel")
  /// Create Account
  internal static let createAccountButtonLabel = L10n.tr("Localizable", "create_account_button_label", fallback: "Create Account")
  /// App Store Connect Account
  internal static let headerTitle = L10n.tr("Localizable", "header_title", fallback: "App Store Connect Account")
  /// Issuer ID does not seems right.
  internal static let invalidIssuerErrorMessage = L10n.tr("Localizable", "invalid_issuer_error_message", fallback: "Issuer ID does not seems right.")
  /// Key ID does not seems right.
  internal static let invalidKeyErrorMessage = L10n.tr("Localizable", "invalid_key_error_message", fallback: "Key ID does not seems right.")
  /// Private Key does not seems right.
  internal static let invalidPrivateKeyErrorMessage = L10n.tr("Localizable", "invalid_private_key_error_message", fallback: "Private Key does not seems right.")
  /// Issuer ID
  internal static let issuerIdentifierPlaceholder = L10n.tr("Localizable", "issuer_identifier_placeholder", fallback: "Issuer ID")
  /// XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXX
  internal static let issuerIdentifierPrompt = L10n.tr("Localizable", "issuer_identifier_prompt", fallback: "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXX")
  /// Key ID
  internal static let keyIdentifierPlaceholder = L10n.tr("Localizable", "key_identifier_placeholder", fallback: "Key ID")
  /// XXXXXXXXXX
  internal static let keyIdentifierPrompt = L10n.tr("Localizable", "key_identifier_prompt", fallback: "XXXXXXXXXX")
  /// Save
  internal static let updateAccountButtonLabel = L10n.tr("Localizable", "update_account_button_label", fallback: "Save")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
