//
//  AccountForm+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension AccountForm {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .accountCheckFailure(let error):
      state.loading = false
      state.error = error
      return .none
    case .accountCheckSuccess(let account):
      state.error = .none
      return .run { [mode = state.mode] send in
        if mode == .edit {
          try await appStore.accounts.remove(account.id)
        }
        try await appStore.accounts.add(account)
        await send(.delegate(.didAddAccount))
        await send(.delegate(.didCloseAccountForm))
      } catch: { error, send in
        await send(.internal(.accountCheckFailure(.invalid(error.localizedDescription))))
      }
    }
  }
}
