//
//  AppsTab+SharedKey.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 31/12/2024.
//

import Foundation
import Sharing
import TanamiFoundation

extension SharedReaderKey where Self == FileStorageKey<[AppStoreConnect.Application.ID]>.Default {
  public static var pinnedApplications: Self {
    Self[
      .fileStorage(
        .applicationSupportDirectory
          .appending(component: Bundle.main.displayName)
          .appending(component: "pinned-applications")
      ),
      default: .init()
    ]
  }
}
