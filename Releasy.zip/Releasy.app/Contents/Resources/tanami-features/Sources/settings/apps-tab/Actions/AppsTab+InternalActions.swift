//
//  AppsTab+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//


import ComposableArchitecture

extension AppsTab {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .fetchAppsSuccess:
      return .none
    case .fetchAppsFailure:
      return .none
    }
  }
}
