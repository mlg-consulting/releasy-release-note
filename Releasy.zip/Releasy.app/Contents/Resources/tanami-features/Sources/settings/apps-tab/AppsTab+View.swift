//
//  AppsTab+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import DeviceKit
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@ViewAction(for: AppsTab.self)
public struct AppsTabView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.deviceClient) var devices

  @Bindable public var store: StoreOf<AppsTab>

  public init(store: StoreOf<AppsTab>) {
    self.store = store
  }

  public var body: some View {
    Form {
      Section {
        ForEach(store.appStoreConnectApps.sorted()) { app in
          AppRow(app: app, trailing: {
            favorite(for: app.id)
          })
        }
      } header: {
        Text(L10n.headerTitle)
        Text(L10n.headerDescription)
      }
    }
    .formStyle(.grouped)
    .task { send(.task) }
  }
}

extension AppsTabView {
  private func favorite(for id: AppStoreConnect.Application.ID) -> some View {
    Button(action: { send(.appDidTapped(id)) }) {
      designSystem.icon(store.pinnedApplications.contains(id) ? .starFill :.star)
        .font(.title2)
        .foregroundStyle(store.pinnedApplications.contains(id) ? .yellow : .primary)
    }
    .buttonStyle(.plain)
  }
}

#if DEBUG
#Preview {
  AppsTabView(store: Store(initialState: .initial, reducer: AppsTab.init))
}
#endif
