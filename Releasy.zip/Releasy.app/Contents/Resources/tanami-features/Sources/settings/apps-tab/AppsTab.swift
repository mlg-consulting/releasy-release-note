//
//  AppsTab.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import Foundation
import Sharing
import TanamiFoundation
import TanamiServices

@Reducer
public struct AppsTab: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.deviceClient) var device
  @Dependency(\.systemClient) var system

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectApps) var appStoreConnectApps
    @Shared(.pinnedApplications) var pinnedApplications

    /// Initializes the state with navigation path.
    init() {}

    /// Provides an initial state.
    public static var initial: State {
      .init()
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case fetchAppsSuccess
      case fetchAppsFailure(String)
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case appDidTapped(AppStoreConnect.Application.ID)
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding(let action):
        return handleBindingAction(action, state: &state)
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
