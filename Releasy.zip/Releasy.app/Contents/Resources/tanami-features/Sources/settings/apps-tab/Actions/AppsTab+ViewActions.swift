//
//  AppsTab+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture

extension AppsTab {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .appDidTapped(let id):
      if state.pinnedApplications.contains(id) {
        state.$pinnedApplications.withLock { $0.removeAll(where: { $0 == id }) }
      } else {
        state.$pinnedApplications.withLock { $0.append(id) }
      }
      return .none
    case .task:
      return .run { send in
        try await appStore.apps.fetchAll(.none)
        await send(.internal(.fetchAppsSuccess))
      } catch: { error, send in
        await send(.internal(.fetchAppsFailure(error.localizedDescription)))
      }.cancellable(id: Cancellable.task, cancelInFlight: true)
    }
  }
}

extension AppsTab {
  enum Cancellable {
    case task
  }
}
