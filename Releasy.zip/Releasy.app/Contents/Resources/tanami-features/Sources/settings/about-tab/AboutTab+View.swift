//
//  AboutTab+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import SwiftUI
import TanamiDesignSystem

@ViewAction(for: AboutTab.self)
public struct AboutTabView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  public let store: StoreOf<AboutTab>

  public init(store: StoreOf<AboutTab>) {
    self.store = store
  }

  public var body: some View {
    VStack(spacing: designSystem.spacing(.xl)) {
      header
      divider
      request
    }
    .padding(.vertical, designSystem.spacing(.xxl))
    .scrollDisabled(true)
  }
}

extension AboutTabView {
  var header: some View {
    HStack(spacing: designSystem.spacing(.l)) {
      icon
      info
    }
    .padding(.horizontal, designSystem.spacing(.xxl))
  }

  var icon: some View {
    RoundedRectangle(cornerRadius: designSystem.radius(.l))
      .foregroundStyle(.gray)
      .frame(width: 96.0, height: 96.0)
      .padding(.horizontal, designSystem.spacing(.m))
  }

  var info: some View {
    VStack(alignment: .leading) {
      Text(Bundle.main.displayName)
        .font(.system(size: 48, weight: .bold))
        .frame(maxWidth: .infinity, alignment: .leading)
      VStack(alignment: .leading, spacing: designSystem.spacing(.xs)) {
        Text(L10n.aboutVersionLabel(Bundle.main.shortVersionString))
          .foregroundStyle(.secondary)
        Text(Bundle.main.humanReadableCopyright)
          .foregroundStyle(.secondary)
      }
    }
  }

  var divider: some View {
    Divider()
      .padding(.horizontal, designSystem.spacing(.l))
  }

  var request: some View {
    VStack(alignment: .leading) {
      Text(L10n.aboutFeatureRequestTitle)
        .font(.headline)
      HStack(spacing: designSystem.spacing(.m)) {
        Text(L10n.aboutFeatureRequestSubtitle(Bundle.main.displayName))
          .font(.subheadline)
        Spacer()
        Link(destination: URL(string: "https://github.com/mlg-consulting/releasy-release-note/issues/new/choose")!) {
          Text(L10n.aboutFeatureRequestButtonLabel)
        }
        .buttonStyle(.borderedProminent)
      }
    }
    .padding(.horizontal, designSystem.spacing(.xxl))
  }
}

#if DEBUG
#Preview {
  AboutTabView(store: Store(initialState: .initial, reducer: AboutTab.init))
    .frame(width: 600)
}
#endif
