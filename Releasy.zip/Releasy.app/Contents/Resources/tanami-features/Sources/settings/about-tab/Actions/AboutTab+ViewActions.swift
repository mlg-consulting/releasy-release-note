//
//  AboutTab+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture

extension AboutTab {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .featureRequestButtonTapped:
      return .none
    case .task:
      return .none
    }
  }
}
