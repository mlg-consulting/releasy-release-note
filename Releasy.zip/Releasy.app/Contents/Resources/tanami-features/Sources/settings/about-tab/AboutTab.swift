//
//  AboutTab.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Foundation
import Sharing
import TanamiServices

@Reducer
public struct AboutTab: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    /// Initializes the state with navigation path.
    init() {}

    /// Provides an initial state.
    public static var initial: State {
      .init()
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, Sendable, Equatable {
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum View: Sendable, Equatable {
      case featureRequestButtonTapped
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    Reduce { state, action in
      switch action {
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
