//
//  AccountTab.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountForm
import ComposableArchitecture
import Dependencies
import Foundation
import TanamiFoundation
import TanamiServices

@Reducer
public struct AccountTab: Sendable {
  @Dependency(\.appStore) var appStore

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Presents var destination: Destination.State?
    @Shared(.appStoreConnectAccounts) var appStoreConnectAccounts

    /// Initializes the state.
    init() {}

    /// Provides an initial state.
    public static var initial: State {
      .init()
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions for destination interactions.
    case destination(PresentationAction<Destination.Action>)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum View: Sendable, Equatable {
      case addAccountButtonTapped
      case editAccountButtonTapped(AppStoreConnect.Account.ID)
      case removeAccountButtonTapped(AppStoreConnect.Account.ID)
      case task
    }
  }

  // MARK: - Destination
  @Reducer(state: .equatable, .sendable, action: .equatable, .sendable)
  public enum Destination {
    case accountForm(AccountForm)
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .destination(.presented(.accountForm(.delegate(let action)))):
        return handleAccountFormAction(action, state: &state)
      case .destination:
        return .none
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
    .ifLet(\.$destination, action: \.destination)
  }

  // MARK: - Inializer
  public init() {}
}
