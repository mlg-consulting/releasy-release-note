//
//  AccountTab+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountForm
import ComposableArchitecture
import Dependencies
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@ViewAction(for: AccountTab.self)
public struct AccountTabView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Bindable public var store: StoreOf<AccountTab>
  @State private var selectedAccount: AppStoreConnect.Account?

  public init(store: StoreOf<AccountTab>) {
    self.store = store
  }

  public var body: some View {
    Form {
      Section {
        List(selection: $selectedAccount) {
          rows
        }
        .listGradientButtons {
          GradientButton(style: .plus) { send(.addAccountButtonTapped) }
            .disabled(store.appStoreConnectAccounts.count > .zero)
        } minusButton: {
          GradientButton(style: .minus) {
            if let selectedAccount {
              send(.removeAccountButtonTapped(selectedAccount.id))
            }
            selectedAccount = .none
          }
          .disabled(selectedAccount == .none)
        }
        .contextMenu(forSelectionType: AppStoreConnect.Account.self) { selectionSet in
          Button(L10n.accountEditMenuLabel) {
            guard let accountId = store.appStoreConnectAccounts.first(where: { $0 == selectionSet.first })?.id else {
              return
            }
            send(.editAccountButtonTapped(accountId))
          }
        } primaryAction: { selectionSet in
          guard let accountId = store.appStoreConnectAccounts.first(where: { $0 == selectionSet.first })?.id else {
            return
          }
          send(.editAccountButtonTapped(accountId))
        }
      } header: {
        Text(L10n.headerTitle)
        Text(L10n.headerDescription)
      }
    }
    .formStyle(.grouped)
    .onTapGesture(count: 1) {
      selectedAccount = .none
    }
    .scrollDisabled(true)
    .onDisappear { selectedAccount = .none }
    .sheet(item: $store.scope(state: \.destination?.accountForm, action: \.destination.accountForm)) { store in
      AccountFormView(store: store)
    }
    .task { send(.task) }
  }
}

extension AccountTabView {
  private var rows: some View {
    ForEach(store.appStoreConnectAccounts) { account in
      Account(
        name: account.name,
        description: account.keyID,
        avatar: {
          Avatar(
            name: account.name,
            color: theme.color(.init(stringLiteral: account.colorKey))
          )
        }
      )
      .tag(account)
    }
    .onDelete { indexSet in
      guard let index = indexSet.first else { return }
      send(.removeAccountButtonTapped(store.appStoreConnectAccounts[index].id))
    }
  }
}

#if DEBUG
#Preview {
  AccountTabView(store: Store(initialState: .initial, reducer: AccountTab.init))
    .frame(height: 500)
}
#endif
