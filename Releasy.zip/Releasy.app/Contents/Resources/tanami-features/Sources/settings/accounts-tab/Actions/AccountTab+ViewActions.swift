//
//  AccountTab+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture

extension AccountTab {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .addAccountButtonTapped:
      state.destination = .accountForm(.initial(account: .empty, mode: .create))
      return .none
    case .editAccountButtonTapped(let id):
      guard let account = state.appStoreConnectAccounts.first(where: { $0.id == id }) else { return .none }
      state.destination = .accountForm(.initial(account: account, mode: .edit))
      return .none
    case .removeAccountButtonTapped(let id):
      return .run { [accounts = state.appStoreConnectAccounts] send in
        try await appStore.accounts.remove(id)
        if !accounts.isEmpty {
          try await appStore.apps.fetchAll(.none)
        }
      } catch: { error, send in
        logger.log(level: .info, method: "removeAccountButtonTapped", message: "error=[\(error)]")
      }
    case .task:
      return .none
    }
  }
}
