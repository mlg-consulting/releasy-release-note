//
//  AccountTab+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture

extension AccountTab {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .addAccountButtonTapped:
      guard state.appStoreConnectAccounts.count == .zero else { return .none }
      state.destination = .accountForm(.initial(account: .empty, mode: .create))
      return .none
    case .editAccountButtonTapped(let id):
      guard let account = state.appStoreConnectAccounts.first(where: { $0.id == id }) else { return .none }
      state.destination = .accountForm(.initial(account: account, mode: .edit))
      return .none
    case .removeAccountButtonTapped(let id):
      return .run { send in
        try await appStore.accounts.remove(id)
      }
    case .task:
      return .none
    }
  }
}
