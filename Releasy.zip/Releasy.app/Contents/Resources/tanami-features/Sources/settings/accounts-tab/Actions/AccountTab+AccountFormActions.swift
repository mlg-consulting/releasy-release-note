//
//  AccountTab+AccountFormActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountForm
import ComposableArchitecture

extension AccountTab {
  func handleAccountFormAction(_ action: AccountForm.Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didCloseAccountForm:
      state.destination = .none
      return .none
    }
  }
}
