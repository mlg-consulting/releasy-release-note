//
//  MediaTab.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Foundation
import Sharing
import TanamiServices

@Reducer
public struct MediaTab: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.mockMedia) var media: [Media]

    var selectedMedia: [Media.ID]
    var isLoading: Bool

    /// Initializes the state with navigation path.
    init(selectedMedia: [Media.ID], isLoading: Bool) {
      self.selectedMedia = selectedMedia
      self.isLoading = isLoading
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(selectedMedia: [], isLoading: false)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, Sendable, Equatable {
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Sendable, Equatable {
      case loadMediaSucceed([Media])
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case loadMedia([URL])
      case mediaDidSelect(Media.ID)
      case removeMediaButtonDidTapped
      case removeAllMediaButtonDidTapped
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    Reduce { state, action in
      switch action {
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}

extension SharedReaderKey where Self == FileStorageKey<[Media]>.Default {
  static public var mockMedia: Self {
    Self[
      .fileStorage(
        .applicationSupportDirectory
          .appending(component: Bundle.main.displayName)
          .appending(component: "media-mock")
      ),
      default: .init()
    ]
  }
}

public struct Media: Identifiable, Codable, Equatable, Sendable {
  public var id: URL { url }
  public let url: URL
  public let data: Data
  public let thumbnail: Data

  public init(url: URL, data: Data, thumbnail: Data) {
    self.url = url
    self.data = data
    self.thumbnail = thumbnail
  }
}
