//
//  MediaTab+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppKit
import ComposableArchitecture
import Foundation

extension MediaTab {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .loadMedia(let urls):
      state.isLoading = true
      let newMediaUrls = Set(urls).subtracting(Set(state.media.map(\.url)))
      return .run(priority: .utility) { send in
        let medias = await withTaskGroup(of: Media?.self, returning: [Media].self) { group in
          for url in newMediaUrls {
            guard let data = try? Data(contentsOf: url) else { continue }
            group.addTask {
              guard
                let thumbnail = NSImage(data: data)?.resized(toWidth: 100.0),
                let thumbnailData = thumbnail.jpegData
              else {
                return .none
              }
              return Media(url: url, data: data, thumbnail: thumbnailData)
            }
          }

          var medias: [Media] = []
          for await mediaSubset in group.compactMap({ $0 }) {
            medias.append(mediaSubset)
          }
          return medias
        }
        await send(.internal(.loadMediaSucceed(medias)))
      }
    case .mediaDidSelect(let mediaId):
      if state.selectedMedia.contains(mediaId) {
        state.selectedMedia.removeAll(where: { $0 == mediaId })
      } else {
        state.selectedMedia.append(mediaId)
      }
      return .none
    case .removeMediaButtonDidTapped:
      state.isLoading = true
      state.$media.withLock {
        $0.removeAll(where: { state.selectedMedia.contains($0.id) })
      }
      state.selectedMedia.removeAll()
      state.isLoading = false
      return .none
    case .removeAllMediaButtonDidTapped:
      state.isLoading = true
      state.$media.withLock { $0.removeAll() }
      state.selectedMedia.removeAll()
      state.isLoading = false
      return .none
    case .task:
      return .none
    }
  }
}

extension NSImage {
  func resized(to newSize: CGSize) -> NSImage? {
    let newImage = NSImage(size: newSize)
    newImage.lockFocus()
    let sourceRect = NSMakeRect(0, 0, size.width, size.height)
    let destRect = NSMakeRect(0, 0, newSize.width, newSize.height)
    draw(in: destRect, from: sourceRect, operation: .sourceOver, fraction: CGFloat(1))
    newImage.unlockFocus()
    return newImage
  }

  func resized(toWidth points: CGFloat) -> NSImage? {
    let ratio = points / size.width
    let height = size.height * ratio
    let newSize = CGSize(width: points, height: height)
    return resized(to: newSize)
  }

  var jpegData: Data? {
    guard let cgImage = cgImage(forProposedRect: .none, context: .none, hints: .none) else { return .none }
    let bitmapRep = NSBitmapImageRep(cgImage: cgImage)
    return bitmapRep.representation(using: .jpeg, properties: [:])
  }
}
