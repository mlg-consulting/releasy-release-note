//
//  MediaTab+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture
import TanamiFoundation

extension MediaTab {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .loadMediaSucceed(let medias):
      state.$media.withLock { $0.append(contentsOf: medias) }
      state.isLoading = false
      return .none
    }
  }
}
