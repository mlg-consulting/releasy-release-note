//
//  MediaTab+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import CoreGraphics
import Dependencies
import SwiftUI
import TanamiDesignSystem
import UniformTypeIdentifiers

extension MediaTabView {
  private enum UI {
    enum Grid {
      static let photoImageSize: CGSize = .init(width: 96.0, height: 96.0)
      static let photoImageCornerRadius: CGFloat = 4.0
      /// Spacing between columns in the grid.
      static let columSpacing: CGFloat = 12.0
      /// Spacing between rows in the grid.
      static let rowSpacing: CGFloat = 12.0
      /// Defines the columns of the grid, their sizing behavior, and spacing.
      static var columns: [GridItem] {
        [
          GridItem(
            .adaptive(minimum: UI.Grid.photoImageSize.width, maximum: UI.Grid.photoImageSize.width),
            spacing: UI.Grid.columSpacing
          )
        ]
      }
    }
  }
}

@ViewAction(for: MediaTab.self)
public struct MediaTabView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @State private var selectedImageUrl: [URL] = []
  @State private var isImporting = false

  private let mediaType: UTType = .image

  public let store: StoreOf<MediaTab>

  public init(store: StoreOf<MediaTab>) {
    self.store = store
  }

  public var body: some View {
    VStack {
      header
      gallery
    }
    .padding(designSystem.spacing(.l))
    .onTapGesture(count: 1) { selectedImageUrl.removeAll() }
    .onDisappear { selectedImageUrl.removeAll() }
    .frame(height: 500)
    .fileImporter(
      isPresented: $isImporting,
      allowedContentTypes: [mediaType],
      allowsMultipleSelection: true
    ) { result in
      if case .success(let urls) = result {
        send(.loadMedia(urls))
        Task {
          await MainActor.run {
            isImporting = false
          }
        }
      }
    }
    .task { send(.task) }
  }
}

extension MediaTabView {
  private var header: some View {
    VStack(alignment: .leading) {
      Text(L10n.headerTitle)
        .font(.headline)
      Text(L10n.headerDescription)
        .font(.subheadline)
        .foregroundStyle(.secondary)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    .padding(.horizontal, designSystem.spacing(.xs))
    .padding(.bottom, designSystem.spacing(.xxs))
  }

  private var gallery: some View {
    ScrollView {
      LazyVGrid(columns: UI.Grid.columns, spacing: UI.Grid.rowSpacing) {
        ForEach(store.media) { media in
          image(for: media.thumbnail)
            .frame(minWidth: .zero, maxWidth: .infinity, minHeight: .zero, maxHeight: .infinity)
            .aspectRatio(1.0, contentMode: .fit)
            .clipShape(.rect(cornerRadius: UI.Grid.photoImageCornerRadius))
            .overlay(alignment: .bottomTrailing) {
              if store.selectedMedia.contains(media.id) {
                designSystem.icon(.checkmarkCircleFill)
                  .foregroundStyle(.white, theme.color(.success))
                  .padding(designSystem.spacing(.xxs))
              }
            }
            .onTapGesture { send(.mediaDidSelect(media.id)) }
        }
      }
    }
    .padding(designSystem.spacing(.m))
    .padding(.bottom, designSystem.spacing(.xl))
    .overlay(alignment: .bottom) { toolbar }
    .overlay(
      RoundedRectangle(cornerRadius: designSystem.radius(.xs))
        .stroke(.tertiary, lineWidth: 0.5)
    )
  }

  private var toolbar: some View {
    VStack(alignment: .leading, spacing: .zero) {
      Divider()
      HStack(spacing: .zero) {
        GradientButton(style: .plus) { isImporting = true }
        GradientButton(style: .minus) {
          send(.removeMediaButtonDidTapped)
        }
        .disabled(store.selectedMedia.isEmpty)
        Spacer()
        if store.isLoading {
          ProgressView()
            .controlSize(.mini)
            .padding(.trailing, designSystem.spacing(.xxs))
        } else {
          Button(action: { send(.removeAllMediaButtonDidTapped) }) {
            Text(L10n.removeAllMediaButtonLabel)
          }
          .buttonStyle(.plain)
          .controlSize(.small)
          .disabled(store.media.isEmpty)
          .padding(.trailing, designSystem.spacing(.xxs))
        }
      }
      .buttonStyle(.borderless)
    }
    .background(.primary.opacity(0.04))
    .fixedSize(horizontal: false, vertical: true)
  }

  private var divider: some View {
    Divider()
      .padding(.horizontal, designSystem.spacing(.l))
  }

  @ViewBuilder
  private func image(for data: Data) -> some View {
    if let image = NSImage(data: data) {
      Image(nsImage: image)
        .resizable()
        .scaledToFill()
        .frame(minWidth: .zero, maxWidth: .infinity, minHeight: .zero, maxHeight: .infinity)
        .aspectRatio(1.0, contentMode: .fit)
    }
  }
}

#if DEBUG
#Preview {
  MediaTabView(store: Store(initialState: .initial, reducer: MediaTab.init))
    .frame(width: 600)
}
#endif
