// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// About
  internal static let tabAboutTitle = L10n.tr("Localizable", "tab_about_title", fallback: "About")
  /// Accounts
  internal static let tabAccountTitle = L10n.tr("Localizable", "tab_account_title", fallback: "Accounts")
  /// Apps
  internal static let tabAppsTitle = L10n.tr("Localizable", "tab_apps_title", fallback: "Apps")
  /// Simulators
  internal static let tabDevicesTitle = L10n.tr("Localizable", "tab_devices_title", fallback: "Simulators")
  /// General
  internal static let tabGeneralTitle = L10n.tr("Localizable", "tab_general_title", fallback: "General")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
