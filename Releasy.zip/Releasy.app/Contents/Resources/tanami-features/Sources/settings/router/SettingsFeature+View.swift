//
//  SettingsFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountTab
import AppsTab
import ComposableArchitecture
import Dependencies
import DevicesTab
import GeneralTab
import SwiftUI
import TanamiDesignSystem

@ViewAction(for: SettingsFeature.self)
public struct SettingsFeatureView: View {
  @Dependency(\.designSystem) var designSystem

  @Bindable public var store: StoreOf<SettingsFeature>

  public init(store: StoreOf<SettingsFeature>) {
    self.store = store
  }

  public var body: some View {
    TabView(selection: $store.selectedTab) {
      GeneralTabView(store: store.scope(state: \.generalTab, action: \.generalTab))
        .tabItem { Label(L10n.tabGeneralTitle, systemImage: DesignSystem.Symbols.gearshape.rawValue) }
        .tag(SettingsTab.general)
      AccountTabView(store: store.scope(state: \.accountTab, action: \.accountTab))
        .tabItem { Label(L10n.tabAccountTitle, systemImage: DesignSystem.Symbols.person2.rawValue) }
        .tag(SettingsTab.accounts)
      AppsTabView(store: store.scope(state: \.appsTab, action: \.appsTab))
        .tabItem { Label(L10n.tabAppsTitle, systemImage: DesignSystem.Symbols.appsIphone.rawValue) }
        .tag(SettingsTab.apps)
      DevicesTabView(store: store.scope(state: \.devicesTab, action: \.devicesTab))
        .tabItem { Label(L10n.tabDevicesTitle, systemImage: DesignSystem.Symbols.ipadAndIphone.rawValue) }
        .tag(SettingsTab.devices)
    }
    .frame(width: 600)
    .frame(maxHeight: 500)
    .scrollContentBackground(.hidden)
    .fixedSize()
  }
}

#if DEBUG
#Preview {
  SettingsFeatureView(store: Store(initialState: .initial, reducer: SettingsFeature.init))
}
#endif
