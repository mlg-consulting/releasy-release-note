//
//  SettingsFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountTab
import AppsTab
import ComposableArchitecture
import DevicesTab
import Foundation
import GeneralTab
import Sharing

@Reducer
public struct SettingsFeature: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.selectedTab) var selectedTab
    var accountTab: AccountTab.State
    var appsTab: AppsTab.State
    var devicesTab: DevicesTab.State
    var generalTab: GeneralTab.State

    /// Initializes the state with navigation path.
    init(
      accountTab: AccountTab.State,
      appsTab: AppsTab.State,
      devicesTab: DevicesTab.State,
      generalTab: GeneralTab.State
    ) {
      self.accountTab = accountTab
      self.appsTab = appsTab
      self.devicesTab = devicesTab
      self.generalTab = generalTab
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(
        accountTab: .initial,
        appsTab: .initial,
        devicesTab: .initial,
        generalTab: .initial
      )
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions releated to the settings account tab features.
    case accountTab(AccountTab.Action)
    /// Actions releated to the settings apps tab features.
    case appsTab(AppsTab.Action)
    /// Actions releated to the settings devices tab features.
    case devicesTab(DevicesTab.Action)
    /// Actions releated to the settings general tab features.
    case generalTab(GeneralTab.Action)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum View: Sendable, Equatable {
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Scope(state: \.accountTab, action: \.accountTab, child: AccountTab.init)
    Scope(state: \.appsTab, action: \.appsTab, child: AppsTab.init)
    Scope(state: \.devicesTab, action: \.devicesTab, child: DevicesTab.init)
    Scope(state: \.generalTab, action: \.generalTab, child: GeneralTab.init)
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .accountTab:
        return .none
      case .appsTab:
        return .none
      case .devicesTab:
        return .none
      case .generalTab:
        return .none
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
