//
//  SettingsFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AboutTab
import AccountTab
import AppsTab
import ComposableArchitecture
import DevicesTab
import Foundation
import GeneralTab
import MediaTab
import Sharing

@Reducer
public struct SettingsFeature: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.selectedTab) var selectedTab
    var aboutTab: AboutTab.State
    var accountTab: AccountTab.State
    var appsTab: AppsTab.State
    var devicesTab: DevicesTab.State
    var generalTab: GeneralTab.State
    var mediaTab: MediaTab.State

    /// Initializes the state with navigation path.
    init(
      aboutTab: AboutTab.State,
      accountTab: AccountTab.State,
      appsTab: AppsTab.State,
      devicesTab: DevicesTab.State,
      generalTab: GeneralTab.State,
      mediaTab: MediaTab.State
    ) {
      self.aboutTab = aboutTab
      self.accountTab = accountTab
      self.appsTab = appsTab
      self.devicesTab = devicesTab
      self.generalTab = generalTab
      self.mediaTab = mediaTab
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(
        aboutTab: .initial,
        accountTab: .initial,
        appsTab: .initial,
        devicesTab: .initial,
        generalTab: .initial,
        mediaTab: .initial
      )
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions releated to the settings about tab features.
    case aboutTab(AboutTab.Action)
    /// Actions releated to the settings account tab features.
    case accountTab(AccountTab.Action)
    /// Actions releated to the settings apps tab features.
    case appsTab(AppsTab.Action)
    /// Actions releated to the settings devices tab features.
    case devicesTab(DevicesTab.Action)
    /// Actions releated to the settings general tab features.
    case generalTab(GeneralTab.Action)
    /// Actions releated to the settings media tab features.
    case mediaTab(MediaTab.Action)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum View: Sendable, Equatable {
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Scope(state: \.aboutTab, action: \.aboutTab, child: AboutTab.init)
    Scope(state: \.accountTab, action: \.accountTab, child: AccountTab.init)
    Scope(state: \.appsTab, action: \.appsTab, child: AppsTab.init)
    Scope(state: \.devicesTab, action: \.devicesTab, child: DevicesTab.init)
    Scope(state: \.generalTab, action: \.generalTab, child: GeneralTab.init)
    Scope(state: \.mediaTab, action: \.mediaTab, child: MediaTab.init)
    Reduce { state, action in
      switch action {
      case .aboutTab:
        return .none
      case .accountTab:
        return .none
      case .appsTab:
        return .none
      case .binding:
        return .none
      case .devicesTab:
        return .none
      case .generalTab:
        return .none
      case .mediaTab:
        return .none
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
