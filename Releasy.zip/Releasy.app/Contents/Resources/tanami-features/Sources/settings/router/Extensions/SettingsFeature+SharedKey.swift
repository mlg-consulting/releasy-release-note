//
//  SettingsFeature+SharedKey.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 31/12/2024.
//

import Sharing

public enum SettingsTab: Int, Sendable {
  case general
  case accounts
  case apps
  case devices
}

extension SharedReaderKey where Self == AppStorageKey<SettingsTab>.Default {
  public static var selectedTab: Self {
    Self[.appStorage("selectedTab"), default: .general]
  }
}
