//
//  GeneralTab+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import UpdateService

@ViewAction(for: GeneralTab.self)
public struct GeneralTabView: View {
  @Dependency(\.designSystem) var designSystem

  @Environment(UpdateController.self) private var updateController
  @Bindable public var store: StoreOf<GeneralTab>

  public init(store: StoreOf<GeneralTab>) {
    self.store = store
  }

  public var body: some View {
    @Bindable var updateController = updateController
    Form {
      Section {
        Toggle(isOn: $store.launchAtLogin) {
          Text(L10n.openAtLoginTitle)
          Text(L10n.openAtLoginDescription(Bundle.main.displayName))
        }
        .controlSize(.large)
      }

      Section {
        Toggle(isOn: $updateController.isAutomaticUpdateCheckEnabled) {
          Text(L10n.checkForUpdateTitle)
          Text(L10n.checkForUpdateDescription(Bundle.main.displayName))
        }
        .controlSize(.large)

        Toggle(isOn: $updateController.isAutomaticUpdateDownloadEnabled) {
          Text(L10n.automaticDownloadUpdateDescription)
        }
        .controlSize(.mini)
        .disabled(!updateController.isAutomaticUpdateCheckEnabled)

        HStack(spacing: 12) {
          Spacer()

          if updateController.isCheckingForUpdates {
            ProgressView()
              .progressViewStyle(.circular)
              .controlSize(.small)
          }

          Button(L10n.checkForUpdateButtonLabel) {
            updateController.checkForUpdates()
          }
          .disabled(!updateController.canCheckForUpdates || updateController.isCheckingForUpdates)
        }
      }
    }
    .formStyle(.grouped)
    .scrollDisabled(true)
  }
}

#if DEBUG
#Preview {
  GeneralTabView(store: Store(initialState: .initial, reducer: GeneralTab.init))
}
#endif
