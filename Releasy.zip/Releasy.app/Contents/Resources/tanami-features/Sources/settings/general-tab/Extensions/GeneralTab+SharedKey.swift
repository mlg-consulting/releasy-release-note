//
//  GeneralTab+SharedKey.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 31/12/2024.
//

import Sharing

extension SharedReaderKey where Self == AppStorageKey<Bool>.Default {
  public static var launchAtLogin: Self {
    Self[.appStorage("launchAtLogin"), default: false]
  }
}
