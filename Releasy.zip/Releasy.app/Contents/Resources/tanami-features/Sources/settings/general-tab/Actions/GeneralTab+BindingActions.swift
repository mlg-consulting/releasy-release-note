//
//  GeneralTab+BindingActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 01/01/2025.
//

import ComposableArchitecture

extension GeneralTab {
  func handleBindingAction(_ action: BindingAction<State>, state: inout State) -> EffectOf<Self> {
    switch action {
    case \.launchAtLogin:
      system.launchAtLogin(state.launchAtLogin)
      return .none
    default:
      return .none
    }
  }
}
