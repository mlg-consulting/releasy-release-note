// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Canceled
  internal static let buildRunCompletionCanceledLabel = L10n.tr("Localizable", "build_run_completion_canceled_label", fallback: "Canceled")
  /// Errored
  internal static let buildRunCompletionErroredLabel = L10n.tr("Localizable", "build_run_completion_errored_label", fallback: "Errored")
  /// Failed
  internal static let buildRunCompletionFailedLabel = L10n.tr("Localizable", "build_run_completion_failed_label", fallback: "Failed")
  /// Skipped
  internal static let buildRunCompletionSkippedLabel = L10n.tr("Localizable", "build_run_completion_skipped_label", fallback: "Skipped")
  /// Succeeded
  internal static let buildRunCompletionSucceededLabel = L10n.tr("Localizable", "build_run_completion_succeeded_label", fallback: "Succeeded")
  /// Complete
  internal static let buildRunExecutionCompleteLabel = L10n.tr("Localizable", "build_run_execution_complete_label", fallback: "Complete")
  /// Pending
  internal static let buildRunExecutionPendingLabel = L10n.tr("Localizable", "build_run_execution_pending_label", fallback: "Pending")
  /// Running
  internal static let buildRunExecutionRunningLabel = L10n.tr("Localizable", "build_run_execution_running_label", fallback: "Running")
  /// Recent builds
  internal static let menuRecentBuildsSectionTitle = L10n.tr("Localizable", "menu_recent_builds_section_title", fallback: "Recent builds")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
