//
//  RecentBuildFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppStoreConnectService
import ComposableArchitecture
import Dependencies
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import Workflow

@ViewAction(for: RecentBuildFeature.self)
public struct RecentBuildFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Environment(\.scenePhase) private var scenePhase

  @Bindable public var store: StoreOf<RecentBuildFeature>

  public init(store: StoreOf<RecentBuildFeature>) {
    self.store = store
  }

  public var body: some View {
    DevicePicker(title: L10n.menuRecentBuildsSectionTitle, action: {}, isLoading: store.isLoading) {
      VStack(alignment: .leading, spacing: designSystem.spacing(.xs)) {
        ForEach(store.buildRuns.prefix(5)) { buildRun in
          if let recentBuild = recentBuild(for: buildRun), let app = app(for: recentBuild) {
            RecentBuildRow(app: app, buildRun: buildRun, sourceBranchOrTag: recentBuild.sourceBranchOrTag)
              .menuBackgroundOnHover(color: .primary.opacity(0.1))
          }
        }
      }
    }
    .onChange(of: scenePhase) { oldValue, newValue in
      if newValue == .active {
        Task(priority: .userInitiated) { send(.task) }
      }
    }
    .onChange(of: store.currentAccountId) { _, _ in
      send(.task)
    }
  }
}

extension RecentBuildFeatureView {
  func recentBuild(for buildRun: AppStoreConnect.CIBuildRun) -> RecentBuild? {
    store.recentBuilds.first(where: { $0.id == buildRun.id })
  }

  func app(for recentBuild: RecentBuild?) -> AppStoreConnect.Application? {
    store.appStoreConnectApps.first(where: { $0.id == recentBuild?.applicationId })
  }
}

#if DEBUG
#Preview {
  RecentBuildFeatureView(store: Store(initialState: .initial, reducer: RecentBuildFeature.init))
}
#endif
