//
//  RecentBuildFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture
import Foundation

extension RecentBuildFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .fetchBuildSuccess(let buildRuns):
      state.buildRuns = buildRuns.sorted(by: { $0.startAt ?? Date() < $1.startAt ?? Date() })
      state.isLoading = false
      return .none
    case .fetchBuildFailure:
      state.isLoading = false
      return .none
    }
  }
}
