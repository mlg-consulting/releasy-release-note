//
//  RecentBuildFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import TanamiFoundation
import Workflow

extension RecentBuildFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .task:
      state.isLoading = true
      return .run(priority: .utility) { [builds = state.recentBuilds.elements] send in
        let buildRuns = try await loadBuildRuns(for: builds)
        await send(.internal(.fetchBuildSuccess(buildRuns)))
      } catch: { error, send in
        await send(.internal(.fetchBuildFailure(error.localizedDescription)))
      }.cancellable(id: Cancellable.task, cancelInFlight: true)
    }
  }

  private func loadBuildRuns(for builds: [RecentBuild]) async throws -> [AppStoreConnect.CIBuildRun] {
    try await withThrowingTaskGroup(
      of: AppStoreConnect.CIBuildRun?.self,
      returning: [AppStoreConnect.CIBuildRun].self
    ) { group in
      for build in builds {
        group.addTask {
          try await appStore.ci.buildRun(build.id)
        }
      }

      var buildRuns: [AppStoreConnect.CIBuildRun] = []
      for try await buildRun in group.compactMap({ $0 }) {
        buildRuns.append(buildRun)
      }
      return buildRuns
    }
  }
}

extension RecentBuildFeature {
  enum Cancellable {
    case task
  }
}
