//
//  ApplicationFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import DeviceKit
import PullRequest
import Release
import SettingsRouter
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@ViewAction(for: ApplicationFeature.self)
public struct ApplicationFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Shared(.selectedTab) var selectedTab

  @Environment(\.scenePhase) private var scenePhase
  @Environment(\.showPullRequestWindow) private var showPullRequestWindow
  @Environment(\.showReleaseWindow) private var showReleaseWindow

  @Bindable public var store: StoreOf<ApplicationFeature>

  public init(store: StoreOf<ApplicationFeature>) {
    self.store = store
  }

  public var body: some View {
    DevicePicker(title: L10n.menuApplicationSectionTitle, action: { settings }, isLoading: store.isLoading) {
      VStack(spacing: designSystem.spacing(.xs)) {
        ForEach(store.applications) { app in
          AppRow(
            app: app,
            showDetails: false,
            trailing: {
              if store.selectedApplications.contains(app.id) {
                designSystem.icon(.checkmarkCircleFill).foregroundStyle(theme.color(.success))
              } else {
                menu(for: app)
              }
            },
            onTapped: { send(.selectApplication(app.id)) }
          )
          .menuBackgroundOnHover(color: .primary.opacity(0.1))
          .contextMenu { menuOptions(for: app) }
        }
        VStack(alignment: .leading, spacing: .zero) {
          release
          selected
        }
      }
    }
    .onChange(of: scenePhase) { oldValue, newValue in
      if newValue == .active {
        Task(priority: .userInitiated) { send(.task) }
      }
    }
  }
}

extension ApplicationFeatureView {
  private var release: some View {
    Button(
      action: {
        showReleaseWindow?.callAsFunction(
          store: Store(
            initialState: .initial(appIds: store.selectedApplications),
            reducer: ReleaseFeature.init
          )
        )
      },
      label: { Text(L10n.releaseApplicationButtonLabel) }
    )
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true, disabled: !store.createNewVersionEnabled))
  }

  private var selected: some View {
    Button(action: { send(.deselectAllApplicationButtonTapped) }) {
      HStack {
        Text(L10n.menuApplicationDeselectAllLabel)
        Spacer()
        if !store.selectedApplications.isEmpty {
          Text(L10n.menuApplicationSelectedCount(store.selectedApplications.count))
            .foregroundStyle(.secondary)
        }
      }
    }
    .buttonStyle(.menuItem(activatesApplication: true, blinks: true, disabled: store.selectedApplications.isEmpty))
  }

  private var settings: some View {
    Group {
      SettingsLink {
        Text(L10n.addApplicationButtonLabel)
      }
      .buttonStyle(
        SettingsLinkActionButtonStyle {
          $selectedTab.withLock { $0 = .apps }
        }
      )
    }
    .buttonStyle(InlineButtonStyle())
  }

  private func menu(for app: AppStoreConnect.Application) -> some View {
    Menu {
      menuOptions(for: app)
    } label: {
      if !store.selectedApplications.contains(app.id) {
        designSystem.icon(.ellipsisCircle)
          .foregroundColor(.secondary)
      }
    }
    .buttonStyle(.plain)
  }

  @ViewBuilder
  private func menuOptions(for app: AppStoreConnect.Application) -> some View {
    Button(L10n.menuApplicationArtifactsLabel) {
      showPullRequestWindow?.callAsFunction(
        store: Store(
          initialState: .initial(appId: app.id),
          reducer: PullRequestFeature.init
        )
      )
    }
    Divider()
    if !store.selectedApplications.contains(app.id) {
      Divider()
      Button(L10n.menuApplicationUnfavoriteLabel) { send(.removeFavoriteButtonTapped(app.id)) }
    }
  }
}

#if DEBUG
#Preview {
  ApplicationFeatureView(store: Store(initialState: .initial, reducer: ApplicationFeature.init))
}
#endif
