//
//  ApplicationFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension ApplicationFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .fetchAppsSuccess:
      state.isLoading = false
      return .none
    case .fetchAppsFailure:
      state.isLoading = false
      return .none
    }
  }
}
