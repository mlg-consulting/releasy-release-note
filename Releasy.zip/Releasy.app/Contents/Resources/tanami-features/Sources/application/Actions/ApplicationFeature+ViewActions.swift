//
//  ApplicationFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import TanamiFoundation

extension ApplicationFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .deselectAllApplicationButtonTapped:
      state.selectedApplications.removeAll()
      return .none
    case .removeFavoriteButtonTapped(let id):
      state.$pinnedApplications.withLock { $0.removeAll(where: { $0 == id }) }
      return .none
    case .selectApplication(let id):
      if state.selectedApplications.contains(id) {
        state.selectedApplications.removeAll(where: { $0 == id})
      } else {
        state.selectedApplications.append(id)
      }
      return .none
    case .task:
      state.isLoading = true
      state.selectedApplications = Array(
        Set(state.selectedApplications).intersection(Set(state.pinnedApplications))
      )
      return .run { [ids = state.pinnedApplications] send in
        try await appStore.apps.fetchAll(ids)
        await send(.internal(.fetchAppsSuccess))
      } catch: { error, send in
        await send(.internal(.fetchAppsFailure(error.localizedDescription)))
      }.cancellable(id: Cancellable.task, cancelInFlight: true)
    }
  }
}

extension ApplicationFeature {
  enum Cancellable {
    case task
  }
}
