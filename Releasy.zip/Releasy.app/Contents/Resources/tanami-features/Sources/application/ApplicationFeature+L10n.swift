// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Add Applications
  internal static let addApplicationButtonLabel = L10n.tr("Localizable", "add_application_button_label", fallback: "Add Applications")
  /// Show Available Artifacts…
  internal static let menuApplicationArtifactsLabel = L10n.tr("Localizable", "menu_application_artifacts_label", fallback: "Show Available Artifacts…")
  /// Deselect All
  internal static let menuApplicationDeselectAllLabel = L10n.tr("Localizable", "menu_application_deselect_all_label", fallback: "Deselect All")
  /// Configure Provider…
  internal static let menuApplicationRecipeLabel = L10n.tr("Localizable", "menu_application_recipe_label", fallback: "Configure Provider…")
  /// Applications
  internal static let menuApplicationSectionTitle = L10n.tr("Localizable", "menu_application_section_title", fallback: "Applications")
  /// %d Selected
  internal static func menuApplicationSelectedCount(_ p1: Int) -> String {
    return L10n.tr("Localizable", "menu_application_selected_count", p1, fallback: "%d Selected")
  }
  /// Unfavorite
  internal static let menuApplicationUnfavoriteLabel = L10n.tr("Localizable", "menu_application_unfavorite_label", fallback: "Unfavorite")
  /// Create New Release…
  internal static let releaseApplicationButtonLabel = L10n.tr("Localizable", "release_application_button_label", fallback: "Create New Release…")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
