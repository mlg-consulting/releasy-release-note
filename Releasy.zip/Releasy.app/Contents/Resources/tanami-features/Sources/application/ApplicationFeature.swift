//
//  ApplicationFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AccountTab
import ComposableArchitecture
import DevicesTab
import DeviceKit
import Foundation
import GeneralTab
import Sharing
import TanamiFoundation
import XcodeCloudProvider

@Reducer
public struct ApplicationFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.deviceClient) var device
  @Dependency(\.systemClient) var system

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectApps) var appStoreConnectApps
    @Shared(.pinnedApplications) var pinnedApplications
    @Shared(.recipes) var recipes

    var isLoading: Bool

    var applications: [AppStoreConnect.Application] {
      appStoreConnectApps.filter { pinnedApplications.contains($0.id) }.sorted()
    }

    var createNewVersionEnabled: Bool {
      !selectedApplications.isEmpty
      && applications
        .filter { selectedApplications.contains($0.id) }
        .compactMap(\.status)
        .allSatisfy { $0 == .readyForDistribution }
    }

    var selectedApplications: [AppStoreConnect.Application.ID]

    /// Initializes the state with navigation path.
    init(selectedApplications: [AppStoreConnect.Application.ID], isLoading: Bool) {
      self.selectedApplications = selectedApplications
      self.isLoading = isLoading
    }

    /// Provides an initial state.
    public static var initial: State {
      .init(selectedApplications: [], isLoading: false)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case fetchAppsSuccess
      case fetchAppsFailure(String)
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case deselectAllApplicationButtonTapped
      case removeFavoriteButtonTapped(AppStoreConnect.Application.ID)
      case selectApplication(AppStoreConnect.Application.ID)
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
