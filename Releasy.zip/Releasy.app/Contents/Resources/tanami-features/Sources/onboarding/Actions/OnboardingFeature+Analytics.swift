//
//  OnboardingFeature+Analytics.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AnalyticsService
import ComposableArchitecture

extension OnboardingFeature {
  func handleAnalyticAction(_ action: Action.Analytic, state: inout State) -> EffectOf<Self> {
    switch action {
    case .appStoreInfoPopoverTapped:
      analytics.send(Feature.Onboarding.AppStore.InfoPopover.tapped)
    case .onAppear:
      analytics.send(App.Window.enter(.onboarding))
    case .xcodeInfoPopoverTapped:
      analytics.send(Feature.Onboarding.Xcode.InfoPopover.tapped)
    case .validate:
      analytics.send(Feature.Onboarding.validate)
    }
    return .none
  }
}
