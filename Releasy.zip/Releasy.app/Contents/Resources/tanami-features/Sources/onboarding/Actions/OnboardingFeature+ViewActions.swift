//
//  OnboardingFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture

extension OnboardingFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .onAppear:
      return.send(.analytic(.onAppear))
    case .task:
      return .none
    }
  }
}
