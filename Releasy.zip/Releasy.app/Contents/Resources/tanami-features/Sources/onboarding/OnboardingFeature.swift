//
//  SettingsFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AnalyticsService
import ComposableArchitecture
import Foundation

@Reducer
public struct OnboardingFeature: Sendable {
  @Dependency(\.analytics) var analytics

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    init() {}

    /// Provides an initial state.
    public static var initial: State {
      .init()
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to analytics.
    case analytic(Analytic)
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Analytic: Equatable, Sendable {
      case appStoreInfoPopoverTapped
      case onAppear
      case xcodeInfoPopoverTapped
      case validate
    }
    @CasePathable
    public enum View: Sendable, Equatable {
      case onAppear
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .analytic(let action):
        return handleAnalyticAction(action, state: &state)
      case .binding:
          return .none
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
