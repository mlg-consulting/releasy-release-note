//
//  SettingsFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Foundation

@Reducer
public struct OnboardingFeature: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    init() {}

    /// Provides an initial state.
    public static var initial: State {
      .init()
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum View: Sendable, Equatable {
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
          return .none
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
