//
//  AppStoreOnboardingItem.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Dependencies
import SettingsRouter
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

struct AppStoreOnboardingItem: View {
  @Dependency(\.designSystem) var designSystem

  @Shared(.appStoreConnectAccounts) var appStoreConnectAccounts
  @Shared(.selectedTab) var selectedTab

	@Environment(\.controlActiveState) private var controlActiveState

	var body: some View {
    ItemLayout(title: L10n.checklistAppStoreTitle, description: L10n.checklistAppStoreSubtitle(Bundle.main.displayName)) {
      Image(.appStoreConnect)
				.resizable()
        .interpolation(.high)
        .padding(designSystem.spacing(.xxs))
		} infoPopoverContent: {
      PopoverContent(title: L10n.popoverAppStoreTitle) {
				Text("API Key can be created from the [App Store Connect](https://appstoreconnect.apple.com/access/integrations/api). From the Users and Access > Integrations > Team Keys section, create a new API Key with “App Manager“ access role.")
					.lineLimit(3, reservesSpace: true)
			}
		} content: {
      if !appStoreConnectAccounts.isEmpty {
        ItemStatusIcon(state: .complete)
      } else {
        SettingsLink {
          Text(L10n.checklistAppStoreAccountButtonLabel)
        }
        .buttonStyle(
          SettingsLinkActionButtonStyle {
            $selectedTab.withLock { $0 = .accounts }
          }
        )
      }
		}
	}
}

#Preview {
  AppStoreOnboardingItem()
}
