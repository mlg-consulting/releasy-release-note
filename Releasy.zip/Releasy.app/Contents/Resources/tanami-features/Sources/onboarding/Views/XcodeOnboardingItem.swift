//
//  XcodeOnboardingItem.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

struct XcodeOnboardingItem: View {
	@Environment(\.appearsActive) private var appearsActive
	@State private var isComplete = Self.isCommandLineToolReachable

	var body: some View {
		ItemLayout(title: L10n.checklistXcodeTitle, description: L10n.checklistXcodeSubtitle(Bundle.main.displayName)) {
			Image(.xcode)
				.resizable()
				.interpolation(.high)
		} infoPopoverContent: {
      PopoverContent(title: L10n.popoverXcodeTitle) {
				Text("Xcode can be downloaded from the [Apple Developer Portal](https://developer.apple.com/download/applications/) or by using [xcodes](https://github.com/RobotsAndPencils/xcodes). Make sure to open Xcode to install the Xcode Command Line Tools and the latest SDKs.")
					.lineLimit(3, reservesSpace: true)
			}
		} content: {
			ItemStatusIcon(state: isComplete ? .complete : .warning) {
        PopoverContent(title: L10n.popoverXcodeContentTitle) {
          Text(L10n.popoverXcodeContentDescription(Bundle.main.displayName))
						.lineLimit(2, reservesSpace: true)
				}
			}
		}
		.onChange(of: appearsActive) { newValue, _ in
      if newValue {
				updateStatus()
			}
		}
	}

	private func updateStatus() {
		let newValue = Self.isCommandLineToolReachable

		if self.isComplete != newValue {
			self.isComplete = newValue
		}
	}

	private static var isCommandLineToolReachable: Bool {
		URL(filePath: "/usr/bin/xcrun").isReachable
	}
}

#Preview {
  XcodeOnboardingItem()
}
