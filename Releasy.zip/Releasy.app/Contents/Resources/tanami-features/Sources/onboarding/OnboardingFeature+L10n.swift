// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Version %s
  internal static func appVersion(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "app_version", p1, fallback: "Version %s")
  }
  /// Start Using %s
  internal static func buttonTitle(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "button_title", p1, fallback: "Start Using %s")
  }
  /// Account…
  internal static let checklistAppStoreAccountButtonLabel = L10n.tr("Localizable", "checklist_app_store_account_button_label", fallback: "Account…")
  /// %s uses App Store Connect to get and manage apps.
  internal static func checklistAppStoreSubtitle(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "checklist_app_store_subtitle", p1, fallback: "%s uses App Store Connect to get and manage apps.")
  }
  /// App Store Connect
  internal static let checklistAppStoreTitle = L10n.tr("Localizable", "checklist_app_store_title", fallback: "App Store Connect")
  /// Make sure the following developer tools are set for %s to work efficiently.
  internal static func checklistTitle(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "checklist_title", p1, fallback: "Make sure the following developer tools are set for %s to work efficiently.")
  }
  /// %s uses Xcode to manage devices and install apps.
  internal static func checklistXcodeSubtitle(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "checklist_xcode_subtitle", p1, fallback: "%s uses Xcode to manage devices and install apps.")
  }
  /// Xcode
  internal static let checklistXcodeTitle = L10n.tr("Localizable", "checklist_xcode_title", fallback: "Xcode")
  /// Getting Started
  internal static let popoverAppStoreTitle = L10n.tr("Localizable", "popover_app_store_title", fallback: "Getting Started")
  /// %s needs Xcode in order to be able to install apps on Apple devices.
  internal static func popoverXcodeContentDescription(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "popover_xcode_content_description", p1, fallback: "%s needs Xcode in order to be able to install apps on Apple devices.")
  }
  /// Needs Setup
  internal static let popoverXcodeContentTitle = L10n.tr("Localizable", "popover_xcode_content_title", fallback: "Needs Setup")
  /// Getting Started
  internal static let popoverXcodeTitle = L10n.tr("Localizable", "popover_xcode_title", fallback: "Getting Started")
  /// Welcome to %s
  internal static func welcomeTitle(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "welcome_title", p1, fallback: "Welcome to %s")
  }
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
