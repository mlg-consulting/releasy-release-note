//
//  OnboardingFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import SystemService
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

extension OnboardingFeatureView {
  private enum UI {
    static let iconSize: CGSize = .init(width: 128.0, height: 128.0)
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 28.0, trailing: 8.0)
    static let spacing: CGFloat = 32.0
  }
}

@ViewAction(for: OnboardingFeature.self)
public struct OnboardingFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.systemClient) var system

  @Shared(.appStoreConnectAccounts) var appStoreConnectAccounts

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @Bindable public var store: StoreOf<OnboardingFeature>

  public init(store: StoreOf<OnboardingFeature>) {
    self.store = store
  }

  public var body: some View {
    VStack(alignment: .center, spacing: UI.spacing) {
      header
      VStack(spacing: .zero) {
        checklist
        validate
      }
    }
    .padding(UI.padding)
    .frame(width: 600)
    .frame(maxHeight: 600)
    .scrollContentBackground(.hidden)
    .fixedSize()
    .onAppear { send(.onAppear) }
    .showDockIconWhenOpen()
  }
}

extension OnboardingFeatureView {
  private var header: some View {
    VStack(spacing: designSystem.spacing(.xs)) {
      Image(.appIcon)
        .resizable()
        .scaledToFit()
        .frame(width: UI.iconSize.width, height: UI.iconSize.height)

      Text(L10n.welcomeTitle(Bundle.main.displayName))
        .font(.largeTitle)
        .foregroundColor(.primary)

      Text(L10n.appVersion(Bundle.main.shortVersionString))
        .foregroundColor(.secondary)
    }
  }

  @ViewBuilder
  private var checklist: some View {
    Text(L10n.checklistTitle(Bundle.main.displayName))
      .font(.body)
      .foregroundColor(.primary)
      .padding(.horizontal, 56.0)

    Form {
      Section {
        AppStoreOnboardingItem()
      }
      Section {
        XcodeOnboardingItem()
      }
    }
    .formStyle(.grouped)
    .scrollDisabled(true)
  }

  private var validate: some View {
    Button(L10n.buttonTitle(Bundle.main.displayName)) {
      store.send(.analytic(.validate))
      customWindowPresentation?.dismiss()
    }
    .controlSize(.large)
    .keyboardShortcut(.return)
  }
}

#Preview {
  OnboardingFeatureView(store: Store(initialState: .initial, reducer: OnboardingFeature.init))
}
