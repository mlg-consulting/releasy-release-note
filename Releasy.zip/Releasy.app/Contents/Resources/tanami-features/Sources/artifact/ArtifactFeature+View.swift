//
//  ArtifactFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import TanamiServices

extension ArtifactFeatureView {
  private enum UI {
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
  }
}

@ViewAction(for: ArtifactFeature.self)
public struct ArtifactFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @State private var animate: Bool = false
  @Bindable public var store: StoreOf<ArtifactFeature>

  public init(store: StoreOf<ArtifactFeature>) {
    self.store = store
  }

  public var body: some View {
    artifact
      .task { send(.task) }
  }
}

extension ArtifactFeatureView {
  @ViewBuilder
  private var artifact: some View {
    if store.buildRun.status == .succeeded {
      if [ArtifactState.downloading, .extract, .clean, .complete].contains(store.artifactState) {
        status
      } else if store.isLoading {
        progress
      } else if store.buildRun.artifactAvailable == true {
        menu
      } else {
        actions
      }
    } else if store.buildRun.status == .failed {
      if store.isLoading {
        progress
      } else {
        startBuild
      }
    }
  }

  private var menu: some View {
    Menu {
      if store.isSimulatorArtifactAvailable {
        Button(L10n.artifactInstallAllSimulatorsButtonLabel) {
          send(.installArtifactSimulatorButtonDidTapped(store.simulators))
        }
      }
      Divider()
      devices
      Divider()
      simulators
    } label: {
      designSystem.icon(.shippingbox).padding(designSystem.spacing(.xxs))
    }
    .buttonStyle(.plain)
  }

  private var status: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(store.artifactState.description)
        .font(.caption)
      ProgressView(value: store.artifactState.value)
        .progressViewStyle(.circular)
        .controlSize(.small)
    }
    .foregroundStyle(Color.accentColor)
    .frame(height: 24.0)
  }

  private var progress: some View {
    ProgressView()
      .controlSize(.small)
      .frame(height: 24.0)
  }

  private var actions: some View {
    Menu {
      Button(L10n.artifactDownloadForDeviceLabel) {
        send(.downloadArtifactButtonDidTapped(.device))
      }
      Button(L10n.artifactDownloadForSimulatorLabel) {
        send(.downloadArtifactButtonDidTapped(.simulator))
      }
    } label: {
      artifactIcon.frame(width: 24.0, height: 24.0)
    }
    .buttonStyle(.plain)
  }

  private var artifactIcon: some View {
    switch store.artifactState {
    case .idle: designSystem.icon(.icloudAndArrowDown)
    case .downloading: designSystem.icon(.slowmo)
    case .extract: designSystem.icon(.zipperPage)
    case .clean: designSystem.icon(.hourglass)
    case .complete: designSystem.icon(.checkmarkCircle)
    case .error: designSystem.icon(.exclamationmarkCircle)
    }
  }

  private var startBuild: some View {
    Button(
      action: { send(.startBuildButtonDidTapped) },
      label: { designSystem.icon(.arrowCounterclockwise).frame(width: 24.0, height: 24.0) }
    )
    .buttonStyle(.plain)
  }

  @ViewBuilder
  private var devices: some View {
    Text(L10n.artifactSectionDevicesLabel)
    if !store.isDeviceArtifactAvailable {
      Button(L10n.artifactDownloadForDeviceLabel) {
        send(.downloadArtifactButtonDidTapped(.device))
      }
    } else {
      ForEach(store.devices) { device in
        Button("\(device.name) - \(device.runtime.description)") {
          send(.installArtifactDeviceButtonDidTapped(device))
        }
      }
      Button(L10n.artifactCleanButtonLabel) {
        send(.cleanArtifactButtonDidTapped(.device))
      }
    }
  }

  @ViewBuilder
  private var simulators: some View {
    Text(L10n.artifactSectionSimulatorsLabel)
    if !store.isSimulatorArtifactAvailable {
      Button(L10n.artifactDownloadForSimulatorLabel) {
        send(.downloadArtifactButtonDidTapped(.simulator))
      }
    } else {
      ForEach(store.simulators) { simulator in
        Button("\(simulator.name) - \(simulator.runtime.description)") {
          send(.installArtifactSimulatorButtonDidTapped([simulator]))
        }
      }
      Button(L10n.artifactCleanButtonLabel) {
        send(.cleanArtifactButtonDidTapped(.simulator))
      }
    }
  }
}

extension ArtifactState {
  var description: String {
    switch self {
    case .idle: "waiting"
    case .downloading: "downloading"
    case .extract: "extracting"
    case .clean: "cleaning"
    case .complete: "complete"
    case .error: "failure"
    }
  }

  var value: CGFloat {
    switch self {
    case .idle: 0.0
    case .downloading: 0.15
    case .extract: 0.5
    case .clean: 0.7
    case .complete, .error: 1.0
    }
  }
}

#if DEBUG
#Preview("Default") {
  ArtifactFeatureView(
    store: Store(
      initialState: .initial(
        bundleId: AppStoreConnect.Application.mock.bundleId,
        workflowId: AppStoreConnect.CIWorkflow.mock.id,
        buildRun: .mock,
        devices: [],
        simulators: []
      ),
      reducer: ArtifactFeature.init
    )
  )
}
#endif
