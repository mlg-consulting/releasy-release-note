//
//  ArtifactFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import TanamiFoundation

extension ArtifactFeature {
  func handleDelegateAction(_ action: Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    case .artifactContainerDidLoad:
      return .none
    case .installArtifactDidFail:
      return .none
    case .requestUnlockDevice:
      return .none
    }
  }
}
