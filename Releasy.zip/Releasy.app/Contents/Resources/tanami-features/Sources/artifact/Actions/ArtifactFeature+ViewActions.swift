//
//  ArtifactFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppStoreConnectService
import ComposableArchitecture
import DeviceKit
import TanamiFoundation

extension ArtifactFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .cleanArtifactButtonDidTapped(let plateform):
      guard let container = state.appStoreArtifacts
        .first(where: { $0.buildRunId == state.buildRun.id && $0.plateform == plateform })
      else {
        return .none
      }
      try? container.delete()
      state.$appStoreArtifacts.withLock {
        $0.removeAll(where: { $0.buildRunId == state.bundleId })
      }
      return .none
    case .installArtifactDeviceButtonDidTapped(let device):
      guard let container = state.appStoreArtifacts
        .first(where: { $0.buildRunId == state.buildRun.id && $0.plateform == .device })
      else {
        return .none
      }
      state.isLoading = true
      return .run { [bundleId = state.bundleId] send in
        let application = DeviceKit.Application(url: container.localUrl, bundleIdentifier: bundleId)
        if try await device.isLocked {
          await send(.delegate(.requestUnlockDevice(L10n.deviceRequestUnlockLabel(device.name))))
        }
        try await device.waitUntilUnlocked()
        try device.install(application: application)
        try device.launch(application: application)
        await send(.internal(.installArtifactComplete))
      } catch: { error, send in
        logger.log(level: .error, method: "installArtifactDeviceDidFail", message: "error=[\(error)]")
        await send(.internal(.installArtifactFailure(error.localizedDescription)))
      }
    case .installArtifactSimulatorButtonDidTapped(let simulators):
      guard let container = state.appStoreArtifacts
        .first(where: { $0.buildRunId == state.buildRun.id && $0.plateform == .simulator })
      else {
        return .none
      }
      state.isLoading = true
      return .run { [bundleId = state.bundleId] send in
        let application = DeviceKit.Application(url: container.localUrl, bundleIdentifier: bundleId)
        for simulator in simulators {
          switch await device.status(simulator.id) {
          case .idle: try await simulator.boot()
          case .ready: try simulator.focus()
          case .unknown: break
          }
          try simulator.install(application: application)
          try simulator.launch(application: application)
          await send(.internal(.installArtifactComplete))
        }
      } catch: { error, send in
        logger.log(level: .error, method: "installArtifactSimulatorDidFail", message: "error=[\(error)]")
        await send(.internal(.installArtifactFailure(error.localizedDescription)))
      }
    case .downloadArtifactButtonDidTapped(let plateform):
      state.isLoading = true
      return .run { [buildRunId = state.buildRun.id] send in
        let buildActions = try await appStore.ci.buildActions(buildRunId)
          .filter({ $0.type == .build && $0.plateform == plateform })
        var containers: [AppStoreConnect.ArtifactContainer] = []
        for buildAction in buildActions {
          let packages = try await appStore.ci.artifacts(buildAction.id)
          guard
            let plateform = buildAction.plateform,
            let package = packages.first(where: { $0.type == .xcodebuildProducts }),
            let url = try await artifact.unpack(buildRunId, plateform, package)
          else {
            continue
          }
          let container = AppStoreConnect.ArtifactContainer(
            id: package.id, buildRunId: buildRunId, plateform: buildAction.plateform, localUrl: url
          )
          containers.append(container)
        }
        await send(.internal(.artifactContainersDidLoad(containers)))
      } catch: { error, send in
        logger.log(level: .error, method: "downloadArtifactDidFail", message: "error=[\(error)]")
      }
    case .startBuildButtonDidTapped:
      guard let workflowId = state.workflowId else { return .none }
      state.isLoading = true
      return .run { [buildRunId = state.buildRun.id] send in
        let buildRun = try await appStore.ci.startBuildRun(workflowId, buildRunId)
        await send(.internal(.buildRunDidLoad(buildRun)))
      } catch: { error, send in
        logger.log(level: .error, method: "startBuildDidFail", message: "error=[\(error)]")
      }
    case .task:
      return .run { [bunbleRunId = state.buildRun.id] send in
        for await progress in await artifact.progress() {
          guard let artifactProgress = progress[bunbleRunId] else { continue }
          logger.log(
            level: .info,
            method: "artifactProgress",
            message: "progress=[\(artifactProgress)] bundleRunId=[\(bunbleRunId)]"
          )
          await send(.internal(.artifactStateDidUpdate(artifactProgress)))
        }
      }
    }
  }
}
