//
//  ArtifactFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import DeviceKit
import TanamiFoundation
import TanamiServices

extension ArtifactFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .cleanArtifactButtonDidTapped:
      guard let container = state.appStoreArtifacts.first(where: { $0.buildRunId == state.buildRun.id }) else {
        return .none
      }
      try? container.delete()
      state.$appStoreArtifacts.withLock {
        $0.removeAll(where: { $0.buildRunId == state.bundleId })
      }
      return .none
    case .installArtifactDeviceButtonDidTapped(let device):
      guard let container = state.appStoreArtifacts.first(where: { $0.buildRunId == state.buildRun.id }) else {
        return .none
      }
      return .run { [bundleId = state.bundleId] send in
        let application = DeviceKit.Application(url: container.localUrl, bundleIdentifier: bundleId)
        try await device.waitUntilUnlocked()
        try device.install(application: application)
        try device.launch(application: application)
      } catch: { error, send in
        logger.log(level: .error, method: "installArtifactDeviceDidFail", message: "error=[\(error)]")
      }
    case .installArtifactSimulatorButtonDidTapped(let simulators):
      guard let container = state.appStoreArtifacts.first(where: { $0.buildRunId == state.buildRun.id }) else {
        return .none
      }
      return .run { [bundleId = state.bundleId] send in
        let application = DeviceKit.Application(url: container.localUrl, bundleIdentifier: bundleId)
        for simulator in simulators {
          switch await device.status(simulator.id) {
          case .idle: try await simulator.boot()
          case .ready: try simulator.focus()
          case .unknown: break
          }
          try simulator.install(application: application)
          try simulator.launch(application: application)
        }
      } catch: { error, send in
        logger.log(level: .error, method: "installArtifactSimulatorDidFail", message: "error=[\(error)]")
      }
    case .downloadArtifactButtonDidTapped:
      state.isLoading = true
      return .run { [buildRunId = state.buildRun.id] send in
        guard
          let buildActionId = try await appStore.ci.buildActions(buildRunId).first(where: { $0.type == .build })?.id,
          let package = try await appStore.ci.artifacts(buildActionId).first(where: { $0.type == .xcodebuildProducts }),
          let url = try await artifact.unpack(buildRunId, package)
        else {
          return
        }
        let container = ArtifactContainer(id: package.id, buildRunId: buildRunId, localUrl: url)
        await send(.internal(.artifactContainerDidLoad(container)))
      } catch: { error, send in
        logger.log(level: .error, method: "downloadArtifactDidFail", message: "error=[\(error)]")
      }
    case .startBuildButtonDidTapped:
      guard let workflowId = state.workflowId else { return .none }
      state.isLoading = true
      return .run { [buildRunId = state.buildRun.id] send in
        let buildRun = try await appStore.ci.startBuildRun(workflowId, buildRunId)
        await send(.internal(.buildRunDidLoad(buildRun)))
      } catch: { error, send in
        logger.log(level: .error, method: "startBuildDidFail", message: "error=[\(error)]")
      }
    case .task:
      return .run { [bunbleRunId = state.buildRun.id] send in
        for await progress in await artifact.progress() {
          guard let artifactProgress = progress[bunbleRunId] else { continue }
          logger.log(
            level: .info,
            method: "artifactProgress",
            message: "progress=[\(artifactProgress)] bundleRunId=[\(bunbleRunId)]"
          )
          await send(.internal(.artifactStateDidUpdate(artifactProgress)))
        }
      }
    }
  }
}
