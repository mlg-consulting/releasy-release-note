//
//  ArtifactFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension ArtifactFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .artifactContainersDidLoad(let containers):
      state.$appStoreArtifacts.withLock {
        if !$0.contains(containers) { $0.append(contentsOf: containers) }
      }
      return .none
    case .artifactStateDidUpdate(let artifactState):
      logger.log(level: .info, method: "artifactStateDidUpdate", message: "progress=[\(artifactState)]")
      state.artifactState = artifactState
      state.isLoading = false
      return .none
    case .buildRunDidLoad(let buildRun):
      state.isLoading = false
      state.$appStoreBuildRuns.withLock { $0.append(buildRun) }
      return .none
    case .installArtifactComplete:
      state.isLoading = false
      return .none
    case .installArtifactFailure(let error):
      state.isLoading = false
      return .send(.delegate(.installArtifactDidFail(error)))
    case .simulatorDidLoad(let simulators):
      state.simulators = simulators.filter({ state.simulators.contains($0) })
      return .none
    }
  }
}
