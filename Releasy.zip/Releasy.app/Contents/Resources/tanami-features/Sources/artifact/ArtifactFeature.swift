//
//  ArtifactFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import ConsoleLogger
import Dependencies
import DeviceKit
import DevicesTab
import Foundation
import Sharing
import TanamiFoundation
import TanamiServices

@Reducer
public struct ArtifactFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.artifact) var artifact
  @Dependency(\.console.artifact) var logger
  @Dependency(\.deviceClient) var device

  // MARK: - State
  @ObservableState
  public struct State: Identifiable, Equatable, Sendable {
    @Shared(.appStoreArtifacts) var appStoreArtifacts
    @Shared(.appStoreBuildRuns) var appStoreBuildRuns

    public var id: AppStoreConnect.CIBuildRun.ID { buildRun.id }
    let bundleId: String
    let workflowId: AppStoreConnect.CIWorkflow.ID?
    var buildRun: AppStoreConnect.CIBuildRun
    var simulators: [Simulator]
    var devices: [Device]
    var isLoading: Bool
    var artifactState: ArtifactState

    var artifactAvailable: [ArtifactContainer] {
      appStoreArtifacts.filter({ $0.buildRunId == buildRun.id })
    }

    var isDeviceArtifactAvailable: Bool {
      artifactAvailable.first(where: { $0.plateform == .device }) != .none
    }

    var isSimulatorArtifactAvailable: Bool {
      artifactAvailable.first(where: { $0.plateform == .simulator }) != .none
    }

    init(
      bundleId: String,
      workflowId: AppStoreConnect.CIWorkflow.ID?,
      buildRun: AppStoreConnect.CIBuildRun,
      devices: [Device],
      simulators: [Simulator],
      isLoading: Bool,
      artifactState: ArtifactState
    ) {
      self.bundleId = bundleId
      self.workflowId = workflowId
      self.buildRun = buildRun
      self.devices = devices
      self.simulators = simulators
      self.isLoading = isLoading
      self.artifactState = artifactState
    }

    /// Provides an initial state.
    public static func initial(
      bundleId: String,
      workflowId: AppStoreConnect.CIWorkflow.ID?,
      buildRun: AppStoreConnect.CIBuildRun,
      devices: [Device],
      simulators: [Simulator],
      isLoading: Bool = false
    ) -> State {
      .init(
        bundleId: bundleId,
        workflowId: workflowId,
        buildRun: buildRun,
        devices: devices,
        simulators: simulators,
        isLoading: isLoading,
        artifactState : .idle
      )
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions for delegate responses.
    case delegate(Delegate)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Delegate: Equatable, Sendable {
      case installArtifactDidFail(String)
      case requestUnlockDevice(String)
    }

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case artifactContainersDidLoad([ArtifactContainer])
      case artifactStateDidUpdate(ArtifactState)
      case buildRunDidLoad(AppStoreConnect.CIBuildRun)
      case installArtifactComplete
      case installArtifactFailure(String)
      case simulatorDidLoad([Simulator])
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case cleanArtifactButtonDidTapped(AppStoreConnect.CIBuildAction.CIActionPlateform)
      case installArtifactDeviceButtonDidTapped(Device)
      case installArtifactSimulatorButtonDidTapped([Simulator])
      case downloadArtifactButtonDidTapped(AppStoreConnect.CIBuildAction.CIActionPlateform)
      case startBuildButtonDidTapped
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .delegate(let action):
        return handleDelegateAction(action, state: &state)
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}

extension AppStoreConnect.CIBuildRun {
  var artifactAvailable: Bool {
    @Shared(.appStoreArtifacts) var appStoreArtifacts
    guard let artifact = appStoreArtifacts.first(where: { $0.buildRunId == id }) else { return false }
    guard FileManager.default.fileExists(atPath: artifact.localUrl.path) else {
      $appStoreArtifacts.withLock { $0.removeAll(where: { $0.id == artifact.id }) }
      return false
    }
    return true
  }
}
