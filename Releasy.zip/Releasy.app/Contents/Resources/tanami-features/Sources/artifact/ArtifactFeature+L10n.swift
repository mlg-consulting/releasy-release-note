// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Clean Artifact…
  internal static let artifactCleanButtonLabel = L10n.tr("Localizable", "artifact_clean_button_label", fallback: "Clean Artifact…")
  /// releasy://artifact?buildRunId=%s&bundleId=%s
  internal static func artifactDeeplink(_ p1: UnsafePointer<CChar>, _ p2: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "artifact_deeplink", p1, p2, fallback: "releasy://artifact?buildRunId=%s&bundleId=%s")
  }
  /// Copy Artifact Deeplink…
  internal static let artifactDeeplinkMenuLabel = L10n.tr("Localizable", "artifact_deeplink_menu_label", fallback: "Copy Artifact Deeplink…")
  /// Artifact deeplink has been placed into your pasteboard.
  internal static let artifactDeeplinkPasteboardLabel = L10n.tr("Localizable", "artifact_deeplink_pasteboard_label", fallback: "Artifact deeplink has been placed into your pasteboard.")
  /// Download For Device…
  internal static let artifactDownloadForDeviceLabel = L10n.tr("Localizable", "artifact_download_for_device_label", fallback: "Download For Device…")
  /// Download For Simulator…
  internal static let artifactDownloadForSimulatorLabel = L10n.tr("Localizable", "artifact_download_for_simulator_label", fallback: "Download For Simulator…")
  /// Install All Simulators…
  internal static let artifactInstallAllSimulatorsButtonLabel = L10n.tr("Localizable", "artifact_install_all_simulators_button_label", fallback: "Install All Simulators…")
  /// Devices
  internal static let artifactSectionDevicesLabel = L10n.tr("Localizable", "artifact_section_devices_label", fallback: "Devices")
  /// Simulators
  internal static let artifactSectionSimulatorsLabel = L10n.tr("Localizable", "artifact_section_simulators_label", fallback: "Simulators")
  /// Please Unlock Device “%s“
  internal static func deviceRequestUnlockLabel(_ p1: UnsafePointer<CChar>) -> String {
    return L10n.tr("Localizable", "device_request_unlock_label", p1, fallback: "Please Unlock Device “%s“")
  }
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
