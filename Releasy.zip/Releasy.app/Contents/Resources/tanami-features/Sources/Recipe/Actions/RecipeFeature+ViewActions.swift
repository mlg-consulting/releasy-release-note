//
//  RecipeFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import TanamiFoundation
import TanamiServices

extension RecipeFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .hideErrorMessage:
      state.errorMessage = .none
      state.isLoading = false
      return .none
    case .task:
      return .none
    }
  }
}
