//
//  RecipeFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import ComposableArchitecture

extension RecipeFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .error(let message):
      state.errorMessage = message
      return .run { send in
        try? await Task.sleep(for: .seconds(3))
        await send(.view(.hideErrorMessage), animation: .bouncy(duration: 0.15))
      }
    }
  }
}
