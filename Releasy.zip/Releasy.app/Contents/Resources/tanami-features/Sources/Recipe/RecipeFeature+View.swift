//
//  RecipeFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import TanamiServices

extension RecipeFeatureView {
  private enum UI {
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
  }
}

@ViewAction(for: RecipeFeature.self)
public struct RecipeFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Environment(\.customWindowPresentation) private var customWindowPresentation
  @Bindable public var store: StoreOf<RecipeFeature>

  public init(store: StoreOf<RecipeFeature>) {
    self.store = store
  }

  public var body: some View {
    ZStack(alignment: .top) {
      VStack(spacing: designSystem.spacing(.xs)) {
        app
        header
        form
      }
      .padding(UI.padding)
      .frame(width: 600)
      .frame(minHeight: 500, maxHeight: 700)
      .scrollContentBackground(.hidden)
      .fixedSize()

      errorMessage
    }
    .onChange(of: store.shouldCloseWindow) { oldValue, newValue in
      if newValue {
        Task {
          try await Task.sleep(for: .seconds(5))
          customWindowPresentation?.dismiss()
        }
      }
    }
  }
}

extension RecipeFeatureView {
  @ViewBuilder
  private var errorMessage: some View {
    if let message = store.errorMessage {
      ErrorMessage(message)
    }
  }

  @ViewBuilder
  private var app: some View {
    if let app = store.currentApplication {
      HStack(spacing: designSystem.spacing(.xs)) {
        AsyncImage(url: app.iconUrl) { image in
          image.resizable()
        } placeholder: {
          Color.gray
        }
        .frame(width: 32.0, height: 32.0)
        .mask(RoundedRectangle(cornerRadius: designSystem.radius(.s)))
      }
    }
  }

  private var header: some View {
    Text(L10n.newReleaseTitle)
      .font(.largeTitle)
      .foregroundColor(.primary)
  }

  private var form: some View {
    Form {
      Section {

      }
      Section {

      }
      Section {

      } header: { Text(L10n.inputWhatsNewLabel) }
    }
    .formStyle(.grouped)
    .task { send(.task) }
  }
}

#if DEBUG
#Preview {
  RecipeFeatureView(
    store: Store(
      initialState: .initial(appId: AppStoreConnect.Application.mock.id),
      reducer: RecipeFeature.init
    )
  )
}
#endif
