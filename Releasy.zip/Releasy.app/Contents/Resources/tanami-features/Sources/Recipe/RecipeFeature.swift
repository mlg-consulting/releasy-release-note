//
//  RecipeFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import Dependencies
import Foundation
import Sharing
import TanamiFoundation
import TanamiServices

@Reducer
public struct RecipeFeature: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectApps) var appStoreConnectApps
    @Shared(.recipes) var recipes

    var appId: AppStoreConnect.Application.ID
    var isLoading: Bool
    var errorMessage: String?
    var shouldCloseWindow: Bool

    var currentApplication: AppStoreConnect.Application? {
      appStoreConnectApps.first(where: { $0.id == appId })
    }

    init(appId: AppStoreConnect.Application.ID, isLoading: Bool, errorMessage: String?, shouldCloseWindow: Bool) {
      self.appId = appId
      self.isLoading = isLoading
      self.errorMessage = errorMessage
      self.shouldCloseWindow = shouldCloseWindow
    }

    /// Provides an initial state.
    public static func initial(appId: AppStoreConnect.Application.ID, isLoading: Bool = false) -> State {
      .init(appId: appId, isLoading: isLoading, errorMessage: .none, shouldCloseWindow: false)
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case error(String)
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case hideErrorMessage
      case task
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
  }

  // MARK: - Inializer
  public init() {}
}
