// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// App
  internal static let bitriseAppPlaceholder = L10n.tr("Localizable", "bitrise_app_placeholder", fallback: "App")
  /// App Slug
  internal static let bitriseAppPrompt = L10n.tr("Localizable", "bitrise_app_prompt", fallback: "App Slug")
  /// Artifact
  internal static let bitriseArtifactPlaceholder = L10n.tr("Localizable", "bitrise_artifact_placeholder", fallback: "Artifact")
  /// Artifact Slug
  internal static let bitriseArtifactPrompt = L10n.tr("Localizable", "bitrise_artifact_prompt", fallback: "Artifact Slug")
  /// Build
  internal static let bitriseBuildPlaceholder = L10n.tr("Localizable", "bitrise_build_placeholder", fallback: "Build")
  /// Build Slug
  internal static let bitriseBuildPrompt = L10n.tr("Localizable", "bitrise_build_prompt", fallback: "Build Slug")
  /// Cancel
  internal static let cancelRecipeButtonLabel = L10n.tr("Localizable", "cancel_recipe_button_label", fallback: "Cancel")
  /// Configure Application Provider
  internal static let configureTitle = L10n.tr("Localizable", "configure_title", fallback: "Configure Application Provider")
  /// Any
  internal static let destinationAnyLabel = L10n.tr("Localizable", "destination_any_label", fallback: "Any")
  /// Device
  internal static let destinationDeviceLabel = L10n.tr("Localizable", "destination_device_label", fallback: "Device")
  /// Destination
  internal static let destinationPickerTitle = L10n.tr("Localizable", "destination_picker_title", fallback: "Destination")
  /// Simulator
  internal static let destinationSimulatorLabel = L10n.tr("Localizable", "destination_simulator_label", fallback: "Simulator")
  /// Please check the provider configuration.
  internal static let genericErrorMessageLabel = L10n.tr("Localizable", "generic_error_message_label", fallback: "Please check the provider configuration.")
  /// URL
  internal static let httpUrlPlaceholder = L10n.tr("Localizable", "http_url_placeholder", fallback: "URL")
  /// https://
  internal static let httpUrlPrompt = L10n.tr("Localizable", "http_url_prompt", fallback: "https://")
  /// iOS
  internal static let platformIosLabel = L10n.tr("Localizable", "platform_ios_label", fallback: "iOS")
  /// macOS
  internal static let platformMacosLabel = L10n.tr("Localizable", "platform_macos_label", fallback: "macOS")
  /// Platform
  internal static let platformPickerTitle = L10n.tr("Localizable", "platform_picker_title", fallback: "Platform")
  /// tvOS
  internal static let platformTvosLabel = L10n.tr("Localizable", "platform_tvos_label", fallback: "tvOS")
  /// visionOS
  internal static let platformVisionosLabel = L10n.tr("Localizable", "platform_visionos_label", fallback: "visionOS")
  /// watchOS
  internal static let platformWatchOsLabel = L10n.tr("Localizable", "platform_watch_os_label", fallback: "watchOS")
  /// Bitrise
  internal static let providerBitriseLabel = L10n.tr("Localizable", "provider_bitrise_label", fallback: "Bitrise")
  /// Basic HTTP
  internal static let providerHttpLabel = L10n.tr("Localizable", "provider_http_label", fallback: "Basic HTTP")
  /// Provider
  internal static let providerPickerTitle = L10n.tr("Localizable", "provider_picker_title", fallback: "Provider")
  /// Xcode Cloud
  internal static let providerXcodeCloudLabel = L10n.tr("Localizable", "provider_xcode_cloud_label", fallback: "Xcode Cloud")
  /// Save
  internal static let saveRecipeButtonLabel = L10n.tr("Localizable", "save_recipe_button_label", fallback: "Save")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
