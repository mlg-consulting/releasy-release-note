//
//  XcodeCloudProviderFeature.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppsTab
import Artifact
import ComposableArchitecture
import Dependencies
import DeviceKit
import DevicesTab
import Foundation
import Sharing
import TanamiFoundation
import TanamiServices

@Reducer
public struct XcodeCloudProviderFeature: Sendable {
  @Dependency(\.appStore) var appStore
  @Dependency(\.artifact) var artifact
  @Dependency(\.continuousClock) var clock
  @Dependency(\.deviceClient) var device
  @Dependency(\.feature) var feature

  // MARK: - Models
  public enum ArtifactFilter: String, CaseIterable, CustomStringConvertible, Sendable {
    case all
    case failed
    case succeeded

    public var description: String {
      switch self {
      case .all: L10n.buildRunFilterAllLabel
      case .failed: L10n.buildRunFilterFailedLabel
      case .succeeded: L10n.buildRunFilterSucceededLabel
      }
    }
  }

  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreArtifacts) var appStoreArtifacts
    @Shared(.appStoreConnectApps) var appStoreConnectApps
    @Shared(.appStoreBuildRuns) var appStoreBuildRuns
    @Shared(.pinnedApplications) var pinnedApplications
    @Shared(.pinnedSimulators) var pinnedSimulators

    var artifacts: IdentifiedArrayOf<ArtifactFeature.State>
    var workflows: [AppStoreConnect.CIWorkflow]
    var currentAppId: AppStoreConnect.Application.ID
    var currentWorkflowId: AppStoreConnect.CIWorkflow.ID?
    var currentFilter: ArtifactFilter
    var pullRequests: [AppStoreConnect.ScmPullRequest]
    var devices: [Device]
    var simulators: [Simulator]
    var isLoading: Bool
    var errorMessage: String?

    init(
      artifacts: IdentifiedArrayOf<ArtifactFeature.State>,
      workflows: [AppStoreConnect.CIWorkflow],
      currentAppId: AppStoreConnect.Application.ID,
      currentWorkflowId: AppStoreConnect.CIWorkflow.ID?,
      currentFilter: ArtifactFilter,
      pullRequests: [AppStoreConnect.ScmPullRequest],
      devices: [Device],
      simulators: [Simulator],
      isLoading: Bool,
      errorMessage: String?
    ) {
      self.artifacts = artifacts
      self.workflows = workflows
      self.currentAppId = currentAppId
      self.currentWorkflowId = currentWorkflowId
      self.currentFilter = currentFilter
      self.pullRequests = pullRequests
      self.devices = devices
      self.simulators = simulators
      self.isLoading = isLoading
      self.errorMessage = errorMessage
    }

    /// Provides an initial state.
    public static func initial(appId: AppStoreConnect.Application.ID, isLoading: Bool = false) -> State {
      .init(
        artifacts: .init(),
        workflows: [],
        currentAppId: appId,
        currentWorkflowId: .none,
        currentFilter: .all,
        pullRequests: [],
        devices: [],
        simulators: [],
        isLoading: isLoading,
        errorMessage: .none
      )
    }

    var applications: [AppStoreConnect.Application] {
      appStoreConnectApps.filter { pinnedApplications.contains($0.id) }.sorted()
    }

    var currentApplication: AppStoreConnect.Application? {
      appStoreConnectApps.first(where: { $0.id == currentAppId })
    }

    var currentWorkflow: AppStoreConnect.CIWorkflow? {
      workflows.first(where: { $0.id == currentWorkflowId })
    }

    var availableSimulators: [Simulator] {
      simulators.filter { pinnedSimulators.contains($0.id) }
    }

    var openedPullRequest: [AppStoreConnect.ScmPullRequest] {
      pullRequests.filter { $0.isClosed == false }
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, BindableAction, Sendable, Equatable {
    /// Actions related to artifact feature event.
    case artifacts(IdentifiedActionOf<ArtifactFeature>)
    /// Actions related to the view input events.
    case binding(BindingAction<State>)
    /// Actions related to internal event.
    case `internal`(Internal)
    /// Actions related to view interactions.
    case view(View)

    @CasePathable
    public enum Internal: Equatable, Sendable {
      case buildRunsDidLoad([AppStoreConnect.CIBuildRun])
      case error(String)
      case pullRequestsDidLoad([AppStoreConnect.ScmPullRequest])
      case devicesDidLoad([Device])
      case simulatorsDidLoad([Simulator])
      case workflowsDidLoad([AppStoreConnect.CIWorkflow])
    }

    @CasePathable
    public enum View: Sendable, Equatable {
      case currentAppIdDidChange(AppStoreConnect.Application.ID)
      case currentWorkflowIdDidChange(AppStoreConnect.CIWorkflow.ID?)
      case hideErrorMessage
      case loadBuildRuns(AppStoreConnect.CIWorkflow.ID)
      case refresh
      case task
      case windowWillClose
    }
  }

  // MARK: - Reducer
  public var body: some ReducerOf<Self> {
    BindingReducer()
    Reduce { state, action in
      switch action {
      case let .artifacts(.element(_, action)):
        guard case let .delegate(delegateAction) = action else { return .none }
        return handleBuildAction(delegateAction, state: &state)
      case .binding(\.currentFilter):
        guard let workflowId = state.currentWorkflowId else { return .none }
        return .send(.view(.loadBuildRuns(workflowId)))
      case .binding:
        return .none
      case .internal(let action):
        return handleInternalAction(action, state: &state)
      case .view(let viewActions):
        return handleViewAction(viewActions, state: &state)
      }
    }
    .forEach(\.artifacts, action: \.artifacts) {
      ArtifactFeature()
    }
  }

  // MARK: - Inializer
  public init() {}
}
