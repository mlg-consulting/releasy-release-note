//
//  XcodeCloudProviderFeature+ArtifactActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Artifact
import ComposableArchitecture
import TanamiFoundation

extension XcodeCloudProviderFeature {
  func handleBuildAction(_ action: ArtifactFeature.Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    case .installArtifactDidFail(let error):
      return .send(.internal(.error(error)))
    case .requestUnlockDevice(let message):
      return .send(.internal(.error(message)))
    }
  }
}
