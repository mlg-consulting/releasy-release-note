//
//  XcodeCloudProviderFeature+Window.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import AppKit
import ComposableArchitecture
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

@MainActor
final class XcodeCloudProviderWindow<Content: View>: NSPanel, CustomWindowPresentation {
	private let rootView: () -> Content

	private lazy var hostingView: NSHostingView<some View> = {
		let view = NSHostingView(
			rootView: rootView()
				.environment(\.customWindowPresentation, self)
				.edgesIgnoringSafeArea(.all)
				// Compensate for extra height from hidden title bar.
				.padding(.top, -titleBarHeight)
		)

		view.translatesAutoresizingMaskIntoConstraints = false
		return view
	}()

	init(content: @escaping () -> Content) {
		self.rootView = content

		super.init(
			contentRect: CGRect(x: 0, y: 0, width: 100, height: 100),
      styleMask: [.closable, .miniaturizable, .titled, .fullSizeContentView],
			backing: .buffered,
			defer: false
		)
    
    isReleasedWhenClosed = true
		isMovable = true
		isMovableByWindowBackground = true
		isFloatingPanel = false
		isOpaque = true
    titleVisibility = .visible
		titlebarAppearsTransparent = true

		animationBehavior = .utilityWindow
		hidesOnDeactivate = false
    
		standardWindowButton(.closeButton)?.isHidden = false
		standardWindowButton(.miniaturizeButton)?.isHidden = false
		standardWindowButton(.zoomButton)?.isHidden = false

		contentView = hostingView
		setContentSize(hostingView.intrinsicContentSize)
	}

	private var titleBarHeight: CGFloat {
		if let windowFrameHeight = contentView?.frame.height {
			return windowFrameHeight - contentLayoutRect.height
		}
    return .zero
	}

	override var canBecomeKey: Bool { true }

	override var canBecomeMain: Bool { true }

  func dismiss() {
    close()
  }
}

public final class ShowXcodeCloudProviderWindowAction {
  private var xcodeCloudProviderWindow: NSWindow?

  public init() {}

  @MainActor
  public func callAsFunction(store: StoreOf<XcodeCloudProviderFeature>) {
    xcodeCloudProviderWindow?.close()
    xcodeCloudProviderWindow = XcodeCloudProviderWindow {
      XcodeCloudProviderFeatureView(store: store)
        .showDockIconWhenOpen()
    }
    xcodeCloudProviderWindow?.identifier = .init(rawValue: "XcodeCloudProviderWindow")
    xcodeCloudProviderWindow?.isReleasedWhenClosed = true
    xcodeCloudProviderWindow?.center()
    xcodeCloudProviderWindow?.makeKeyAndOrderFront(nil)
    NSRunningApplication.current.activate()
  }
}

extension EnvironmentValues {
  @Entry public var showXcodeCloudProviderWindow: ShowXcodeCloudProviderWindowAction?
}
