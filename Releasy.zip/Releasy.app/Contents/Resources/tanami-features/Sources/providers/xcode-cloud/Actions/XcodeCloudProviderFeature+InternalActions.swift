//
//  XcodeCloudProviderFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import Artifact
import ComposableArchitecture
import TanamiFoundation

extension XcodeCloudProviderFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .buildRunsDidLoad(let buildRuns):
      let cleanBuilds = cleanBuilds(buildRuns, state: &state)
      state.$appStoreBuildRuns.withLock { $0 = cleanBuilds }
      addNewArtifacts(for: cleanBuilds, state: &state)
      state.isLoading = false
      return .run(priority: .utility) { send in
        let sourceBranchOrTagIds = Set(cleanBuilds.compactMap(\.sourceBranchOrTagId))
        guard !sourceBranchOrTagIds.isEmpty else { return }
        let gitReferences = try await withThrowingTaskGroup(
          of: AppStoreConnect.ScmGitReference?.self,
          returning: [AppStoreConnect.ScmGitReference].self
        ) { group in
          for sourceBranchOrTagId in sourceBranchOrTagIds {
            group.addTask {
              let reference = try await appStore.repository.gitReference(sourceBranchOrTagId)
              return reference
            }
          }

          var gitReferences: [AppStoreConnect.ScmGitReference] = []
          for try await gitReferenceSubset in group.compactMap({ $0 }) {
            gitReferences.append(gitReferenceSubset)
          }
          return gitReferences
        }
        await send(.internal(.gitReferencesDidLoad(gitReferences)))
      } catch: { error, send in
        await send(.internal(.error(error.localizedDescription)))
      }
    case .devicesDidLoad(let devices):
      state.devices = devices
      return .none
    case .error(let message):
      state.isLoading = false
      state.errorMessage = message
      return .run { send in
        try? await Task.sleep(for: .seconds(3))
        await send(.view(.hideErrorMessage), animation: .bouncy(duration: 0.15))
      }
    case .gitReferencesDidLoad(let gitReferences):
      state.gitReferences = gitReferences.sorted(by: { $0.name ?? "" > $1.name ?? "" })
      return .none
    case .pullRequestsDidLoad(let pullRequests):
      state.pullRequests = pullRequests
      return .none
    case .repositoryDidLoad(let repository):
      state.repository = repository
      return .none
    case .simulatorsDidLoad(let simulators):
      state.simulators = simulators
      return .none
    case .workflowsDidLoad(let workflows):
      guard !workflows.isEmpty else {
        state.isLoading = false
        state.pullRequests.removeAll()
        state.$appStoreBuildRuns.withLock { $0.removeAll() }
        return .cancel(id: Cancellable.refreshTimer)
      }
      state.workflows = workflows.filter(\.isEnabled)
      state.currentWorkflowId = state.workflows.last?.id
      guard let workflowId = state.currentWorkflowId else { return .none }
      return .send(.view(.loadBuildRuns(workflowId)))
    }
  }
}

extension XcodeCloudProviderFeature {
  private func cleanArtifacts(for buildRunIds: [AppStoreConnect.CIBuildRun.ID], state: inout State) {
    let removableArtifactIds = state.artifacts.filter { !buildRunIds.contains($0.id) }.ids
    removableArtifactIds.forEach { id in
      try? state.appStoreArtifacts.first(where: { $0.id == id})?.delete()
      state.artifacts.remove(id: id)
    }
  }

  private func addNewArtifacts(for buildRuns: [AppStoreConnect.CIBuildRun], state: inout State) {
    guard let bundleId = state.currentApplication?.bundleId else { return }
    let workflowId = state.currentWorkflowId
    let devices = state.devices
    let simulators = state.availableSimulators
    for buildRun in buildRuns.filter({ state.appStoreBuildRuns.contains($0) }) {
      state.artifacts.append(
        .initial(
          bundleId: bundleId,
          workflowId: workflowId,
          buildRun: buildRun,
          devices: devices,
          simulators: simulators
        )
      )
    }
  }

  private func cleanBuilds(
    _ buildRuns: [AppStoreConnect.CIBuildRun],
    state: inout State
  ) -> [AppStoreConnect.CIBuildRun] {
    guard !buildRuns.compactMap(\.pullRequestId).isEmpty else { return buildRuns }
    let pullRequestIds = state.pullRequests.map(\.id)
    let buildRuns = buildRuns.filter {
      guard let pullRequestId = $0.pullRequestId else { return false }
      return pullRequestIds.contains(pullRequestId)
    }
    cleanArtifacts(for: buildRuns.map(\.id), state: &state)
    return buildRuns
  }
}
