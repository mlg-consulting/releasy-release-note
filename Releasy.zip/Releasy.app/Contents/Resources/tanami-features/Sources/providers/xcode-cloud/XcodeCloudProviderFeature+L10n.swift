// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Applications
  internal static let appsPickerTitle = L10n.tr("Localizable", "apps_picker_title", fallback: "Applications")
  /// Deeplink available into pasteboard
  internal static let artifactDeeplinkPasteboardCopyLabel = L10n.tr("Localizable", "artifact_deeplink_pasteboard_copy_label", fallback: "Deeplink available into pasteboard")
  /// Artifact for Build Run Number [%d] is now ready.
  internal static func artifactDownloadReadyLabel(_ p1: Int) -> String {
    return L10n.tr("Localizable", "artifact_download_ready_label", p1, fallback: "Artifact for Build Run Number [%d] is now ready.")
  }
  /// branch
  internal static let buildGitReferenceTypeBranchLabel = L10n.tr("Localizable", "build_git_reference_type_branch_label", fallback: "branch")
  /// pull request
  internal static let buildGitReferenceTypePullRequestLabel = L10n.tr("Localizable", "build_git_reference_type_pull_request_label", fallback: "pull request")
  /// tag
  internal static let buildGitReferenceTypeTagLabel = L10n.tr("Localizable", "build_git_reference_type_tag_label", fallback: "tag")
  /// All
  internal static let buildRunFilterAllLabel = L10n.tr("Localizable", "build_run_filter_all_label", fallback: "All")
  /// Failed
  internal static let buildRunFilterFailedLabel = L10n.tr("Localizable", "build_run_filter_failed_label", fallback: "Failed")
  /// Filter
  internal static let buildRunFilterPickerTitle = L10n.tr("Localizable", "build_run_filter_picker_title", fallback: "Filter")
  /// Succeeded
  internal static let buildRunFilterSucceededLabel = L10n.tr("Localizable", "build_run_filter_succeeded_label", fallback: "Succeeded")
  /// No Pull Request Workflow Available
  internal static let noPullRequestWorkflowsLabel = L10n.tr("Localizable", "no_pull_request_workflows_label", fallback: "No Pull Request Workflow Available")
  /// Available Pull Requests
  internal static let pullRequestTitle = L10n.tr("Localizable", "pull_request_title", fallback: "Available Pull Requests")
  /// Workflows
  internal static let workflowsPickerTitle = L10n.tr("Localizable", "workflows_picker_title", fallback: "Workflows")
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
