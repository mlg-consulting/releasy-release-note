import ComposableArchitecture

extension AccountPicker {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .accountTapped(let id):
      return .send(.delegate(.didSelectAccount(id)))
    case .addAccountButtonTapped:
      return .send(.delegate(.didTapAddAccount))
    case .onAppear:
      return .none
    case .task:
      return .none
    }
  }
}
