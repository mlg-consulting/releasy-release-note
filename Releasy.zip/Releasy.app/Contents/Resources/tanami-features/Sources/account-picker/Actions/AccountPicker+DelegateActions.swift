import ComposableArchitecture

extension AccountPicker {
  func handleDelegateAction(_ action: Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    case .didSelectAccount:
      return .none
    case .didTapAddAccount:
      return .none
    }
  }
}
