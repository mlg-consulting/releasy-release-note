import AppStoreConnectService
import ComposableArchitecture
import SettingsRouter
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation

extension AccountPickerView{
  private enum UI {
    static let size: CGSize = .init(width: 28.0, height: 28.0)
  }
}

@ViewAction(for: AccountPicker.self)
public struct AccountPickerView: View {
  @Dependency(\.designSystem) private var designSystem
  @Dependency(\.designSystem.theme) private var theme

  @Shared(.selectedTab) var selectedTab

  public let store: StoreOf<AccountPicker>

  /// The content and layout of the view.
  public var body: some View {
    VStack(alignment: .leading, spacing: designSystem.spacing(.xs)) {
      ForEach(store.appStoreConnectAccounts) { account in
        Account(name: account.name, description: account.keyID) {
          Avatar(name: account.name, color: theme.color(.init(stringLiteral: account.colorKey)))
        }
        .backgroundOnHover(color: .primary.opacity(0.1))
        .onTapGesture { send(.accountTapped(account.id)) }
      }
      Divider()
      addButton
    }
    .padding(designSystem.spacing(.xs))
    .task { send(.task) }
  }

  /// Initializes with a specific store.
  public init(store: StoreOf<AccountPicker>) {
    self.store = store
  }
}

// MARK: - Components
extension AccountPickerView {
  private var addButton: some View {
    SettingsLink {
      HStack {
        designSystem.icon(.plus)
          .frame(width: UI.size.width, height: UI.size.height)
          .background(
            RoundedRectangle(cornerRadius: designSystem.radius(.s))
              .fill(.primary.opacity(0.2))
          )
        Text(L10n.addNewAccountButtonTitle)
          .font(.body)
          .fontWeight(.bold)
          .frame(maxWidth: .infinity, alignment: .leading)
      }
      .padding(designSystem.spacing(.xs))
      .backgroundOnHover(color: .primary.opacity(0.1))
    }
    .buttonStyle(
      SettingsLinkActionButtonStyle {
        $selectedTab.withLock { $0 = .accounts }
      }
    )
    .buttonStyle(.plain)
  }
}

// MARK: - Previews
#if DEBUG
#Preview {
  AccountPickerView(store: Store(initialState: .initial) { AccountPicker() })
}
#endif
