import AppStoreConnectService
import ComposableArchitecture
import Sharing
import SwiftUI
import TanamiFoundation

@Reducer
public struct AccountPicker: Sendable {
  // MARK: - State
  @ObservableState
  public struct State: Sendable, Equatable {
    @Shared(.appStoreConnectAccounts) var appStoreConnectAccounts

    /// Initializes the state.
    init() {}

    /// Provides an initial state.
    public static var initial: Self {
      .init()
    }
  }

  // MARK: - Actions
  @CasePathable
  public enum Action: ViewAction, Equatable, Sendable {
    /// Actions for delegate responses.
    case delegate(Delegate)
    /// Actions related to view interactions.
    case view(View)

    /// Delegate actions, typically for handling selection or navigation events.
    @CasePathable
    public enum Delegate: Equatable, Sendable {
      case didSelectAccount(AppStoreConnect.Account.ID)
      case didTapAddAccount
    }
    /// View actions, initiated by user interaction within the UI.
    @CasePathable
    public enum View: Equatable, Sendable {
      case accountTapped(AppStoreConnect.Account.ID)
      case addAccountButtonTapped
      case onAppear
      case task
    }
  }

  /// Contains logic for handling actions and updating the state.
  public var body: some ReducerOf<Self> {
    Reduce { state, action in
      switch action {
      case .delegate(let action):
        return handleDelegateAction(action, state: &state)
      case .view(let action):
        return handleViewAction(action, state: &state)
      }
    }
  }

  /// Initializes the reducer.
  public init() {}
}
