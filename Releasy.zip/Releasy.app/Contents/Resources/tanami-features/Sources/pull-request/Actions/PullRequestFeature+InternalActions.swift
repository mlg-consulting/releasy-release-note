//
//  PullRequestFeature+InternalActions.swift
//  tanami-features
//
//  Created by Loïc GRIFFIE on 02/01/2025.
//

import Artifact
import ComposableArchitecture
import TanamiFoundation

extension PullRequestFeature {
  func handleInternalAction(_ action: Action.Internal, state: inout State) -> EffectOf<Self> {
    switch action {
    case .buildRunsDidLoad(let buildRuns):
      cleanArtifacts(for: buildRuns, state: &state)
      state.$appStoreBuildRuns.withLock { $0 = buildRuns }
      addNewArtifacts(for: buildRuns, state: &state)
      state.isLoading = false
      return .none
    case .error(let message):
      state.isLoading = false
      state.errorMessage = message
      return .run { send in
        try? await Task.sleep(for: .seconds(3))
        await send(.view(.hideErrorMessage), animation: .bouncy(duration: 0.15))
      }
    case .pullRequestsDidLoad(let pullRequests):
      state.pullRequests = pullRequests
      return .none
    case .devicesDidLoad(let devices):
      state.devices = devices
      return .none
    case .simulatorsDidLoad(let simulators):
      state.simulators = simulators
      return .none
    case .workflowsDidLoad(let workflows):
      guard !workflows.isEmpty else {
        state.isLoading = false
        state.pullRequests.removeAll()
        state.$appStoreBuildRuns.withLock { $0.removeAll() }
        return .cancel(id: Cancellable.refreshTimer)
      }
      state.workflows = workflows.filter(\.isEnabled)
      state.currentWorkflowId = workflows.last?.id
      guard let workflowId = state.currentWorkflowId else { return .none }
      return .send(.view(.loadBuildRuns(workflowId)))
    }
  }
}

extension PullRequestFeature {
  private func cleanArtifacts(for buildRuns: [AppStoreConnect.CIBuildRun], state: inout State) {
    let removableArtifactIds = state.artifacts.filter { !buildRuns.map(\.id).contains($0.id) }.ids
    removableArtifactIds.forEach { id in
      try? state.appStoreArtifacts.first(where: { $0.id == id})?.delete()
      state.artifacts.remove(id: id)
    }
  }

  private func addNewArtifacts(for buildRuns: [AppStoreConnect.CIBuildRun], state: inout State) {
    guard let bundleId = state.currentApplication?.bundleId else { return }
    let workflowId = state.currentWorkflowId
    let devices = state.devices
    let simulators = state.availableSimulators
    state.artifacts.append(
      contentsOf: buildRuns
        .filter { state.appStoreBuildRuns.contains($0) }
        .map {
          .initial(
            bundleId: bundleId,
            workflowId: workflowId,
            buildRun: $0,
            devices: devices,
            simulators: simulators
          )
        }
    )
  }
}
