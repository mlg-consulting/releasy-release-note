//
//  PullRequestFeature+ArtifactActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Artifact
import ComposableArchitecture
import TanamiFoundation

extension PullRequestFeature {
  func handleBuildAction(_ action: ArtifactFeature.Action.Delegate, state: inout State) -> EffectOf<Self> {
    switch action {
    }
  }
}
