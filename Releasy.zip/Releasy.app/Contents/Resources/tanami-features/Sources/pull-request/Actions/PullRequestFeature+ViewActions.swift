//
//  PullRequestFeature+ViewActions.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import ComposableArchitecture
import DeviceKit
import TanamiFoundation
import TanamiServices

extension PullRequestFeature {
  func handleViewAction(_ action: Action.View, state: inout State) -> EffectOf<Self> {
    switch action {
    case .currentAppIdDidChange(let appId):
      guard appId != state.currentAppId else { return .none }
      state.currentAppId = appId
      state.currentWorkflowId = .none
      state.workflows.removeAll()
      state.pullRequests.removeAll()
      return .send(.view(.task))
    case .currentWorkflowIdDidChange(let workflowId):
      guard let workflowId, workflowId != state.currentWorkflowId else { return .none }
      return .send(.view(.loadBuildRuns(workflowId)))
    case .hideErrorMessage:
      state.errorMessage = .none
      state.isLoading = false
      return .none
    case .loadBuildRuns(let workflowId):
      return .run { send in
        let buildRuns = try await appStore.ci.buildRuns(workflowId)
        await send(.internal(.buildRunsDidLoad(buildRuns)))
      } catch: { error, send in
        await send(.internal(.error(error.localizedDescription)))
      }
    case .refresh:
      return .run { send in
        for await _ in clock.timer(interval: .seconds(5)) {
          await send(.view(.task))
        }
      }
      .cancellable(id: Cancellable.refreshTimer)
    case .task:
      guard let ciProductId = state.currentApplication?.ciProductId else { return .none }
      state.isLoading = true
      return .run { send in
        let devices = await device.devices()
        await send(.internal(.devicesDidLoad(devices)))
        let simulators = await device.simulators()
        await send(.internal(.simulatorsDidLoad(simulators)))
        guard let repository = try await appStore.repository.repositories().first else { return }
        let workflows = try await appStore.ci.workflows(ciProductId)
        await send(.internal(.workflowsDidLoad(workflows)))
        let pullRequests = try await appStore.repository.pullRequests(repository.id)
        await send(.internal(.pullRequestsDidLoad(pullRequests)))
      } catch: { error, send in
        await send(.internal(.error(error.localizedDescription)))
      }
    case .windowWillClose:
      return .merge(
        .cancel(id: Cancellable.task),
        .cancel(id: Cancellable.refreshTimer)
      )
    }
  }
}

extension PullRequestFeature {
  enum Cancellable {
    case refreshTimer
    case task
  }
}
