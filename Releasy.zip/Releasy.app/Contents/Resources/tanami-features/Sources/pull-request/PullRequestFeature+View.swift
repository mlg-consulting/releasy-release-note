//
//  PullRequestFeature+View.swift
//  Tanami
//
//  Created by Loïc GRIFFIE on 29/12/2024.
//

import Artifact
import ComposableArchitecture
import Sharing
import SwiftUI
import TanamiDesignSystem
import TanamiFoundation
import TanamiServices

extension PullRequestFeatureView {
  private enum UI {
    static let iconSize: CGSize = .init(width: 64.0, height: 64.0)
    static let padding: EdgeInsets = .init(top: 56.0, leading: 8.0, bottom: 8.0, trailing: 8.0)
  }
}

@ViewAction(for: PullRequestFeature.self)
public struct PullRequestFeatureView: View {
  @Dependency(\.designSystem) var designSystem
  @Dependency(\.designSystem.theme) var theme

  @Bindable public var store: StoreOf<PullRequestFeature>

  public init(store: StoreOf<PullRequestFeature>) {
    self.store = store
  }

  public var body: some View {
    ZStack(alignment: .top) {
      VStack(spacing: designSystem.spacing(.xs)) {
        header
        form
      }
      .task { send(.task) }
      .task { send(.refresh) }
      .padding(UI.padding)
      .frame(width: 700)
      .frame(minHeight: 500, maxHeight: 700)
      .scrollContentBackground(.hidden)
      .fixedSize()

      errorMessage
    }
    .onReceive(NotificationCenter.default.publisher(for: NSWindow.willCloseNotification)) { notification in
      if let window = notification.object as? NSWindow, window.identifier == .init(rawValue: "PullRequestWindow") {
        send(.windowWillClose)
      }
    }
  }
}

extension PullRequestFeatureView {
  @ViewBuilder
  private var errorMessage: some View {
    if let message = store.errorMessage {
      ErrorMessage(message)
    }
  }

  private var header: some View {
    VStack(spacing: designSystem.spacing(.xs)) {
      AsyncImage(url: store.currentApplication?.iconUrl) { image in
        image.resizable()
      } placeholder: {
        Color.gray
      }
      .frame(width: UI.iconSize.width, height: UI.iconSize.height)
      .mask(RoundedRectangle(cornerRadius: designSystem.radius(.m)))
      Text(store.currentApplication?.name ?? "")
        .font(.largeTitle)
        .foregroundColor(.primary)
      Text(L10n.pullRequestTitle)
        .font(.body)
        .foregroundColor(.secondary)
    }
  }

  private var form: some View {
    Form {
      Section {
        apps
        workflows
        filters
      }
      pullRequests
    }
    .formStyle(.grouped)
  }

  private var apps: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.appsPickerTitle)
        .font(.headline)
      if store.isLoading {
        ProgressView().controlSize(.mini)
      }
      Spacer()
      Picker(
        L10n.appsPickerTitle,
        selection: $store.currentAppId.sending(\.view.currentAppIdDidChange)
      ) {
        ForEach(store.applications) { app in
          Text(app.name)
            .tag(app.id)
        }
      }
      .labelsHidden()
    }
  }

  private var workflows: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.workflowsPickerTitle)
        .font(.headline)
      Spacer()
      Picker(
        L10n.workflowsPickerTitle,
        selection: $store.currentWorkflowId.sending(\.view.currentWorkflowIdDidChange)
      ) {
        ForEach(store.workflows) { workflow in
          Text(workflow.name ?? "--")
            .tag(workflow.id)
        }
      }
      .labelsHidden()
    }
  }

  private var filters: some View {
    HStack(spacing: designSystem.spacing(.xxs)) {
      Text(L10n.buildRunFilterPickerTitle)
        .font(.headline)
      Spacer()
      Picker(L10n.buildRunFilterPickerTitle, selection: $store.currentFilter) {
        ForEach(PullRequestFeature.ArtifactFilter.allCases, id: \.rawValue) { filter in
          Text(String(describing: filter))
            .tag(filter)
        }
      }
      .labelsHidden()
    }
  }

  @ViewBuilder
  private var pullRequests: some View {
    ForEach(store.openedPullRequest) { pullRequest in
      section(for: pullRequest)
    }
  }

  @ViewBuilder
  private func section(for pullRequest: AppStoreConnect.ScmPullRequest) -> some View {
    if store.appStoreBuildRuns.compactMap(\.pullRequestId).contains(pullRequest.id) {
      let builds = store.appStoreBuildRuns.filter ({ $0.pullRequestId == pullRequest.id }).filtered(by: store.currentFilter)
      if !builds.isEmpty {
        Section {
          buildRuns(builds: builds, url: pullRequest.webURL)
        } header: {
          HStack(spacing: designSystem.spacing(.xs)) {
            Text(pullRequest.title ?? "--")
            Text("#\(pullRequest.number ?? .zero)")
          }
          HStack(spacing: designSystem.spacing(.xs)) {
            Text(pullRequest.sourceBranchName ?? "--")
            designSystem.icon(.arrowRight)
            Text(pullRequest.destinationBranchName ?? "--")
          }
        }
      }
    }
  }

  private func buildRuns(builds: [AppStoreConnect.CIBuildRun], url: URL?) -> some View {
    ForEach(builds) { buildRun in
      BuildRunRow(
        buildRun: buildRun,
        url: url,
        trailing: {
          if let childStore = store.scope(state: \.artifacts[id: buildRun.id], action: \.artifacts[id: buildRun.id]) {
            ArtifactFeatureView(store: childStore)
          }
        }
      )
      .padding(designSystem.spacing(.xs))
      .menuBackgroundOnHover(color: .primary.opacity(0.1))
    }
  }
}

extension Array where Element == AppStoreConnect.CIBuildRun {
  func filtered(by currentFilter: PullRequestFeature.ArtifactFilter) -> [Element] {
    switch currentFilter {
    case .all: filter { [.succeeded, .errored, .failed, .none].contains($0.status) }
    case .failed: filter { [.errored, .failed].contains($0.status) }
    case .succeeded: filter { $0.status == .succeeded }
    }
  }
}

#if DEBUG
#Preview("Default") {
  PullRequestFeatureView(
    store: Store(
      initialState: .initial(appId: AppStoreConnect.Application.mock.id),
      reducer: PullRequestFeature.init
    )
  )
}
#endif
