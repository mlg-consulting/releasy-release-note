// swift-tools-version: 6.0

import PackageDescription

let package = Package(
  name: "tanami-features",
  defaultLocalization: "en",
  platforms: [.macOS(.v14)],
  products: [
    .library(name: "Application", targets: ["Application"]),
    .library(name: "Artifact", targets: ["Artifact"]),
    .library(name: "Build", targets: ["Build"]),
    .library(name: "Device", targets: ["Device"]),
    .library(name: "Menu", targets: ["Menu"]),
    .library(name: "Onboarding", targets: ["Onboarding"]),
    .library(name: "Providers", targets: [
      "XcodeCloudProvider"
    ]),
    .library(name: "Recipe", targets: ["Recipe"]),
    .library(name: "Settings", targets: [
      "SettingsRouter", "GeneralTab", "AccountTab", "AccountForm", "AppsTab", "DevicesTab", "MediaTab", "AboutTab"
    ]),
    .library(name: "Release", targets: ["Release"]),
    .library(name: "Simulator", targets: ["Simulator"])
  ],
  dependencies: [
    // External
    .package(url: "https://github.com/mlg-consulting/device-kit", .upToNextMajor(from: "0.2.6")),
    .package(url: "https://github.com/mlg-consulting/tanami-design-system", .upToNextMajor(from: "0.2.11")),
    .package(url: "https://github.com/mlg-consulting/tanami-foundation", .upToNextMajor(from: "0.8.4")),
    .package(url: "https://github.com/pointfreeco/swift-composable-architecture", .upToNextMajor(from: "1.17.0"))
    // Internal
  ],
  targets: [
    .target(
      name: "Menu",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Application",
        "Device",
        "SettingsRouter",
        "Simulator"
      ],
      path: "Sources/menu",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Application",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Recipe",
        "Release",
        "SettingsRouter",
        "XcodeCloudProvider"
      ],
      path: "Sources/application",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Artifact",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation"),
        "DevicesTab"
      ],
      path: "Sources/artifact",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Build",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/build",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Device",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/device",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Onboarding",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/onboarding",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    // ------ Settings ------ //
    .target(
      name: "SettingsRouter",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AboutTab",
        "AccountTab",
        "AppsTab",
        "DevicesTab",
        "GeneralTab",
        "MediaTab"
      ],
      path: "Sources/settings/router",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "GeneralTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/general-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AccountForm"
      ],
      path: "Sources/settings/accounts-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountForm",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/account-form",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "DevicesTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/settings/devices-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AppsTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/apps-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "MediaTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system")
      ],
      path: "Sources/settings/media-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AboutTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system")
      ],
      path: "Sources/settings/about-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    // ------ Providers ------ //
    .target(
      name: "XcodeCloudProvider",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Artifact",
        "DevicesTab"
      ],
      path: "Sources/providers/xcode-cloud",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Recipe",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/recipe",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Release",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AppsTab",
        "Build"
      ],
      path: "Sources/release",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Simulator",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/simulator",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    )
  ]
)
