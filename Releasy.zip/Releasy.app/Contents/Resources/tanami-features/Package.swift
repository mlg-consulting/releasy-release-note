// swift-tools-version: 6.0

import PackageDescription

let package = Package(
  name: "tanami-features",
  defaultLocalization: "en",
  platforms: [.macOS(.v14)],
  products: [
    .library(name: "Application", targets: ["Application"]),
    .library(name: "Artifact", targets: ["Artifact"]),
    .library(name: "Build", targets: ["Build"]),
    .library(name: "Device", targets: ["Device"]),
    .library(name: "Menu", targets: ["Menu"]),
    .library(name: "Onboarding", targets: ["Onboarding"]),
    .library(name: "PullRequest", targets: ["PullRequest"]),
    .library(name: "Settings", targets: [
      "SettingsRouter", "GeneralTab", "AccountTab", "AccountForm", "AppsTab", "DevicesTab"
    ]),
    .library(name: "Release", targets: ["Release"]),
    .library(name: "Simulator", targets: ["Simulator"])
  ],
  dependencies: [
    // External
    .package(url: "https://github.com/mlg-consulting/device-kit", .upToNextMajor(from: "0.2.3")),
    .package(url: "https://github.com/pointfreeco/swift-composable-architecture", .upToNextMajor(from: "1.17.0")),
    .package(url: "https://github.com/mlg-consulting/tanami-design-system", .upToNextMajor(from: "0.2.4")),
    .package(url: "https://github.com/mlg-consulting/tanami-foundation", .upToNextMajor(from: "0.3.0")),
    // Internal
  ],
  targets: [
    .target(
      name: "Menu",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Application",
        "Device",
        "SettingsRouter",
        "Simulator"
      ],
      path: "Sources/menu",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Application",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "PullRequest",
        "Release",
        "SettingsRouter"
      ],
      path: "Sources/application",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Artifact",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "DevicesTab"
      ],
      path: "Sources/artifact",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Build",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/build",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Device",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/device",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Onboarding",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/onboarding",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "SettingsRouter",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AccountTab",
        "AppsTab",
        "DevicesTab",
        "GeneralTab"
      ],
      path: "Sources/settings/router",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "GeneralTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/general-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AccountForm"
      ],
      path: "Sources/settings/accounts-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountForm",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/settings/account-form",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "DevicesTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/settings/devices-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AppsTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation")
      ],
      path: "Sources/settings/apps-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Simulator",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/simulator",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "PullRequest",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Artifact",
        "DevicesTab"
      ],
      path: "Sources/pull-request",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Release",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AppsTab",
        "Build"
      ],
      path: "Sources/release",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    )
  ]
)
