// swift-tools-version: 6.0

import PackageDescription

let package = Package(
  name: "tanami-features",
  defaultLocalization: "en",
  platforms: [.macOS(.v14)],
  products: [
    .library(name: "AccountPicker", targets: ["AccountPicker"]),
    .library(name: "Application", targets: ["Application"]),
    .library(name: "Artifact", targets: ["Artifact"]),
    .library(name: "Build", targets: ["Build"]),
    .library(name: "Console", targets: ["Console"]),
    .library(name: "Device", targets: ["Device"]),
    .library(name: "Menu", targets: ["Menu"]),
    .library(name: "Onboarding", targets: ["Onboarding"]),
    .library(name: "Providers", targets: [
      "XcodeCloudProvider"
    ]),
    .library(name: "RecentBuild", targets: ["RecentBuild"]),
    .library(name: "Recipe", targets: ["Recipe"]),
    .library(name: "Settings", targets: [
      "SettingsRouter", "GeneralTab", "AccountTab", "AccountForm", "AppsTab", "DevicesTab", "MediaTab", "AboutTab"
    ]),
    .library(name: "Release", targets: ["Release"]),
    .library(name: "Simulator", targets: ["Simulator"]),
    .library(name: "Workflow", targets: ["Workflow"])
  ],
  dependencies: [
    // External
    .package(url: "https://github.com/Pictarine/CodeMirror-SwiftUI", .upToNextMinor(from: "0.1.7")),
    .package(url: "https://github.com/mlg-consulting/device-kit", .upToNextMinor(from: "0.2.8")),
    .package(url: "https://github.com/mlg-consulting/tanami-design-system", .upToNextMinor(from: "0.2.20")),
//    .package(path: "../../../../tanami-design-system"),
    .package(url: "https://github.com/mlg-consulting/tanami-foundation", .upToNextMinor(from: "0.16.0")),
//    .package(path: "../../../../tanami-foundation"),
    .package(url: "https://github.com/pointfreeco/swift-composable-architecture", .upToNextMinor(from: "1.23.0"))
    // Internal
  ],
  targets: [
    .target(
      name: "Menu",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AccountPicker",
        "Application",
        "Console",
        "Device",
        "RecentBuild",
        "SettingsRouter",
        "Simulator"
      ],
      path: "Sources/menu",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountPicker",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/account-picker",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Application",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Recipe",
        "Release",
        "SettingsRouter",
        "XcodeCloudProvider",
        "Workflow"
      ],
      path: "Sources/application",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Artifact",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation"),
        "DevicesTab"
      ],
      path: "Sources/artifact",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Build",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/build",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Console",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        .product(name: "CodeMirror-SwiftUI", package: "CodeMirror-SwiftUI"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/console",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Device",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/device",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Onboarding",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/onboarding",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    // ------ Settings ------ //
    .target(
      name: "SettingsRouter",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AboutTab",
        "AccountTab",
        "AppsTab",
        "DevicesTab",
        "GeneralTab",
        "MediaTab"
      ],
      path: "Sources/settings/router",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "GeneralTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/general-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AccountForm"
      ],
      path: "Sources/settings/accounts-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AccountForm",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/account-form",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "DevicesTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/devices-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AppsTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/settings/apps-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "MediaTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system")
      ],
      path: "Sources/settings/media-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "AboutTab",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system")
      ],
      path: "Sources/settings/about-tab",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    // ------ Providers ------ //
    .target(
      name: "XcodeCloudProvider",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Artifact",
        "DevicesTab"
      ],
      path: "Sources/providers/xcode-cloud",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "RecentBuild",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "Workflow"
      ],
      path: "Sources/recent-build",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Recipe",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/recipe",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Release",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        "AppsTab",
        "Build",
        "Console"
      ],
      path: "Sources/release",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Simulator",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "DeviceKit", package: "device-kit"),
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation"),
        "SettingsRouter"
      ],
      path: "Sources/simulator",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    ),
    .target(
      name: "Workflow",
      dependencies: [
        // External
        .product(name: "ComposableArchitecture", package: "swift-composable-architecture"),
        // Internal
        .product(name: "TanamiDesignSystem", package: "tanami-design-system"),
        .product(name: "TanamiFoundation", package: "tanami-foundation"),
        .product(name: "TanamiServices", package: "tanami-foundation")
      ],
      path: "Sources/workflow",
      exclude: ["swiftgen.yml"],
      resources: [
        .process("Resources")
      ]
    )
  ]
)
